class CategoriesController < ApplicationController
  before_filter :authenticate, :except => [:show]
  before_filter :deny_without_store, :except => [:show]

  # show products for category with filter: gender, color, size, new & used
  def show
    # select categories for tree
    @categories_tree = Category.categories_tree
    @category_path = {}

    # select needed products
    category = Category.find(params[:id])

    @category_path[:category] = category.id
    @products_selection = Product.where(:accepted => 1).category_products(category)

    #breadcrumbs
    add_breadcrumb category.title, category.id
    add_path = ""
    [:subcategory, :gender, :size, :color].each do |param|
      if params[param]
        cat = Category.find(params[param].to_i)
        add_path << "#{param.to_s}=#{params[param].to_i}"
        path = "#{category.id}?"<< add_path
        add_breadcrumb cat.title, path
        add_path << "&"
      end
    end

    # filter by season
    if params[:show_season]
      @current_season = params[:season] ? Season.find(params[:season]) : Season.first
      @products_selection = @products_selection.season_products(@current_season)
      @seasons = Season.all
    end

    ["subcategory", "gender", "color", "size"].each do |category_name|
      join_category(category_name) if params[category_name]
    end

    @products_selection = @products_selection.all_new if params[:filter] == "new"
    @products_selection = @products_selection.all_used if params[:filter] == "used"

    @products = @products_selection.paginate(:page => params[:page])
  rescue ActiveRecord::RecordNotFound
    notify(:type => "error", :title => t(:product_management), :message => t(:category_not_found))
  rescue StandardError
    notify(:type => "error", :title => t(:product_management), :message => t(:internal_error))
    redirect_to :root
  end

  def join_category(name, param_name = nil)
    category = Category.find(params[param_name || name.to_sym])
    @category_path[Category::LEVELS_SYMBOLS[category.level]] = category.id
    @products_selection = @products_selection.send "#{name}_products".to_sym, category
  end

end