class UsersController < ApplicationController

  before_filter :authenticate, :only => [:show, :update, :update_avatar]
  before_filter :correct_user, :only => [:show, :update, :update_avatar]
  expose(:countries) { Country.all }
  expose(:states) { State.all }

  caches_page :dynamic_states
  #caches_action :new, :expires_in => APP_CONFIG[:expires_in].minutes

  def new
    add_breadcrumb I18n.t(:register), :new_user_path

    if current_user.blank?
      @user = User.new
      @user.build_address
    else
      redirect_to user_path(current_user)
    end
  end

  def create
    # Merge attribute skip for escaping validations within Address model
    params[:user][:address_attributes]

    @user = User.new(params[:user])
    if @user.save
      begin
        @user.send_confirmation_mail
        notify(:type => "notice", :title => t(:register_process), :message => t(:confirm_send))
        redirect_to :action => :send_mail
        #redirect_to root_path()
      rescue AWS::SES::ResponseError
        notify(:type => "alert", :title => t(:register_process), :message => t(:email_in_blacklist))
        redirect_to :action => :new
      end
    else
      notify(:type => "alert", :title => t(:register_process), :message => errors_messages_for(@user))
      render 'new'
    end
  end

  def send_mail

  end

  def show
    add_breadcrumb I18n.t(:my_profile), :user_path

    @user = User.find(current_user.id, :include => [:address, :seller])
      #fresh_when(:etag => [@user, @user.seller]) if Rails.env == "production"
  rescue ActiveRecord::RecordNotFound
    notify(:type => "alert", :title => t(:user_profile), :message => t(:record_not_found))
    redirect_back_or_root
  end

  # This method allows to update both seller and user profile
  # We can provide this with a help of nested attributes
  #
  def update
    tab = (params[:user][:seller_attributes]) ? 'seller' : 'general'
    if params[:user]
      year = params[:user]['birthday(1i)']
      month = params[:user]['birthday(2i)']
      day = params[:user]['birthday(3i)']

      if (Date.valid_date?(year.to_i, month.to_i, day.to_i).nil? &&
          !(year.blank? && month.blank? && day.blank?)) &&
          tab == 'general'

        notify(:type => "alert", :title => t(:update_profile), :message => t(:incorrect_date))
        return redirect_back_or_root
      end
      user = User.find(current_user.id, :include => (tab == 'general' ? [:address] : [:address, :seller]))

      if user.update_attributes(params[:user].merge(:reset => 0))
        notify(:type => "success", :title => t(:update_profile), :message => t(:successfully_changed))
        #expires_now
        redirect_to user_path + "?tab=#{tab}"
      else
        notify(:type => "alert", :title => t(:update_profile), :message => errors_messages_for(user))
        request.env["HTTP_REFERER"] ? (redirect_to :back) : (redirect_to root_path)
      end
    else
      notify(:type => "alert", :title => t(:update_profile), :message => t(:record_not_found))
      redirect_back_or_root
    end
  end

  def update_avatar
    @user = User.find_by_id(params[:id])
    if  @user.update_attributes(params[:user].merge(:reset => 0))
      notify(:type => "success", :title => t(:update_profile), :message => t(:successfully_changed))
      #redirect_to user_path + "?tab=#{tab}"
    else
      notify(:type => "alert", :title => t(:update_profile), :message => errors_messages_for(@user))
      #redirect_back_or_root
    end

    respond_to do |format|
      format.js
    end
  end

  #This method creates instance variable @country_states and renders rjs for dynamic states select
  #
  def dynamic_states
    @country_states = {}
    Country.all(:include => :states).each { |c| @country_states.merge!(c.id => c.states.collect(&:id)) }
    respond_to { |format| format.js { render 'dynamic_states.js.erb', :layout => false } }
  end

  def resend_mail
    user = User.find_by_id(params[:id])
    if user.nil?
      notify(:type => "notice", :title => t(:register_process), :message => t(:record_not_found))
    else
      check_if_registered?(user)
    end
    redirect_to root_path()
  end

  private

  def correct_user
    user = User.find_by_id(params[:id])
    unless current_user?(user)
      notify(:type => "alert", :title => t(:user_profile), :message => t(:permission))
      redirect_to user_path(current_user)
    end
  end

  # Looks whether user is already registered or not
  # otherwise sends an email confirmation
  #
  def check_if_registered?(user)
    if user.registered?
      notify(:type => "alert", :title => t(:register_process), :message => t(:already_registered))
    else
      notify(:type => "notice", :title => t(:register_process), :message => t(:confirm_send))
      user.send_confirmation_mail
    end
  end
end
