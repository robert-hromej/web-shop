class ReportingController < ApplicationController
  require 'will_paginate/array'

  before_filter :authenticate_seller
  before_filter :deny_without_store
  before_filter :common_breadcrumbs

  def common_breadcrumbs
    add_breadcrumb I18n.t(:my_profile), {:controller => :users, :action => :show, :id => current_user.id}
    add_breadcrumb I18n.t(:my_store), {:controller => :stores, :action => :edit, :id => current_seller.store.id}
  end

  def sold_products
    add_breadcrumb I18n.t(:sold_products), :sold_products_path

    @invoice_datum = ReceiverOption.datum_for_seller(seller_id, params[:filter]).paginate(:page => params[:page], :per_page => 12)
    if @invoice_datum.blank?
      notify(:type => "notice", :title => t(:reporting), :message => t(:any_sold_products))
    end
  end

  def for_sale_products
    add_breadcrumb I18n.t(:for_sale), :for_sale_products_path

    @products = Product.for_sale_products(seller_id).paginate(:page => params[:page])
    notify(:type => "notice", :title => t("report.title"), :message => t("report.for_sale_products.havent")) if @products.blank?
  rescue
    redirect_back_or_root
  end

  def renew_products
    unless params[:renew].nil?
      if Product.update_all({:expiration_date => Time.now + Product::EXPIRATION_TIME, :accepted => 1}, ["id IN (?) AND seller_id = ?", params[:renew].map { |id| id.to_i }, seller_id])
        params[:renew] = nil
      end
    end
    request.env["HTTP_REFERER"] ? (redirect_to :back) : (redirect_to root_path)
  end

  def fee_history
    add_breadcrumb I18n.t(:fee_history), fee_history_path

    @history = InvoiceItemData.sales_fee(current_seller) + PaymentOption.listing_for(current_seller)
    @history = @history.sort_by{|elem| elem[:date]}.reverse.paginate(:page => params[:page], :per_page => 12)

  end

  def product_history
    add_breadcrumb I18n.t(:product_history), :product_history_path
    @products = Product.history_for_seller(seller_id).paginate(:page => params[:page])
  end

  def used_products
    add_breadcrumb I18n.t(:used_products), :used_products_path

    status = params[:filter]
    condition = show_all_used_products?(status) ? "" : (status.blank? ? "accepted is null" : "accepted = #{status}")
    @products = Product.used_products(seller_id, condition).paginate(:page => params[:page])
    notify(:type => "notice", :title => t("report.title"), :message => t("report.used_products.havent")) if @products.blank?
  rescue
    redirect_back_or_root
  end

  private

  def show_all_used_products?(status)
    status.nil? || status.to_s == "all"
  end

end
