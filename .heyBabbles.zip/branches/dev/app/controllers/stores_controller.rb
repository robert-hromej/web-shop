class StoresController < ApplicationController

  before_filter :authenticate_seller
  before_filter :common_breadcrumbs
  caches_action :new, :expires_in => APP_CONFIG[:expires_in].minutes

  def common_breadcrumbs
    add_breadcrumb I18n.t(:my_profile), user_path(current_user)
  end

  def new
    check_for_store
    @store = current_user.seller.stores.build
    add_breadcrumb I18n.t(:new_store), new_store_path(@store)
  end

  def create

    check_for_store
    @store = Store.new(params[:store])
    add_breadcrumb I18n.t(:create_store), stores_path(@store)
    @store.seller_id = current_user.seller.id
    if @store.save
      notify(:type => "success", :title => t(:store_profile), :message => t(:store_created))
      redirect_to management_products_path
      #redirect_to edit_store_path(@store)
    else
      notify(:type => "alert", :title => t(:store_profile), :message => errors_messages_for(@store))
      render 'new'
    end
  end

  def edit

    @store = Store.find(params[:id])
    add_breadcrumb I18n.t(:edit_store), edit_store_path(@store)
    check_for_right_seller(@store)
    # We don`t want to cache just after creation
    #fresh_when(:etag => [@store, @store.seller.address])
  rescue ActiveRecord::RecordNotFound
    notify(:type => "alert", :title => t(:store_profile), :message => t(:havent_got_store_profile))
    redirect_to new_store_path
  end

  def update
    @store = Store.find(params[:id])
    check_for_right_seller(@store)

    if @store.update_attributes(params[:store])
      notify(:type => "success", :title => t(:store_profile), :message => t(:store_updated))
      redirect_to edit_store_path(@store)
    else
      notify(:type => "success", :title => t(:store_profile), :message => errors_messages_for(@store))
      render "edit"
    end
  rescue ActiveRecord::RecordNotFound
    notify(:type => "alert", :title => t(:store_profile), :message => t(:havent_got_store_profile))
    redirect_to new_store_path
  end

  private
  #We use this method, because before_filter - to heavy for usage

  # This will be invoked if user already has store
  def check_for_store
    redirect_to edit_store_path(current_user.store) if current_user.has_store?
  end

  #if seller tries to access other sellers pages he will be redirected
  # @param store [Store]
  def check_for_right_seller(store)
    if store != current_user.store
      notify(:type => "alert", :title => t(:store_profile), :message => t(:permission))
      redirect_back_or_root
    end
  end
end
