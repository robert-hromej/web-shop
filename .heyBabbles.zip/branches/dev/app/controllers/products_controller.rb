class ProductsController < ApplicationController

  protect_from_forgery :except => [:ipn_for_approval, :ipn_for_key]
  before_filter :authenticate, :except => [:ipn_for_approval, :ipn_for_key, :index, :show, :dynamic_product_combinations,
                                           :dynamic_product_cs]
  before_filter :deny_without_store, :except => [:ipn_for_approval, :ipn_for_key, :index, :show, :dynamic_product_combinations,
                                                 :dynamic_product_cs]
  before_filter :common_breadcrumbs, :except => [:show, :dynamic_product_combinations, :dynamic_categories, :index]
  before_filter :edit_product_breadcrumbs, :only => [:edit, :advanced, :paid]
  before_filter :deny_when_not_accepted, :only => [:show, :edit, :advanced, :paid]

  #caches_page :dynamic_categories
  caches_action :new, :expires_in => APP_CONFIG[:expires_in].minutes

  expose(:currencies) { Currency.all }
  expose(:from_shippings) { Country.from_shippings }
  expose(:categories) { Category.all }
  expose(:combinations) { Combination.all }

  def common_breadcrumbs
    add_breadcrumb I18n.t(:my_profile), {:controller => :users, :action => :show, :id => current_user.id}
    add_breadcrumb I18n.t(:my_store), {:controller => :stores, :action => :edit, :id => current_seller.store.id}
  end

  def edit_product_breadcrumbs
    @product = Product.find_by_id(params[:id])
    add_breadcrumb "#{@product.try(:name)}", :"#{action_name}_product_path"
    #access_control(@product)
  end

  def new
    add_breadcrumb I18n.t(:new_product), :new_product_path
    @product = Product.new

    #respond_to do |format|
    #  format.html { render :html => :new_product_path }
    #  format.js { render :js => "window.location='#{new_product_url}';" }
    #end

  end

  def create
    #May be I am wrong, but we need to check whether
    #combination exists or not!
    combination_id = Combination.where(:category_id => params[:product].delete(:category_id),
                                       :subcategory_id => params[:product].delete(:subcategory_id),
                                       :gender_category_id => params[:product].delete(:gender_category_id)).first.try(:id)
    @product = Product.new(params[:product].merge(:seller_id => current_user.seller.id,
                                                  :store_id => current_user.store.id,
                                                  :combination_id => combination_id))
    respond_to do |format|
      if @product.save
        UserMailer.product_created(current_user, @product).deliver if @product.new?
        notify(:type => "success", :title => t(:product_management), :message => t(:successfully_saved))

        format.html {
          redirect_to advanced_product_path(@product)
        }
        format.js {
          render :js => "window.location='#{advanced_product_path(@product)}';"
        }
      else
        notify(:type => "alert", :title => t(:product_management), :message => errors_messages_for(@product))
        format.html {
          render :action => :new
        }
        format.js {
          #render :js => "window.location='#{new_product_url}';"
          render :js=> "set_flash();"
        }

        #redirect_to(:back)
        #render :js=> "set_flash();"
      end
    end

  end

  def management
    add_breadcrumb I18n.t(:product_management), :management_products_path

    @products = current_user.my_products.includes(:images, :item_types).paginate(:page => params[:page])
  end

  # searches products by string and category
  def index
    add_breadcrumb I18n.t(:search_result), {:controller => :products, :action => :index}
    unless params[:season]
      unless params[:from_seller]
        params[:query] ||= ""

        @search_query = params[:query]
        category = Category.find(params[:category_id]) unless params[:category_id].blank?

        @products = Product.search(@search_query, :category => category, :page => params[:page])
      else
        @seller = Seller.find_by_id(params[:from_seller])
        #@seller_name = @seller.try(:fullname)
        @seller_name = @seller.try(:store).try(:name)
        @products = @seller.store.products.where(:accepted => 1).paginate(:page => params[:page])
      end
    else
      if Season.find_by_id(params[:season]).try(:is_active?)
        @products = Product.seasonal_products(params[:season]).paginate(:page => params[:page])
        @season_name = Season.find_by_id(params[:season]).try(:title)
      else
        notify(:type => "alert", :title => t(:seasonas), :message => t(:unactive_season))
        redirect_to root_path
        @products = []
      end
    end

    unless @products == []
      @products = @products.try(:all_new) if params[:filter] == "new"
      @products = @products.try(:all_used) if params[:filter] == "used"

      ProductCounter.decrement_points(@products.collect(&:id))
    end

  rescue ActiveRecord::RecordNotFound => e
    notify(:type => "alert", :title => t(:searching), :message => e)
  rescue
    notify(:type => "error", :title => t(:product_management), :message => t(:product_not_found))
    redirect_to root_path
  end

  def edit
  end

  #todo Refactor
  #It would be better to assign params[:combination] just in UI
  def update
    @product = Product.find_by_id(params[:id])
    access_control_product(@product) do

      #combination_id = Combination.where(:category_id => params[:product].delete(:category_id),
      #                                   :subcategory_id => params[:product].delete(:subcategory_id),
      #                                   :gender_category_id => params[:product].delete(:gender_category_id)).first.try(:id)
      #if @product.update_attributes(params[:product].merge(:combination_id => combination_id))

      if @product.update_attributes(params[:product])
        notify(:type => "success", :title => t(:product_management), :message => t(:successfully_saved))
      else
        notify(:type => "alert", :title => t(:product_management), :message => errors_messages_for(@product))
      end
      #redirect_to edit_product_path(@product)
      #render :edit
      redirect_to advanced_product_path(@product)
    end
  end

  def advanced
#-------------------------
#    @price_one_image = Configuration.get_config('price_one_image').to_f
#-------------------------


    respond_to do |format|
      format.html {
        render :html => :advanced_product_path }
      format.js {
        render :js => "window.location='#{advanced_product_url}';" }
    end
  end

  def paid
    @services = Service.all
    @price_one_image = Configuration.get_config('price_one_image').to_f
  end


  def show
    @product = Product.find_by_id(params[:id])
#TODO Miroslav. fix breadcrumb, should link to product.store instead of current_user.store
#    add_breadcrumb "#{@product.try(:store).try(:name)}", {:controller => :stores, :action => :edit, :id => current_seller.store.id}
    add_breadcrumb @product.try(:category).try(:title), category_path(@product.try(:category).id)
    add_breadcrumb @product.try(:subcategory).try(:title), category_path(@product.try(:category).id, :subcategory => @product.try(:subcategory).id)
    name = @product.try(:name)
    if name.length > 20
      name = name.slice(0, 20) << "..."
    end
    add_breadcrumb name, :product_path

    @seller = @product.try(:seller).try(:user)
#@other_products = Product.where("seller_id = #{@product.try(:seller).try(:id)} and id != #{@product.try(:id)} and accepted = 1").limit(3)
    @other_products = @product.try(:seller).store.products.where("accepted = 1 and id != #{@product.try(:id)}").limit(3)
    recent_products(@product.id)
  end


  def dynamic_product_combinations
    @combinations = ItemType.for_product(params[:id]).all
    @product_combinations = []
    @combinations.each do |combination|
      @product_combinations << {:color => {:title => combination.color_title, :id => combination.color_category_id},
                                :size => {:title => combination.size_title, :id => combination.size_category_id},
                                :count => combination.item_count, :price => combination.price}
    end
    render :layout => false
  end

  def dynamic_product_cs
    @categories_cs ||= {}
    combinations_new = CombinationCs.for_new_product(params[:id])
    combinations_new.each do |combination|
      size_id = combination.size_id.to_s
      color_id = combination.color_id.to_s
      @categories_cs[size_id] ||= []
      @categories_cs[size_id] << color_id
    end
    render :layout => false
  end

  def dynamic_categories
    @categories = {}
    #    creates hash for dynamic_categories like {"1"=>{"2"=>[3, 4],"6"=>[3,8]},"5"=>{"6"=>[3,8]}}
    #    where keys in the parent hash are a category_id's keys in the second hash are a subcategory_id's
    #    and arrays contain all relative gender id's
    #
    combinations.each do |combination|
      category_id = combination.category_id.to_s
      subcategory_id = combination.subcategory_id.to_s
      gender_id = combination.gender_category_id

      @categories.merge!(category_id => {}) if @categories[category_id].nil?
      unless @categories[category_id][subcategory_id].nil?
        @categories[category_id][subcategory_id] << gender_id
      else
        @categories[category_id].merge!(subcategory_id => [gender_id])
      end
    end
    render :layout => false
  end

  private

  def deny_without_store
    if current_user.store.nil?
      message = (t('need_store') + ("<a href='#{new_store_path}'>Create store</a>")).html_safe
      notify(:type => "error", :title => t(:product_management), :message => message)
      redirect_back_or_root
    end
  end

  def deny_when_not_accepted
    product = Product.find(params[:id])
    if product.accepted != 1
      if current_user
        unless current_user.my_product?(product)
          redirect_back_or_root
        end
      else
        redirect_back_or_root
      end
      notify(:type => "alert", :title => t(:access_denied), :message => t(:product_is_not_accepted))
    end
  rescue ActiveRecord::RecordNotFound
    redirect_back_or_root
  end

end
