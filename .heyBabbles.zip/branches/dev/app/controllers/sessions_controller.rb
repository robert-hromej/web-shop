class SessionsController < ApplicationController

  #caches_action :new, :expires_in => APP_CONFIG[:expires_in].minutes
  skip_before_filter :authenticate, :except => [:update_password]
  before_filter :deny_if_signed, :except => [:destroy, :update_password]
  #before_filter :deny_if_suspend

  def new;
    @user = User.new
    add_breadcrumb I18n.t(:sign_in), :signin_path
  end

  #Sign in process
  #
  def create
    @user = User.new(params[:user])
    params[:session] = params[:user]
    user = User.authenticate(params[:user][:email], params[:user][:password])
    if user.nil?
      notify(:type => "error", :title => t(:authenticate), :message => t(:invalid))
      @user.password = ''
      render 'new'
    else
      unless user.suspended?
        if user.registered?
          notify(:type => "success", :title => t(:authenticate), :message => t(:sign_in_success))
          sign_in_user user
          unload_session_cart_to_db(user_path(user))
        else
          message = (t(:not_finished) + " <a id='Resend Email' href='#{resend_mail_path(user)}'>Resend Email</a>").html_safe
          notify(:type => "alert", :title => t(:authenticate), :message => message)
          redirect_to root_path
        end
      else
        notify(:type => "alert", :title => t(:authenticate), :message => t(:your_account_is_suspended));
        redirect_back_or_root
      end
    end
  end

  #Sign out process
  #
  def destroy
    notify(:type => "success", :title => t(:authenticate), :message => t(:signed_out))
    cookies.delete("#{Facebooker2.cookie_prefix + Facebooker2.app_id.to_s}")
    sign_out_user
    session[:cart_items] = []
    redirect_to root_path
  end

  def facebook_connect
    if current_facebook_user
      #look for an existing users
      @user = User.find_by_facebook_uid(current_facebook_user.id)
      #if one isn't found, try to grab the email address and join to an existing account
      if @user.nil?
        join_or_create_user
      else
        sign_in_user @user
        unload_session_cart_to_db(@user)
        #redirect_to @user
      end
    else
      notify(:type => "error", :title => t(:fb_connect_error), :message => t(:fb_registration))
      redirect_back_or_root
    end
  end

  # User access by 'html' request:
  # 1.will have ability to set pass after 'facebook_connect' process
  # 2.will update pass from user_profile page
  def update_password
    # if user has a password the process will check previous one
    if !current_user.encrypted_password.blank?
      check_previous_password(params)
    else
      # invoke simple update password functional
      update_password_by(params)
    end
  end

  #This method was created for integration tests
  #
  def integration_sign_in
    user = User.find(params[:id])
    sign_in_user(user) if Rails.env == "test"
    redirect_to root_path
  end

  private
  #Grab the email address and join to an existing account
  #otherwise new users created in system
  #
  def join_or_create_user
    current_facebook_user.fetch
    user_facebook_email = current_facebook_user.email
    user_facebook_uid = current_facebook_user.id
    if !user_facebook_email.blank?

      @user = User.first(:conditions => ["facebook_email = ? OR email = ?", user_facebook_email, user_facebook_email])
      if @user.nil?
        #We create new one
        #
        @user = User.new(:facebook_email => user_facebook_email, :email => user_facebook_email, :facebook_uid => user_facebook_uid, :registered => true)
        @user.save(:validate => false)
        @user.build_address.save(:validate => false)
      else
        #Otherwise we join to existing one
        #
        @user.update_attributes(:facebook_uid => user_facebook_uid, :facebook_email => user_facebook_email, :reset => 0)
      end
      sign_in_user @user
      redirect_to @user
    else
      redirect_back_or_root
    end
  end


  # @param params [filtered hash]
  # Invoke update process for 'current user'
  def update_password_by(params)
    if current_user.update_attributes(params[:user].merge(:reset => 1))
      sign_in_user current_user
      notify(:type => "success", :title => t(:my_profile), :message => t(:password_updated))
      redirect_to current_user
    else
      notify(:type => "alert", :title => t(:my_profile), :message => errors_messages_for(current_user))
      redirect_back_or_root
    end
  end

  # @param params [filtered hash]
  # if previous password equal one from the form then invoke password functional
  def check_previous_password(params)
    if current_user.hash_password?(params[:user][:previous_password])
      params.delete(:previous_password)
      update_password_by(params)
    else
      message = (t('previous_password_match') + t('cant_remember') + " <a href='#{begin_reset_path}' id='RESET'>Reset</a>").html_safe
      notify(:type => "alert", :title => t(:my_profile), :message => message)
      redirect_to current_user
    end
  end
end
