class PurchaseHistoriesController < ApplicationController

  def index
    add_breadcrumb I18n.t("purchase_history.title"), :purchase_histories_path
    @items = InvoiceItemData.only_products.by_user(current_user.id).includes(:identifier => :sold_one).paginate(:page => params[:page])
    notify(:type => "notice", :title => t("purchase_history.title"), :message => t("purchase_history.havent")) if @items.blank?
  rescue
    request.env["HTTP_REFERER"] ? (redirect_to :back) : (redirect_to root_path)
  end

end
