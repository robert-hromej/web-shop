class ApplicationImagesController < ApplicationController

  before_filter :authenticate
  respond_to :js

  def create
    #@image = ApplicationImage.new(params[:application_image])
    @image = ApplicationImage.new(params[:application_image].merge({:product_id => params[:id]}))
    #@product = @image.product
    #@product = Product.find_by_id(params[:application_image][:product_id])
    @product = Product.find_by_id(params[:id])
    #todo need to refactor logic
    #access_control(@product)

    if @image.save
      remove_obsolete_paykeys(true)
      notify(:type => "success", :title => t('product_management'), :message => t('image.created'))
    else
      notify(:type => "alert", :title => t('product_management'), :message => errors_messages_for(@image))
    end
  end

  def update
    @image = ApplicationImage.find_by_id(params[:id])
    #todo need to refactor logic
    #access_control(@image.product)
    description = params[:application_image][:description]

    if_image_exists? do
      if @image.update_attribute(:description, description)
        notify(:type => "success", :title => t('product_management'), :message => t('image.updated'))
      else
        notify(:type => "alert", :title => t('product_management'), :message => errors_messages_for(@image))
      end
    end
  end

  def destroy
    @image = ApplicationImage.find_by_id(params[:id])
    @product = @image.product
    #todo need to refactor logic
    #access_control(@product)

    if_image_exists? do
      if @image.destroy
        remove_obsolete_paykeys(true)
        notify(:type => "success", :title => t('product_management'), :message => t('image.deleted'))
      else
        notify(:type => "alert", :title => t('product_management'), :message => errors_messages_for(@image))
      end
    end

  end

  def set_main
    @image = ApplicationImage.find_by_id(params[:id])
    @product = @image.product
    #todo need to refactor logic
    #access_control(@product)

    if_image_exists? { @image.set_as_the_main }
  end

  private

  def if_image_exists?
    if @image.nil?
      notify(:type => "alert", :title => t('product_management'), :message => t('image.no_image'))
    else
      yield
    end
  end

end
