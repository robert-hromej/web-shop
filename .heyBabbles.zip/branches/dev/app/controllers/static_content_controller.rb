class StaticContentController < ApplicationController
  before_filter :authenticate, :except => [:show]
  def show
    @content = PagePart.find_by_page_id(params[:id]).body
    @header = PageTranslation.find_by_page_id(params[:id]).title
    add_breadcrumb @header, static_content_path(params[:id])
  end

end
