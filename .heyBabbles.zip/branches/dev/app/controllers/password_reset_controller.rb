class PasswordResetController < ApplicationController
  skip_before_filter :authenticate
  before_filter :deny_if_signed, :only => [:finish_registration]

  expose(:user) { User.find_by_reset_password_token(params[:id]) }

  caches_action :new, :edit, :finish_registration, :expires_in => APP_CONFIG[:expires_in].minutes

  def new;
    add_breadcrumb I18n.t(:password_reset), :new_password_reset_path
  end

  def edit;
    add_breadcrumb I18n.t(:update_password), :edit_password_reset_path
    unless User.find_by_reset_password_token(params[:id])
      notify(:type => "alert", :title => t(:reset_password_process), :message => t(:password_expired))
      redirect_to new_password_reset_path
    end

  end

  def create
    user = User.find_by_email(params[:email])
    if user
      user.send_reset_password_mail
      notify(:type => "notice", :title => t(:email_service_process), :message => t(:email_reset_sent))
      redirect_to root_path
    else
      notify(:type => "error", :title => t(:email_service_process), :message => t(:no_email))
      render "new"
    end
  end


  def update
    if user.link_expired?
      notify(:type => "alert", :title => t(:reset_password_process), :message => t(:password_expired))
      redirect_to new_password_reset_path
    elsif user.update_attributes(params[:user].merge!(:reset => 1))
      notify(:type => "success", :title => t(:reset_password_process), :message => t(:password_reseted))
      redirect_to signin_path
    else
      notify(:type => "alert", :title => t(:reset_password_process), :message => t(:password_not_reseted))
      render "edit"
    end
  rescue => e
    notify(:type => "error", :title => t(:reset_password_process), :message => t(:record_not_found))
    redirect_to root_path
  end

  def finish_registration
    @user = User.find(params[:id])
    finish_process if @user.ready_for_registration?
  rescue ActiveRecord::RecordNotFound
    notify(:type => "alert", :title => t(:register_process), :message => t(:record_not_found))
    redirect_to root_path()
  end

  # This method was created for special case
  # when user try to reset his password from profile
  # form and click link 'Reset' he will be forced
  # to start 'Reset password process from begin'
  def begin_process
    sign_out_user
    redirect_to new_password_reset_path
  end

  private
  # Add user to ConstantContact ESP
  # otherwise redirects to root and resend confirm email
  #
  def finish_process
    if @user.added_to_constant_contact?
      sign_in_user @user
      notify(:type => "success", :title => t(:register_process), :message => t(:welcome))
      unload_session_cart_to_db(@user)
    else
      @user.send_confirmation_mail
      notify(:type => "notice", :title => t(:register_process), :message => t(:confirm_send))
      notify(:type => "error", :title => t(:register_process), :message => t(:add_contact_error))
      redirect_to root_path
    end
  end

end
