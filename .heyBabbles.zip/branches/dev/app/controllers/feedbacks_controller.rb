class FeedbacksController < ApplicationController

  def index
    add_breadcrumb I18n.t(:feedbacks), :feedbacks_path
    if params[:controllers] == 'sellers'
      if params[:id] == current_seller.id.to_s
        @seller = Seller.find_by_id(seller_id)
        @feedbacks = Seller.feedbacks(seller_id).paginate(:page => params[:page])
        notify(:type => "notice", :title => t("feedback.title"), :message => t("feedback.havent")) if @feedbacks.blank?
      else
        redirect_back_or_root
        notify(:type => "notice", :title => t("feedback.title"), :message => t("cant_access"))
      end
    else
      @feedbacks = User.by_payed(user_id).paginate(:page => params[:page])
      notify(:type => "notice", :title => t("feedback.title"), :message => t("feedback.havent")) if @feedbacks.blank?
    end
  rescue
    redirect_back_or_root
  end

  def create
    @feedback = Feedback.new(:writer_id => user_id, :writeable_id => params[:writeable_id],
                             :writeable_type => "Seller", :feedback_text => params[:feedback][:feedback_text],
                             :write_through_id => params[:write_through_id], :write_through_type => "InvoiceItemData")
    if @feedback.save
      #render :update do |page|
      #  page.replace_html "#feedback_#{params[:write_through_id]}", "<div class='feed_text'>#{@feedback.feedback_text}</div>"
      #
      #end
      @write_through_id = params[:write_through_id]
      respond_to do |format|
        format.js
      end
    end
  rescue
    redirect_back_or_root
  end

end