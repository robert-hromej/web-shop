class ApplicationController < ActionController::Base

  before_filter :authenticate
  before_filter :set_home_breadcrumb
  protect_from_forgery

  include Facebooker2::Rails::Controller
  include SessionsHelper
  include ApplicationHelper
  helper_method :fb_user_valid?

  def set_home_breadcrumb
    add_breadcrumb I18n.t(:home), :root_path
  end

  def fb_user_valid?
    valid = current_facebook_user
    begin
      current_facebook_user.try(:fetch)
    rescue Mogli::Client::HTTPException => e
      cookies.delete(fb_cookie_name) if !fb_cookie_name.nil?
      valid = false
    end
    valid
  end


  # this method needs optimization for payment.
  def validate_cart(line_item_ids = false)
    initialize_cart
    @cart_items = @cart.get_items(line_item_ids)
    invalid_items = []
    sellers = []
    valid = true
    @cart_items.each do |line_item|
      unless line_item.has_valid_condition?
        invalid_items << line_item
      end
      sellers << line_item.seller
    end
    sellers.uniq!
    valid = false if !invalid_items.blank? || sellers.count > SELLER_LIMIT || cart_items_cost[:total] > 10000
    @cart_data = {:invalid_items => invalid_items, :sellers => sellers, :valid => valid}
  end

  private

    def initialize_cart
      if signed_in_user?
        @cart = DbCart::Cart.new(current_user)
      else
        @cart = SessionCart::Cart.new(session)
      end
    end

    def calculate_cost(params, item_type)
      ship_to = ShipTo.find_by_id(params[:ship_to_id])
      shipping_cost = calculate_shipping_cost(params[:quantity].to_i, ship_to)
      total_cost = item_type.price * params[:quantity].to_i + shipping_cost
      {:shipping => shipping_cost, :total => total_cost}
    end

  #todo Refactor
  #To raise error is a bad idea.We need to create new mechanism.
  #
  def access_control(record, options = {})
    case
      when (record.is_a?(Product) or options[:as] == :product)
        #raise "access denied to this product"
        unless current_user.my_product?(record)
          redirect_back_or_root
          notify(:type => "alert", :title => t(:access_denied), :message => t(:access_denied_to_product))
        end
      when (record.is_a?(ShipTo) or options[:as] == :ship_to)
        #raise "access denied to this product"
        unless current_user.my_product?(record.product_id)
          redirect_back_or_root
          notify(:type => "alert", :title => t(:access_denied), :message => t(:access_denied_to_product))
        end
      when (record.is_a?(ProductCounter) or options[:as] == :product_counter)
        #raise "access denied to this product"
        unless current_user.my_product?(record.product_id)
          redirect_back_or_root
          notify(:type => "alert", :title => t(:access_denied), :message => t(:access_denied_to_product))
        end
      when record.is_a?(NilClass)
        #raise "it object is nil"
        redirect_back_or_root
        notify(:type => "alert", :title => t(:access_denied), :message => t(:access_denied_to_product))
      else
        raise "dont implement access_control for #{record.class} model"
    end
  end

  def access_control_product(record, options = {})
    case
      when (record.is_a?(Product) or options[:as] == :product)
        #raise "access denied to this product"
        unless current_user.my_product?(record)
          redirect_back_or_root
          notify(:type => "alert", :title => t(:access_denied), :message => t(:access_denied_to_product))
        else
          yield
        end
      when (record.is_a?(ShipTo) or options[:as] == :ship_to)
        #raise "access denied to this product"
        unless current_user.my_product?(record.product_id)
          redirect_back_or_root
          notify(:type => "alert", :title => t(:access_denied), :message => t(:access_denied_to_product))
        else
          yield
        end
      when (record.is_a?(ProductCounter) or options[:as] == :product_counter)
        #raise "access denied to this product"
        unless current_user.my_product?(record.product_id)
          redirect_back_or_root
          notify(:type => "alert", :title => t(:access_denied), :message => t(:access_denied_to_product))
        else
          yield
        end
      when record.is_a?(NilClass)
        #raise "it object is nil"
        redirect_back_or_root
        notify(:type => "alert", :title => t(:access_denied), :message => t(:access_denied_to_product))
      else
        raise "dont implement access_control for #{record.class} model"
    end
  end

  # example notify_object(@product, :method => :save, :success_msg => "success saved",  :alert_msg => "fail saved")
  #
  def notify_do(object, options = {})

    object_return = object.send(options[:method])

    if object_return
      options[:type] = "success"
      options[:message] = options[:success_msg]
      remove_obsolete_paykeys(options[:feature]) if options[:remove_obsolete_paykeys]
      check_product_state(object.product) if object.is_a?(ShipTo) || object.is_a?(ItemType)
    else
      options[:type] = "alert"
      options[:message] = options[:alert_msg] || errors_messages_for(object)
    end

    if options[:ajax]
      ajax_notify(options)
    else
      notify(options)
    end

    #if object_return
    #  true
    #else
    #  false
    #end
    !!object_return
  end


  def check_product_state(product)
    if product.destinations.count == 0 || product.item_types.count == 0
      product.update_attribute(:accepted, nil)
    elsif product.destinations.count > 0 && product.item_types.count > 0
      if product.new
        product.update_attribute(:accepted, 1) if product.accepted != 1
      else
        product.update_attribute(:accepted, 2) if product.accepted != 2
      end
    end
  end

end
