class IpnsController < ApplicationController
  require 'adaptive_payment'
  require 'payment'
  include AdaptivePayment

  skip_before_filter :authenticate
  protect_from_forgery :except => [:preapproval, :payment, :payment_feature]


  def create
    postback_validation
    render :nothing => true
  end


  def preapproval
    if postback_validation == "VERIFIED" && params[:approved] == "true"
      preapproval_key = ApprovalOptions.find_by_preapproval_key(params[:preapproval_key])
      if preapproval_key && preapproval_key.update_attributes(:approved => true, :active => true)
        mark_older_keys_as_inactive(preapproval_key)
        Rails.logger.info "Preapproval key accepted!"
      end
    else
      Rails.logger.info "Preapproval key rejcted"
    end
    render :nothing => true
  end


  def payment
    if postback_validation == "VERIFIED"
      payment_option = PaymentOption.find_by_pay_key(params[:pay_key])
      if payment_option && payment_option.update_attribute(:txn_id, params[:transaction])
        Rails.logger.info "Transaction info saved!"
      end
    else
      Rails.logger.info "Not saving invalid transaction info"
    end
    render :nothing => true
  end

  def payment_feature
    if postback_validation == "VERIFIED"
      payment_option = PaymentOption.find_by_pay_key(params[:pay_key])
      if payment_option && payment_option.update_attribute(:txn_id, params[:transaction])
        Rails.logger.info "Transaction info saved!"
        AdaptivePayment.delete_purchased_features(payment_option.params["techDetails"]) if params[:status] == "COMPLETED" && params[:preapproval_key] == nil
      else
        Rails.logger.info "Saving transaction info failed"
      end
    else
      Rails.logger.info "Transaction info not saved"
    end
    render :nothing => true
  end

  private


    def mark_older_keys_as_inactive(preapproval_key)
      ApprovalOptions.where(:sender_email => preapproval_key.sender_email, :approved => true, :active => true).where("id != ?", preapproval_key.id).each do |old_approval_key|
        old_approval_key.update_attribute(:active, false)
      end
    end

    def postback_validation
      response_params = "cmd=_notify-validate&" + request.raw_post.to_s
      http = Net::HTTP.new("www.paypal.com", 443)
      http.verify_mode = OpenSSL::SSL::VERIFY_NONE
      http.use_ssl = true
      response = http.post("/cgi-bin/webscr", response_params)
      Rails.logger.info "Processing validations..."
      return response.body
    end


end
