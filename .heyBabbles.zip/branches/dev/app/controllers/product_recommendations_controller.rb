class ProductRecommendationsController < ApplicationController
  skip_before_filter :authenticate

  def show
    add_breadcrumb I18n.t(:recommendation_page), :recommendation_path
    if params[:id]
      @product = Product.find_by_id(params[:id])
      @recommendations = @product.recommendations if @product
      @recent = return_recent_products(params[:id].to_i)
      redirect_back_or_root unless @product
    end
  end

end
