class SellersController < ApplicationController
  before_filter :authenticate, :except => :show
  before_filter :check_if_seller?, :except => [:show, :rate]
  before_filter :correct_seller, :only => [:show]

  expose(:countries) { Country.all }
  expose(:states) { State.all }

  caches_action :new, :expires_in => 10.seconds

  def new
    add_breadcrumb I18n.t(:register_seller), :new_seller_path

    @user = current_user
    @seller = @user.build_seller({})
    #@seller.paypal_email = @user.email
  end

  def create
    if current_user.update_attributes(params[:user].merge(:reset => 0))
      notify(:type => "success", :title => t(:register_process), :message => t(:seller_registered))
      redirect_to new_store_path
    else
      notify(:type => "error", :title => t(:register_process), :message => errors_messages_for(current_user))
      @user = current_user
      @seller = @user.seller
      render "new"
    end
  end

  def show
    @seller = Seller.find_by_id(params[:id])
    unless @seller.user.suspended?
      @products = @seller.try(:store).try(:products).where(:accepted => 1).limit(10)
    else
      notify(:type => "alert", :title => t(:authenticate), :message => t(:this_user_is_suspended));
      redirect_back_or_root
    end
  end

  def rate
    @seller = Seller.find(params[:id])
    @seller.rate(params[:stars], current_user, params[:dimension])
    render :update do |page|
      page.replace_html @seller.wrapper_dom_id(params), ratings_for(@seller, params.merge(:wrap => false))
      page.visual_effect :highlight, @seller.wrapper_dom_id(params)
    end
  end

  private

  def check_if_seller?
    if current_user.seller?
      store = current_user.try(:seller).try(:store)
      if store
        redirect_to edit_store_path(current_user.try(:seller).try(:store))
      else
        redirect_back_or_root
      end
    end
  end
end

def correct_seller
    seller = Seller.find_by_id(params[:id])
    unless seller
      notify(:type => "alert", :title => t(:seller_profile), :message => t(:no_seller))
      redirect_back_or_root
    end
  end
