class InvoiceItemDatumController < ApplicationController
  before_filter :deny_if_strange_product
  before_filter :common_breadcrumbs

  def common_breadcrumbs
    add_breadcrumb I18n.t(:my_profile), {:controller => :users, :action => :show, :id => current_user.id}
    add_breadcrumb I18n.t(:my_store), {:controller => :stores, :action => :edit, :id => current_seller.store.id}
    add_breadcrumb I18n.t(:sold_products), :sold_products_path
  end

  def show;
        add_breadcrumb I18n.t(:shipping_info_view), invoice_item_datum_path(params[:id])
  end

  def edit;
        add_breadcrumb I18n.t(:shipping_info_edit), edit_invoice_item_datum_path(params[:id])
  end

  def update
    if_has_intracking_number? do
      set_additional_params
      #redirect_to sold_products_path, :page => params[:page]
      redirect_to :controller => :reporting, :action => :sold_products, :page => (params[:page]=="" ? 1 : params[:page])
    end
  end

  private

  def if_has_intracking_number?
    if params[:inv_it_data][:intracking_number][:params_value].blank?
      notify(:type => "error", :title => t(:cart_updating), :message => t("shipping_info.no_number"))
      #redirect_back_or_root
      render (:edit)
    else
      yield
    end
  end

  #Deny, when user will show the strange product
  def deny_if_strange_product
    if @payment_info = InvoiceItemData.find_by_id(params[:id])
      unless current_seller.has_product?(@payment_info.identifier_id)
        notify(:type => "error", :title => t(:reporting), :message => t(:permission))
        #redirect_back_or_root
        render (:edit)
      end
    else
      notify(:type => "alert", :title => t(:reporting), :message => t(:record_not_found))
      #redirect_back_or_root
      render (:edit)
    end
  end

  # 'Deprecated'
  def transform_date(date)
    #date[:params_value].values.join("-")
    date[:year]+"-"+date[:month]+"-"+date[:day]
  end

  def arguments
    info = params[:inv_it_data]
    status = params[:invoice_item_data][:status]
    closed = params[:invoice_item_data][:closed]
    array = info.values
    array[1][:params_value] = transform_date(array[1][:params_value])

    [@payment_info, array, status, closed]
  end

  def set_additional_params
    @args = arguments
    InvoiceItemData.set_additional_params(*@args)

    @buyer = @args[0].receiver_option.payment_option.sender
    @product_names = InvoiceItemData.parallel_datum(@args[0]).map{|i| i.identifier.name}.join(", ")
    @store = InvoiceItemData.parallel_datum(@args[0]).first.identifier.store.name
  rescue => error
    notify(:type => "error", :title => t(:cart_updating),
           :message => t("shipping_info.no_update").concat(' ' + error))
  else
    notify(:type => "success", :title => t(:cart_updating), :message => t("shipping_info.updated"))
    UserMailer.buyer_shipping_info(@buyer, @args, @product_names, @store).deliver
  end
end
