class PaymentsController < ApplicationController
  require 'adaptive_payment'
  require 'payment'
  include AdaptivePayment

  before_filter :validate_cart, :only => [:return_from, :index] #:only => :create
  before_filter :authenticate, :except => [:return_from_preapproval, :cancel]
  before_filter :initialize_cart, :only => [:return_from, :index]

  def return_from_feature
    @product = Product.find_by_id(params[:id])
    if @product && @product.seller.user == current_user
      render :layout => false
    else
      Rails.logger.info "user don't own that product"
      render :nothing => true
    end
  end

  def return_from_preapproval
    render :nothing => true
  end


  def cancel
    render :layout => false
  end

  def return_from
    if params[:id] && current_user
      payment_option = current_user.payment_options.find_by_check_id(params[:id])
      if payment_option
        payment_details_req = AdaptivePayment::PaymentDetails.new({"payKey" => payment_option.pay_key})
        payment_details = payment_details_req.fetch
        payment_option.update_attribute(:check_info, (payment_details.blank? ? {"status" => "fetch failed"} : payment_details))


        begin
          shipping_address_response = AdaptivePayment::GetShippingAddress.new({"key" => payment_option.pay_key}).fetch
          buyers_address = shipping_address_response["selectedAddress"]
        rescue
          buyers_address = {"city"=>"", "line1"=>"", "line2"=>"", "countryCode"=>"", "postalCode"=>"", "state"=>""}
        end

        if payment_details && payment_details["status"] == "COMPLETED"
          mails = AdaptivePayment::Mailer.new(payment_option, payment_details, buyers_address) unless payment_details["preapprovalKey"]
          ActiveRecord::Base.transaction do
            present_line_items = LineItem.find_all_by_id(payment_option.params["items"]).map(&:id)
            AdaptivePayment.delete_from_cart(present_line_items)
          end
          mails.deliver unless payment_details["preapprovalKey"]
        end
      end
    end
    LineItem.uncached do
      @cart_items = nil
      current_user.clear_association_cache()
      validate_cart
      @cart_items.sort! {|x,y| x.item_type.product.store.seller.id <=> y.item_type.product.store.seller.id}
      @all_cost = cart_items_cost
    end
    render :layout => false
  end

  def index
    add_breadcrumb I18n.t(:cart), :cart_items_path

    @cart_items.sort! {|x,y| x.item_type.product.store.seller.id <=> y.item_type.product.store.seller.id}
    @all_cost = cart_items_cost
  end


  def create
    validate_cart(params[:line_items])
    cookies[:flash] = []
    if @cart_data[:valid]
      if @cart_items.count == 0
        notify(:type => "alert", :title => "Nothing to checkout", :message => "Your cart is empty")
        render "reset"
      else
        payment = AdaptivePayment::Items.new(@cart_items, @cart_data, current_user, request.server_name)
        process_payment(payment)
      end
    else
      notify(:type => "alert", :title => "Not valid", :message => "Condition of the cart is not valid")
      render "carts/validate"
    end
  end


  def features
    product = Product.find_by_id(params[:id])
    if product && product.seller.user == current_user
      if product.subtotal[:total] > 0
        payment = AdaptivePayment::Features.new(product.subtotal, current_user, return_from_feature_payment_path(product.id))
        process_payment(payment)
      else
        @product = product
        notify(:type => "alert", :title => "Nothing to pay for", :message => "First you should select some features")
        render "reset_feature"
      end
    else
      render :nothing => true
    end
  end








  private


    def process_payment(payment)
      preapproval_simulator = {:simulate => true, :disabled => false}


      if preapproval_simulator[:simulate] || payment.build_approval_key
        if preapproval_simulator[:disabled] && payment.approval_key_data && payment.approval_key_data["approved"]
          if payment.exec_preapproved
            if payment.is_a?(AdaptivePayment::Items)
              transaction = {}
              payment.sellers.each_with_index do |seller, index|
                transaction.merge!("#{index}" => {".receiver" => "#{seller.paypal_email}"})
              end
              mails = AdaptivePayment::Mailer.new(PaymentOption.find_by_pay_key(payment.pay_key_data["payKey"]), transaction)
              mark_cart_as_purchased
              mails.deliver
            else
              mark_features_as_purchased(payment.tech_details)
            end
            notify(:type => "success", :title => "Ok", :message => "Payment was successfuly completed!")
            render payment.return_from
          else
            Rails.logger.info "fetch pay key failed"
            notify(:type => "error", :title => "Failure", :message => "Connecting to PayPal failed")
            render "reset"
          end
        else
          Rails.logger.info "executing payment without preapproval"
          if payment.build_pay_key
            @pay_key_data = payment.pay_key_data
            @approval_key_data = payment.approval_key_data if preapproval_simulator[:disabled]
            render 'create'
          else
            Rails.logger.info "fetch pay key failed"
            notify(:type => "error", :title => "Failure", :message => "Connecting to PayPal failed")
            render "reset"
          end
        end
      else
        Rails.logger.info "fetch preapproval key failed"
        notify(:type => "error", :title => "Failure", :message => "Connecting to PayPal failed")
        render "reset"
      end
    end




    def mark_cart_as_purchased
      if AdaptivePayment.delete_from_cart(@cart_items.map(&:id))
        LineItem.uncached do
          current_user.clear_association_cache()
          validate_cart
          @cart_items.sort! {|x,y| x.item_type.product.store.seller.id <=> y.item_type.product.store.seller.id} if @cart_items.count > 2
          @all_cost = cart_items_cost
        end
      else
        Rails.logger.info("Deleting cart items failed")
      end
    end


    def mark_features_as_purchased(tech_details)
      if AdaptivePayment.delete_purchased_features(tech_details)
        Product.uncached do
          @product = Product.find_by_id(params[:id])
        end
      else
        Rails.logger.info("Deleting cart items failed")
      end
    end








end
