ActiveAdmin.register Currency do
  
end
