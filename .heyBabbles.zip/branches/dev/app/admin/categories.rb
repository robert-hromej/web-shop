ActiveAdmin.register Category do
  index do
    column :id
    column :title
    column "Level", :sortable => :level do |record|
      case record.level
        when 1
          "Category"
        when 2
          "Subcategory"
        when 3
          "Gender"
        when 4
          "Size"
        else
          "Color"
      end
    end

    default_actions
  end

end
