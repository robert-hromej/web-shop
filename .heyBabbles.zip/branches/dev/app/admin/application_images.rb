ActiveAdmin.register ApplicationImage do

  index do
    column :description
    column "File name", :image_file_name
    column :image_file_name do |image|
      image_tag(image.image.url(:medium))
    end
    default_actions
  end

end
