ActiveAdmin.register FeaturedVendor do
  form do |f|
      f.inputs "New Featured Vendor" do
        f.input :seller
        f.input :start_date, :as => :string, :input_html => {:class => 'datepicker my_datapicker'}
        f.input :end_date, :as => :string, :input_html => {:class => 'datepicker my_datapicker'}
      end
        f.buttons
    end

end
