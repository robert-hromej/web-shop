ActiveAdmin.register Configuration do
  
end
