ActiveAdmin.register Product do
  scope :all
  scope "Used Products", :all_used
  scope :not_accepted
  scope :rejected
  scope :not_finished
  index do
    column :name
    column :new
    #column :accepted
    column :accepted do |product|
      if product.accepted == 1
        link_to "Reject", :action => :reject, :id => product.id
      elsif product.accepted == nil
        "Not finished"
      else
        link_to "Accept", :action => :accept, :id => product.id
      end
    end
    column :price
    column :description
    column :return_policy
    #column :ship_from_id
    column :image_file_name do |product|
      unless product.main_image.nil?
        image_tag(product.main_image.image.url(:thumb))
      end
    end
    column "Actions" do |post|
      links = link_to "View", admin_product_path(post), :class => "member_link view_link"
      links += link_to "Edit", edit_admin_product_path(post), :class => "member_link edit_link"
      links
    end
  end

  member_action :accept, :method => :put do
    product = Product.find(params[:id])
    product.update_attributes(:accepted => 1)

    if product.save
      flash[:notice] = "Accepted!"
      redirect_to :action => :show
    else
      flash[:error] = "Something was wrong. Product not accepted!"
      redirect_to :action => :show
    end
  end

  member_action :reject, :method => :put do
    product = Product.find(params[:id])
    product.update_attributes(:accepted => 0)

    if product.save
      flash[:notice] = "Rejected!"
      redirect_to :action => :show
    else
      flash[:error] = "Something was wrong. Product not rejected!"
      redirect_to :action => :show
    end
  end


end
