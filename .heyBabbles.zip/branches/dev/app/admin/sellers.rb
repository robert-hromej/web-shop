ActiveAdmin.register Seller do

  index do
    column :id
    column :first_name
    column :last_name

    column do |seller|
      if seller.is_featured?
        "Featured"
      else
        link_to "Set featured", :action => :set_featured, :id => seller.id
      end
    end


    default_actions
  end

  member_action :set_featured do
    if !params[:featured_vendor]
      start_date = FeaturedVendor.select("end_date").last.nil? ? Date.today : FeaturedVendor.select("end_date").last.end_date + 1.day

      @vend = FeaturedVendor.new(:start_date => start_date, :end_date => start_date)
    else
      @vend = FeaturedVendor.new(:seller_id => params[:id])
      if @vend.update_attributes(params[:featured_vendor])
        flash[:notice] = "Featured vendor was successfully saved"
        redirect_to :action => :index
      else
        flash[:error] = "Error saving featured vendor. #{humanize(@vend.errors)} "
        redirect_to :back
      end
    end
  end

end
