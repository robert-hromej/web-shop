ActiveAdmin.register Combination do

  index do
    column :id
    column "Category", :category
    column "Subcategory", :subcategory
    column "Gender",:gender
    default_actions
  end

  form do |f|
      f.inputs "New combination" do
        f.input :category
        f.input :subcategory
        f.input :gender
      end
        f.buttons
  end

  member_action :destroy, :method => :put do
      if Combination.in_use(params[:id]).any?
        flash[:error] = "Combination can't be deleted. Exist items with this combination!"
        redirect_to :action => :index
      else
        Combination.find_by_id(params[:id]).destroy
        flash[:notice] = "Combination and dependent Combination Sc are successfully deleted."
        redirect_to :action => :index
      end
    end
end
