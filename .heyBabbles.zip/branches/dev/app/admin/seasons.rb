ActiveAdmin.register Season do

  index do
    column :title
    column :description
    column :start_date
    column :end_date
    column :cost
    column "Active" do |season|
      status_tag (season.is_active? ? "Active" : "Inactive"), (season.is_active? ? :ok : :error)
    end
    column "File name", :banner_file_name
    column "Banner", :banner_file_name do |image|
      image_tag(image.banner.url(:thumb))
    end
    default_actions
  end

  show do
    panel "Season" do
      attributes_table_for season do
        row("Title") { season.title }
        row("Description") { season.description }
        row("Status") { status_tag (season.is_active? ? "Active" : "Inactive"), (season.is_active? ? :ok : :error) }
        row("Start date") { season.start_date}
        row("Cost") { season.cost}
        row("End date") { season.end_date}
        row("Banner file name") { season.banner_file_name}
        row("Banner image") { image_tag(season.banner.url(:medium)) }
      end
    end
  end


  form :html => { :enctype => "multipart/form-data" } do |f|
    f.inputs "Details" do
      f.input :title
      f.input :description
      f.input :start_date, :as => :date
      f.input :end_date, :as => :date
      f.input :cost
      f.input :banner, :as => :file
    end
      f.buttons
  end
end
