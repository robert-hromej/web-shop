ActiveAdmin.register User do
  scope :all
  scope :suspended
  scope :active
  index do
    column :id
    column :username
    column :email
    column :facebook_uid
    column :facebook_email
    column :registered do |user|
      if user.registered
        "Yes"
      else
        link_to "Set registered", :action => :set_registered, :id => user.id
      end
    end
    column :gender do |gender|
      if gender.gender == 0
        "Male"
      elsif gender.gender == 1
        "Female"
      end
    end
    column "Suspended" do |user|
      if user.suspended?
        link_to "Activate", :action => :set_active, :id => user.id
      else
        link_to "Suspend User", :action => :set_suspend, :id => user.id
      end
    end
    #default_actions :except => [:delete]
    column "Actions" do |resource|
      links = link_to I18n.t('active_admin.view'), resource_path(resource), :class => "member_link view_link"
      links += link_to I18n.t('active_admin.delete'), resource_path(resource), :method => :delete, :confirm => I18n.t('active_admin.delete_confirmation'), :class => "member_link delete_link"
      links
    end
  end


  form do |f|
    f.inputs "Details" do
      f.input :suspended
      f.input :id
      f.input :username
      f.input :email
      f.input :registered
      f.input :gender
      f.input :birthday
      f.input :newsletter
      f.input :about
    end
    f.buttons
  end

  member_action :set_registered do
    @user = User.find_by_id(params[:id])
    if @user.update_attributes(:registered => true, :reset => 0)
      flash[:notice] = "User was successfully registered"
      redirect_to :action => :index
    else
      flash[:error] = "Error registering user. #{humanize(@user.errors)} "
      redirect_to :back
    end
  end

  member_action :set_active do
    @user = User.find_by_id(params[:id])
    if @user.update_attributes(:suspended => false, :reset => 0)
      flash[:notice] = "User was successfully activated"
      redirect_to :action => :index
    else
      flash[:error] = "Error registering user. #{humanize(@user.errors)} "
      redirect_to :back
    end
  end

  member_action :set_suspend do
    @user = User.find_by_id(params[:id])
    if @user.update_attributes(:suspended => true, :reset => 0)
      flash[:notice] = "User was successfully suspended"
      redirect_to :action => :index
    else
      flash[:error] = "Error registering user. #{humanize(@user.errors)} "
      redirect_to :back
    end
  end

end
