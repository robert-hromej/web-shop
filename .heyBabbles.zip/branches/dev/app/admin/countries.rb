ActiveAdmin.register Country do

  form do |f|
    f.inputs "Create title" do
      f.input :title
    end
    f.inputs "Country type" do
      f.select(:country_type, Country::COUNTRY_TYPE)
    end
    f.buttons
  end

end
