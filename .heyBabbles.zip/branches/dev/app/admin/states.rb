ActiveAdmin.register State do
  
end
