ActiveAdmin.register CombinationCs do

  #form :partial => "form"


  index do
    column :id
    column "Category", :combination do |combination|
      Category.find_by_sql("SELECT *
      FROM `categories`, `combinations`
      WHERE `combinations`.`category_id` = `categories`.`id` and `combinations`.`id` = #{combination.combination_id}").try(:first).try(:title)
    end
    column "Subcategory", :combination do |combination|
      Category.find_by_sql("SELECT *
      FROM `categories`, `combinations`
      WHERE `combinations`.`subcategory_id` = `categories`.`id` and `combinations`.`id` = #{combination.combination_id}").try(:first).try(:title)
    end
    column "Gender", :combination do |combination|
      Category.find_by_sql("SELECT *
      FROM `categories`, `combinations`
      WHERE `combinations`.`gender_category_id` = `categories`.`id` and `combinations`.`id` = #{combination.combination_id}").try(:first).try(:title)
    end
    column "Size", :size do |size|
      Category.find_by_id(size.size_id).title
    end
    column "Color", :color do |color|
      Category.find_by_id(color.color_id).title
    end

    default_actions
  end

  form do |f|
    f.inputs "New combination" do
      f.input :cat_1, :as => :select, :collection => Category.where(:level => 1)
      f.input :cat_2, :as => :select, :collection => Category.where(:level => 2)
      f.input :cat_3, :as => :select, :collection => Category.where(:level => 3)
      f.input :size, :as => :check_boxes, :collection => Category.where(:level => 4)
      f.input :color, :as => :check_boxes, :collection => Category.where(:level => 5)
    end
    f.buttons
  end

  member_action :destroy, :method => :put do
    if CombinationCs.in_use(params[:id]).any?
      flash[:error] = "Size and Color combination can't be deleted. Exist items with this combination!"
      redirect_to :action => :index
    else
      CombinationCs.find_by_id(params[:id]).destroy
      flash[:notice] = "Size and Color combination are successfully deleted."
      redirect_to :action => :index
    end
  end

  member_action :create, :method => :put do
    combination_id = Combination.select(:id).where(:category_id => params[:combination_cs][:cat_1],
                                                   :subcategory_id => params[:combination_cs][:cat_2],
                                                   :gender_category_id => params[:combination_cs][:cat_3]).first.id

    sizes = params[:combination_cs][:size]
    colors = params[:combination_cs][:color]

    begin
      ActiveRecord::Base.transaction do
        sizes.each do |size|
          colors.each do |color|
            if (color.to_i != 0) && (size.to_i != 0)
              CombinationCs.find_or_create_by_combination_id_and_color_id_and_size_id(:combination_id => combination_id,
                                                                                      :size_id => size.to_i,
                                                                                      :color_id => color.to_i)
            end
          end
        end
        flash[:notice] = "Color and size combination are successfully saved"
        redirect_to :action => :index
      end
    rescue
      flash[:error] = "Error saving color and size combination. #{humanize(@comb_cs.errors)} "
      redirect_to :back
    end

  end

  member_action :dynamic_categories do
    @categories = {}
    #    creates hash for dynamic_categories like {"1"=>{"2"=>[3, 4],"6"=>[3,8]},"5"=>{"6"=>[3,8]}}
    #    where keys in the parent hash are a category_id's keys in the second hash are a subcategory_id's
    #    and arrays contain all relative gender id's
    #
    Combination.all.each do |combination|
      category_id = combination.category_id.to_s
      subcategory_id = combination.subcategory_id.to_s
      gender_id = combination.gender_category_id

      @categories.merge!(category_id => {}) if @categories[category_id].nil?
      unless @categories[category_id][subcategory_id].nil?
        @categories[category_id][subcategory_id] << gender_id
      else
        @categories[category_id].merge!(subcategory_id => [gender_id])
      end
    end
    render :layout => false
  end

end
