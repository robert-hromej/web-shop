class UserMailer < ActionMailer::Base
  helper :application
  default :from => 'support@purplepail.com'

  def create_welcome_mail(user)
    mail(:to => user.email, :subject => "Registered")
  end

  def password_reset_mail(user)
    @user = user
    mail(:to => user.email, :subject => "Reset Password")
  end

  def confirm_email(user)
    @user = user
    mail(:to => user.email, :subject => "Confirm Email")
  end

  def rescue_mail(error)
    mail(:to => ["tom.koptel@gmail.com", "kedgark@gmail.com", "slawikdft@gmail.com"], :subject => "Error Happened")
  end

  def product_created(user, product)
    @user = user
    @product = product
    mail(:to => user.email, :subject => "Product was created #{product.name}")
  end

  def product_approved(user, product)
    @user = user
    @product = product
    mail(:to => user.email, :subject => "Product was approved #{product.name}")
  end

  def product_not_approved(user, product)
    @user = user
    @product = product
    mail(:to => user.email, :subject => "Product was rejected #{product.name}")
  end

  def user_suspended(user)
    @user = user
    mail(:to => user.email, :subject => "Your account is suspended!")
  end

  def user_not_suspended(user)
    @user = user
    mail(:to => user.email, :subject => "Your account activated!")
  end

  def product_expires_5_days(user, product)
    @user = user
    @product = product
    mail(:to => user.email, :subject => "Product expires in 5 days #{product.name}")
  end

  def product_expires_1_day(user, product)
    @user = user
    @product = product
    mail(:to => user.email, :subject => "Product expires in 1 day #{product.name}")
  end

  def product_has_expired(user, product)
    @user = user
    @product = product
    mail(:to => user.email, :subject => "Product has expired #{product.name}")
  end

  def seller_order_details(seller, products, buyer, buyers_address)
    @seller = seller
    @products = products
    @buyer = buyer
    @buyers_address = buyers_address
    mail(:to => seller.user.email, :subject => "Order details")
  end

  def buyer_order_details(buyer, products)
    @buyer = buyer
    @products = products
    mail(:to => buyer.email, :subject => "Order details")
  end

  def buyer_shipping_info(buyer, parameters, product_names, store)
    @buyer = buyer
    @parameters = parameters
    @store = store
    @product_names = product_names.split(",")

    mail(:to => buyer.email, :subject => "Shipping info")
  end

  def buyer_feedback_reminder(buyer, products)
    @buyer = buyer
    hash = {}
    products.map! do |prod|
      store = prod.item_type.product.store.name
      store_id = prod.item_type.product.store.id
      if hash[("s"+"#{store_id}").to_sym].nil?
        hash.merge!(("s"+"#{store_id}").to_sym => {:store_name => store, :products => [prod.item_type.product]})
      else
        hash[("s"+"#{store_id}").to_sym][:products] << prod.item_type.product
      end
    end
    @products_hash = hash

    mail(:to => buyer.email, :subject => "Feedback Reminder")
  end
end
