module HomeHelper
  def new?(product)
    product.new ? "New" : "Used"
  end

  def seller_fullname
    title = "Featured Vendor"
    @seller.nil? ? title : title + (": " + @seller.fullname)
  end

  def random_active_season
    @html = ''
    season = Season.active_seasons.sort_by{rand}.first
      unless season.blank?
        @html << "#{link_to image_tag(season.banner.url(:medium)),"products?season=#{season.id}"}"
      end
    raw(@html)
  end

end
