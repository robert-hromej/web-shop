module CategoriesHelper
  def list(categories, season = nil, parent_category_path = {})

    html = ""

    categories.values.each do |category|
      html << "<div>"
      #html << "*" * (category[:level]-1)

      category_path = parent_category_path.dup
      category_path[category[:category][1]] = category[:category][2]
      category_path[:season] = season.id if season

      html << "<div class='node open'></div>" if category[:category][0] == 1
      html << "<div class='node closed'></div>" if category[:children] and !(category[:category][0] == 1)

      html << link_to(truncate(category[:category][3], :length => 25), full_category_path(category_path), :title => category[:category][3])

      if category[:children]
        html << "<div class='category_child' id='#{category_child_container_id(category_path)}' style="
        if category[:category][0] == 1
          html << "''>"
        else
          html << "'display:none;'>"
        end

        html << list(category[:children], season, category_path)

        html << "</div>"
      end

      html << "</div>"
    end

    raw html
  end

end
