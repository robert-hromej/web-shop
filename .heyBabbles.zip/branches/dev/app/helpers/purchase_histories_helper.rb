module PurchaseHistoriesHelper
  def total_cost(quantity = 0, limit = 0, cost = 0, shipping_cost = 0, additional_shipping_cost = 0, tax = 0  )
    without_tax = (quantity.to_f - limit.to_f) * additional_shipping_cost.to_f + limit.to_f * shipping_cost.to_f + quantity.to_f * cost.to_f
    subtotal =  without_tax + tax.to_f
    return sprintf("%.2f", subtotal).to_f
  end
end
