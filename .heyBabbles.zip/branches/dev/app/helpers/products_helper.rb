module ProductsHelper
  def raw_tab(title, destination, action = "")
    @html = ''
    cls = 'tab '
    if params[:action]== action
      cls << 'active'
      left_img = "<img src = '/images/new_design/left_tab_active.png' >"
      link = "<a href = '#{destination}'>#{title}</a>"
      right_img = "<img src = '/images/new_design/right_tab_active.png' >"
    else
      cls << 'inactive'
      left_img = "<img src = '/images/new_design/left_tab_inactive.png' >"
      link = "<a href = '#{destination}'>#{title}</a>"
      right_img = "<img src = '/images/new_design/right_tab_inactive.png' >"
    end
    @html += "<li class = '#{cls}'>"
    @html += left_img
    @html += link
    @html += right_img
    @html += '</li>'

    raw(@html)
  end

  def br_name(name, count = 30)
    @html = ''
    @html = name

    len = name.length
    if len > count
      defis = ' '
      first_part = name.slice(0, count)
      i = first_part.rindex(' ')
      if !i.nil? && (len-i < count)
        first_part = name.slice(0, i)
        second_part = name.slice(i, len)
      else
        second_part = name.slice(count, len)
        defis = '-'
      end
      @html = first_part << defis << '<br>' << second_part
    end

    raw(@html)
  end


end
