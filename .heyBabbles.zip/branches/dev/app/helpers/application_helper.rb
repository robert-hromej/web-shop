module ApplicationHelper
  include SessionsHelper


#  <b>==DOCUMENTATION==</b>
#  <b>Gave ability simply create html tags inside helpers</b>
#
#  <b>Usage</b>
#    div.page! {
#      div.content {
#        h1 "A Short Short Saintly Dog"
#      }
#    }
#
#  <b>output</b> -->
#    <div id="page">
#      <div class="content">
#        <h1>A Short Short Saintly Dog</h1>
#      </div>
#    </div>
  def html_tags(&block)
    Markaby::Builder.new({}, self, &block)
  end

  #usage: just paste <%= title "My title "%> on your page
  #warning:IT WORKS WHEN YOU SET SCRIPLET <%= yield(:title) || "Static Title" %> IN LAYOUT
  def title(page_title)
    content_for(:title) { page_title }
  end

  #escape error if they happend
  def escape
    begin
      yield
    rescue => e
      Rails.logger.error "Error is ============> #{e}"
      Rails.logger.error e.backtrace.join("\n")
      ""
    end
    ""
  end

  #  <b>Draws the error message block</b>
  #  <em>income</em> <-- <b>object</b>
  #     - excepts object which refers to the random model one
  #  <em>outcome</em> --> <b>html</b>
  #       <div class="error">
  #          <div class="alertImg">
  #            <img src="/images/icons/error.png?1303331009" alt="Alert">
  #          </div>
  #          <div class="alertContent">
  #            <span class="header">3 errors occured!</span>
  #            <ul>
  #              <li>...some inf </li>
  #              <li>...some inf </li>
  #              <li>...some inf </li>
  #            </ul>
  #          </div>
  #     </div>
  #
  #  <b>Usage</b>
  #  <%= error_message_for @projects %>
  def error_message_for(object)
    return if object.errors.empty?
    raw(
        html_tags do
          div.error {
            div.alertImg { image_tag "icons/error.png" }
            div.alertContent! {
              span.header { "#{pluralize(object.errors.count, "error")} occured!" }
              ul {
                object.errors.full_messages.each do |msg|
                  li { msg }
                end
              }
            }
          }
        end
    )
  end

  def javascript(*files)
    content_for(:head) { javascript_include_tag(*files) }
  end

  def css(*files)
    content_for(:head) { stylesheet_link_tag(*files) }
  end

  # For facebook
  def fb_observer
    #APP_CONFIG[:shared_route] + facebook_connect_sessions_path()
    facebook_connect_sessions_path()
  end

  #TODO - following three method need refactoring
  # Redirects to register as seller form otherwise show to seller store profile
  #
  def sell_link
    if signed_in_user?
      if current_user.seller?
        #todo weired bug
        if current_user.has_store? && !current_user.store.id.nil?
          link_to t(:sell), management_products_path, :id => "Sell"
        else
          link_to t(:sell), new_store_path, :id => "Sell"
        end
      else
        link_to t(:sell), new_seller_path, :id => "Sell"
      end
    else
      link_to t(:sell), new_seller_path, :id => "Sell"
    end
  end

  # Redirects to new or edit if has_store?
  def store_account_link(name)
    if current_user.has_store? && !current_user.store.id.nil?
      link = link_to(name, edit_store_path(current_user.store), {:class => "button grey", :id => html_id(name)})
    else
      link = link_to(name, new_store_path(), {:class => "button grey", :id => html_id(name)})
    end
    link.html_safe
  end

  def seller_account_link(name)
    if current_user.has_store? && !current_user.store.id.nil?
      link = link_to(name, management_products_path, {:class => "button grey", :id => html_id(name)})
    else
      link = link_to(name, new_store_path(), {:class => "button grey", :id => html_id(name)})
    end
    link.html_safe
  end

  #returns a string that can be used as a html tag id attribute. example: Seller Account => seller_account
  def html_id(str)
    str.split(" ").join("_").downcase!
  end


  #returns a quantity of items in cart
  def items_in_cart
    if signed_in_user?
      current_user.line_items.count
    else
      if session[:cart_items]
        session[:cart_items].count
      else
        0
      end
    end
  end


  #calculates the cost of all items in cart including shipping cost
  def cart_items_cost
    item_cost = 0.0
    shipping_cost = 0.0
    total_cost = 0.0
    if signed_in_user?
      current_user.line_items.each do |line_item|
        item_cost += line_item.item_type.price * line_item.count
        shipping_cost += calculate_shipping_cost(line_item.count, line_item.ship_to)
      end
    else
      if session[:cart_items]
        session[:cart_items].each do |line_item|
          item_cost += ItemType.find_by_id(line_item.keys.first).try(:price).to_f * line_item.values.first[:count]
          shipping_cost += calculate_shipping_cost(line_item.values.first[:count], ShipTo.find_by_id(line_item.values.first[:ship_to]))
        end
      end
    end
    {:items => item_cost, :shipping => shipping_cost, :total => (item_cost + shipping_cost)}
  end


  #calculates the shipping cost from items count and destination
  def calculate_shipping_cost(cont, ship_to)
    add_cost = ship_to.additional_cost
    cost = ship_to.cost
    limit = ship_to.product_limit
    if (cont > limit)
      add_price = cost*limit + add_cost*(cont-limit)
    else
      add_price = cost*cont
    end
    add_price
  end


  def remove_obsolete_paykeys(feature = false)
    if signed_in_user?
      current_user.payment_options.find_all_by_txn_id_and_check_info_and_feature(nil,nil,feature).each do |pay_key|
        pay_key.destroy
      end
    end
  end


  def load_js_for_development
    javascript_include_tag(JSD.transform["javascripts"]["workspace"].map { |element| element.gsub("public/javascripts/", "") })
    end

  def load_css_for_development
    stylesheet_link_tag(JSD.transform["stylesheets"]["workspace"].map { |element| element.gsub("public/stylesheets/", "") })
  end

  def merge_current_params(new_params = {})
    params.dup.merge(new_params)
  end

  def show_ajax_notify
    escape_javascript("set_flash();")
  end

  # generate full path to category.
  def full_category_path(options = {})
    category = options[:category]
    if options[:season]
      season_category_path(category, options.merge({:category => nil}))
    else
      category_path(category, options.merge({:category => nil}))
    end
  end

  def category_child_container_id(options = {})
    unless options[:category].blank?
      container = "category_children"
      options.each { |key, value| container << "_" + value.to_s }
    end
    container
  end

  def list_head
    @categories_head = Category.categories_head
    if params[:show_season]
      @current_season = params[:season] ? Season.find(params[:season]) : Season.first
    end

    html = "<div id='drop_menus'>"
    html_head = "<ul class='top_nav'>"

    submenu = 1

    @categories_head.values.each do |category|
      category_path_head = {}
      category_path_head[category[:category][1]] = category[:category][2]
      category_path_head[:season] = @current_season.id if @current_season

      html << "<div id='submenu_#{submenu}' class='drop_menu'>"
      html << "<div class='left_corner'></div>"

      submenu = submenu + 1

      html_head << "<li>"
      html_head << link_to(category[:category][3], full_category_path(category_path_head))
      html_head << "<span></span></li>"

      if category[:children]
        html << "<div class='sub_body'><div class='top_arrow'></div><ul class='sub_nav'>"

        category[:children].values.each do |subcategory|
          html << "<li>"

          category_path = category_path_head.dup
          category_path[subcategory[:category][1]] = subcategory[:category][2]

          html << link_to(subcategory[:category][3], full_category_path(category_path))
          html << "</li>"
        end

        html << "</ul></div>"
      end

      html << "<div class='right_corner'></div></div>"
    end

    html_head << "</ul>"
    html << "</div>"

    html = html_head + html
    raw(html)
  end

end

