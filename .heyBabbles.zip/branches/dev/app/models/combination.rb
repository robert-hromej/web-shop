class Combination < ActiveRecord::Base

  after_save do
    begin
      File.chmod(777, "#{::Rails.root.to_s}/public/products/dynamic_categories.js")
      File.delete("#{::Rails.root.to_s}/public/products/dynamic_categories.js") if File.exists?("#{::Rails.root.to_s}/public/products/dynamic_categories.js")
    rescue
    end
  end

  attr_accessible :category_id, :gender_category_id, :subcategory_id

  belongs_to :category, :conditions => "level = 1"
  belongs_to :subcategory, :class_name => "Category", :foreign_key => :subcategory_id, :conditions => "level = 2"
  belongs_to :gender, :class_name => "Category", :foreign_key => :gender_category_id, :conditions => "level = 3"

  has_many :products
  has_many :combination_css, :dependent => :destroy

  validates_uniqueness_of :category_id, :scope => [:subcategory_id, :gender_category_id]
  validates_existence_of :category, :gender, :subcategory

  scope :in_use, lambda { |combination_id| find_by_sql("SELECT id FROM products WHERE combination_id = #{combination_id}")}

end

# == Schema Information
#
# Table name: combinations
#
#  id                 :integer(4)      not null, primary key
#  category_id        :integer(4)
#  subcategory_id     :integer(4)
#  gender_category_id :integer(4)
#

