class PaymentOption < ActiveRecord::Base

  serialize :params
  serialize :txn_id
  serialize :check_info

  attr_accessible :params, :pay_key, :user_id, :feature, :check_id, :check_info

  has_many :receiver_options, :class_name => "ReceiverOption", :foreign_key => "payment_opt_id", :dependent => :destroy
  has_many :additional_params, :class_name => "AdditionalParams", :foreign_key => "identifier_id", :as => :identifier
  has_many :products, :class_name => "InvoiceItemData"
  belongs_to :sender, :class_name => "User", :primary_key => "id", :foreign_key => "user_id"
  belongs_to :user

  validates_presence_of :params, :user_id
  validates :pay_key, :presence => true, :uniqueness => true

  def self.listing_for(seller)
    listings_array = []
    options = where(:feature => 1, :user_id => seller.user_id).order("created_at DESC")
    options.each do |option|
      cost = 0
      params = option.params["techDetails"]
      if params[:images] != 0
        unless option.try(:additional_params).empty?
          cost = option.additional_params.where(:params_name => "cost").first.params_value.to_f
          product_name = option.additional_params.where(:params_name => "product_name").first.params_value
        end
      end

      invoice_item_datums = option.try(:receiver_options).try(:first).try(:products)
      if invoice_item_datums
        invoice_item_datums.each do |datum|
          unless datum.try(:additional_params).empty?
            cost = cost + datum.additional_params.where(:params_name => "cost").first.params_value.to_f
            product_name = datum.additional_params.where(:params_name => "product_name").first.params_value
          end
        end

        id = option.id
        type = "listing"
        date = option.created_at.to_date
        listing = {:date => date, :type => type, :product_name => product_name, :id => id, :cost => cost}
        listings_array << listing
      end
    end
    return listings_array
  end

end
