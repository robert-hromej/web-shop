class Store < ActiveRecord::Base

  NAME = 100
  RETURN_POLICY = 400
  DESCRIPTION = 400
  BIO = 400

  has_attached_file :logo, :styles => {:medium => "480x320>", :thumb => "100x60>", :store => "580x65>"}
  #,
  #                         :storage => {"development" => :filesystem, "production" => :s3},
  #                         :s3_credentials => "#{RAILS_ROOT}/config/app_config.yml",
  #                         :path => ":class/:attachment/:id/:style/:basename.:extension"
  validates_attachment_size :logo, :less_than =>5.megabytes, :unless => lambda { logo_file_name.blank? }
  validates_attachment_content_type :logo, :content_type => [/^image\/(?:jpeg|gif|png|pjpeg|x-png)$/, nil], :unless => lambda { logo_file_name.blank? }

  has_many :products, :dependent => :destroy
  belongs_to :seller

  attr_accessible :name, :return_policy, :description, :bio, :logo

  validates :logo_file_name, :logo_content_type, :logo_file_size, :presence => true, :unless => lambda { logo_file_name.blank? }
  validates :name, :presence => true, :length => {:maximum => NAME}
  validates :return_policy, :presence => true, :length => {:maximum => RETURN_POLICY}
  validates :description, :presence => true, :length => {:maximum => DESCRIPTION}
  validates :bio, :presence => true, :length => {:maximum => BIO}

end

# == Schema Information
#
# Table name: stores
#
#  id                :integer(4)      not null, primary key
#  name              :string(100)
#  seller_id         :integer(4)
#  return_policy     :text
#  description       :text
#  bio               :text
#  logo_file_name    :string(255)
#  logo_content_type :string(255)
#  logo_file_size    :integer(4)
#  logo_update_at    :datetime
#  created_at        :datetime
#  updated_at        :datetime
#

