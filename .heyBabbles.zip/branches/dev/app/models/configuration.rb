class Configuration < ActiveRecord::Base


  class << self
    def get_paypal_headers
      get_config_hash(["X-PAYPAL-SECURITY-USERID", "X-PAYPAL-SECURITY-PASSWORD",
                       "X-PAYPAL-SECURITY-SIGNATURE", "X-PAYPAL-APPLICATION-ID",
                       "X-PAYPAL-DEVICE-IPADDRESS", "X-PAYPAL-REQUEST-DATA-FORMAT", "X-PAYPAL-RESPONSE-DATA-FORMAT"])
    end

    def get_endpoints
      get_config_hash(["SERVER", "PORT"])
    end

    def get_preapproval_config
      config_hash = get_config_hash(["maxAmountPerPayment", "maxNumberOfPayments",
                                     "displayMaxTotalAmount", "feesPayer",
                                     "maxTotalAmountOfAllPayments", "pinType"])
      config_hash["maxAmountPerPayment"] = config_hash["maxAmountPerPayment"].to_f
      config_hash["maxNumberOfPayments"] = config_hash["maxNumberOfPayments"].to_i
      config_hash["displayMaxTotalAmount"] = config_hash["displayMaxTotalAmount"] == "true" ? true : false
      config_hash["maxTotalAmountOfAllPayments"] = config_hash["maxTotalAmountOfAllPayments"].to_f
      return config_hash
    end

    def get_tax_new
      get_config("tax-percent-new").gsub("%", "").to_f
    end

    def get_tax_used
      get_config("tax-percent-used").gsub("%", "").to_f
    end

    def pp_account
      get_config("PurplePail-PayPal-acount")
    end

    def get_config(what)
      find_by_name(what).try(:value)
    end

    def get_config_hash(what)
      config_hash = {}
      if self.table_exists?
        find_all_by_name(what).each do |config|
          config_hash.merge!(config.name => config.value)
        end
      end
      config_hash
    end
  end


end
