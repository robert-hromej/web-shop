class Season < ActiveRecord::Base

  has_many :product_seasons, :dependent => :destroy


  if Rails.env.production?
    has_attached_file :banner,
                      :default_style => :original,
                      :styles => {:medium => "900x145", :thumb => "250x145"},
                      :storage => :s3,
                      :s3_credentials => "#{RAILS_ROOT}/config/s3.yml",
                      :url => ':id/:style/:basename.:extension',
                      :path => ':id/:style/:basename.:extension',
                      :bucket => 'PurpleDevelopment'
  else
    has_attached_file :banner,
                      :default_style => :original,
                      :styles => {:medium => "900x145", :thumb => "250x145"}
  end

  validates_attachment_size :banner, :less_than =>5.megabytes
  validates_attachment_content_type :banner, :content_type => [/^image\/(?:jpeg|gif|png|pjpeg|x-png)$/, nil]

  scope :active_seasons, where("seasons.end_date > ?", Time.now)

  def self.free_for_product(product)
    ids = product.product_seasons.collect(&:season_id)
    where(ids.blank? ? "" : "seasons.id NOT IN (#{ids.join(",")})")
  end

  def is_active?
    if self
      return self.end_date.to_time > Time.now ? true : false
    else
      return false
    end
  end

  validates_with PriceValidation, :fields => [:cost]

  with_options :presence => true do |season|
    season.validates :start_date
    season.validates :end_date
    season.validates :title, :length => {:within => 3..50}
    season.validates :cost, :numericality => true
  end

end
