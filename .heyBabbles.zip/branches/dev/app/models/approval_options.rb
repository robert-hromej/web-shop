class ApprovalOptions < ActiveRecord::Base
  attr_accessible :preapproval_key, :approved, :active, :starting_date, :ending_date, :sender_email, :pin_type, :params
  serialize :params
  belongs_to :user, :primary_key => "email", :foreign_key => "sender_email"

  validates :preapproval_key, :presence => true, :uniqueness => true
  validates_presence_of :params, :starting_date, :ending_date, :sender_email
  validates_with BooleanValidator, :fields => [:approved]

end

# == Schema Information
#
# Table name: approval_options
#
#  id              :integer(4)      not null, primary key
#  preapproval_key :string(255)     not null
#  approved        :boolean(1)      default(FALSE), not null
#  starting_date   :datetime        not null
#  ending_date     :datetime        not null
#  sender_email    :string(255)
#  pin_type        :string(255)     default("NOT_REQUIRED"), not null
#  params          :text            default(""), not null
#  created_at      :datetime
#  updated_at      :datetime
#

