class ReceiverOption < ActiveRecord::Base

  attr_accessible :payment_opt_id, :custom_id, :subtotal, :total_tax, :total_shipping

  has_many :products, :class_name => "InvoiceItemData", :dependent => :destroy

  belongs_to :seller, :foreign_key => "custom_id"
  belongs_to :payment_option, :foreign_key => "payment_opt_id"

  validates_presence_of :custom_id, :payment_opt_id
  with_options :presence => true, :numericality => true do |data|
    data.validates :subtotal
    data.validates :total_tax
    data.validates :total_shipping
  end

  #STATUSES = { "pending payment" => 1, "pending shipment" => 2, "finished" => 3}
  STATUSES = {"pending shipment" => 2, "finished" => 3}

  def self.datum_for_seller(seller_id, status)
    unless status.blank?
      conditions = "invoice_item_data.status = #{status}"
    else
      conditions = ""
    end
    self.joins(:products).where(:custom_id => seller_id || current_seller.id).where(conditions).order("created_at DESC").uniq
  end

  def products_with_item_type
    try(:products).where(:identifier_type => "Product")
  end


end