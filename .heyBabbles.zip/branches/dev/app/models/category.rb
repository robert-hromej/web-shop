class Category < ActiveRecord::Base

  after_save do
    begin
      File.chmod(777, "#{::Rails.root.to_s}/public/products/dynamic_categories.js")
      File.delete("#{::Rails.root.to_s}/public/products/dynamic_categories.js") if File.exists?("#{::Rails.root.to_s}/public/products/dynamic_categories.js")
    rescue
    end
  end

  MAIN_CATEGORIES_LEVEL = 1
  SUB_CATEGORIES_LEVEL = 2
  GENDER_CATEGORIES_LEVEL = 3
  SIZE_CATEGORIES_LEVEL = 4
  COLOR_CATEGORIES_LEVEL = 5

  #MAIN_ONE = {
  #    "Babies" => 1,
  #    "Maternity" => 2,
  #    "Daddies" => 3,
  #    "Kids" => 4
  #}

  #MAIN_ONE_NAV = ["Babies", "Maternity", "Daddies", "Kids"]

  LEVELS_SYMBOLS = {
      1 => :category,
      2 => :subcategory,
      3 => :gender,
      4 => :size,
      5 => :color
  }

  has_many :combinations, :dependent => :destroy
  has_many :sub_combinations, :class_name => 'Combination', :foreign_key => :subcategory_id
  has_many :gender_combinations, :class_name => 'Combination', :foreign_key => :gender_category_id
  has_many :color_item_types, :class_name => 'ItemType', :foreign_key => :color_category_id
  has_many :size_item_types, :class_name => 'ItemType', :foreign_key => :size_category_id
  has_many :color_cs_types, :class_name => 'CombinationCs', :foreign_key => :color_id
  has_many :size_cs_types, :class_name => 'CombinationCs', :foreign_key => :size_id

  has_many :main_products, :class_name => 'Product', :through => :combinations
  has_many :sub_products, :class_name => 'Product', :through => :sub_combinations
  has_many :gender_products, :class_name => 'Product', :through => :gender_combinations
  has_many :size_products, :class_name => 'Product', :through => :size_item_types
  has_many :color_products, :class_name => 'Product', :through => :color_item_types

  attr_accessible :title, :level
  validates_presence_of :title

  scope :main_categories, where(:level => MAIN_CATEGORIES_LEVEL)
  scope :sub_categories, where(:level => SUB_CATEGORIES_LEVEL)
  scope :gender_categories, where(:level => GENDER_CATEGORIES_LEVEL)
  scope :color_categories, lambda { |product_id|
      find_by_sql("SELECT DISTINCT combination_cs.color_id as id, categories.title
                   FROM products, combination_cs, categories
                   WHERE products.id = #{product_id} AND products.combination_id = combination_cs.combination_id AND combination_cs.color_id = categories.id ORDER BY products.id DESC") }
  #scope :color_categories, where(:level => COLOR_CATEGORIES_LEVEL)
  scope :size_categories, lambda { |product_id|
      find_by_sql("SELECT DISTINCT combination_cs.size_id as id, categories.title
                   FROM products, combination_cs, categories
                   WHERE products.id = #{product_id} AND products.combination_id = combination_cs.combination_id AND combination_cs.size_id = categories.id ORDER BY products.id DESC") }
  #scope :size_categories, where(:level => SIZE_CATEGORIES_LEVEL)

  class << self
    def categories_tree
      all_comb = Category.find_by_sql("SELECT c.category_id, c.subcategory_id, c.gender_category_id, cs.size_id, cs.color_id
                                        FROM combinations c, combination_cs cs
                                        WHERE c.id = cs.combination_id
                                        ORDER BY 1, 2, 3, 4, 5")

      categories = Category.all.inject({}){ |hash, cat| hash[cat.id.to_s] = cat.title; hash }

      main_tree = {}

      all_comb.each do |item|
        unless main_cat = main_tree[item.category_id]
          main_cat = {}
          main_cat[:children] = {}
          main_cat[:category] = [ 1, :category, item.category_id, categories[item.category_id] ]
          main_tree[item.category_id] =  main_cat
        end

        unless sub_cat = main_cat[:children][item.subcategory_id]
          sub_cat = {}
          sub_cat[:children] = {}
          sub_cat[:category] = [ 2, :subcategory, item.subcategory_id, categories[item.subcategory_id] ]
          main_cat[:children][item.subcategory_id] = sub_cat
        end

        unless gen_cat = sub_cat[:children][item.gender_category_id]
          gen_cat = {}
          gen_cat[:children] = {}
          gen_cat[:category] = [ 3, :gender, item.gender_category_id, categories[item.gender_category_id] ]
          sub_cat[:children][item.gender_category_id] = gen_cat
        end

        unless size_cat = gen_cat[:children][item.size_id]
          size_cat = {}
          size_cat[:children] = {}
          size_cat[:category] = [ 4, :size, item.size_id, categories[item.size_id] ]
          gen_cat[:children][item.size_id] = size_cat
        end

        unless color_cat = size_cat[:children][item.color_id]
          color_cat = {}
          color_cat[:category] = [ 5, :color, item.color_id, categories[item.color_id] ]
          size_cat[:children][item.color_id] = color_cat
        end
      end

      return  main_tree
    end

    def categories_head
      all_comb = Category.find_by_sql("SELECT c.category_id, c.subcategory_id
FROM combinations c, combination_cs cs
WHERE c.id = cs.combination_id
ORDER BY CASE c.category_id WHEN 2 THEN 4
WHEN 1 THEN 3
WHEN 4 THEN 2
WHEN 3 THEN 1
ELSE 5 END")

      categories = Category.all.inject({}){ |hash, cat| hash[cat.id.to_s] = cat.title; hash }

      main_tree = {}

      all_comb.each do |item|
        unless main_cat = main_tree[item.category_id]
          main_cat = {}
          main_cat[:children] = {}
          main_cat[:category] = [ 1, :category, item.category_id, categories[item.category_id] ]
          main_tree[item.category_id] =  main_cat
        end

        unless sub_cat = main_cat[:children][item.subcategory_id]
          sub_cat = {}
          sub_cat[:category] = [ 2, :subcategory, item.subcategory_id, categories[item.subcategory_id] ]
          main_cat[:children][item.subcategory_id] = sub_cat
        end
      end

      return  main_tree
    end
  end

end

# == Schema Information
#
# Table name: categories
#
#  id    :integer(4)      not null, primary key
#  title :string(255)
#  level :integer(4)
#

