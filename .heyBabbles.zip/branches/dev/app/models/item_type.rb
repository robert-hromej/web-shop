class ItemType < ActiveRecord::Base

  MIN_PRICE_FOR_USED = Configuration.get_config('min_price_for_used').to_f
  acts_as_paranoid


  belongs_to :color, :class_name => 'Category', :foreign_key => :color_category_id
  belongs_to :size, :class_name => 'Category', :foreign_key => :size_category_id
  belongs_to :product

  has_many :combinations, :through => :product
  has_many :line_items, :dependent => :destroy

  delegate :title, :to => :color, :prefix => true
  delegate :title, :to => :size, :prefix => true

  scope :for_product, lambda { |product_id| where(:product_id => product_id).where('item_count > 0') }

  validates_existence_of :product, :color, :size
  validates :price, :numericality => {:greater_than_or_equal_to => 0.01}
  validates :price, :numericality => {:less_than_or_equal_to => 10000}
  #validates :price,:numericality => {:greater_than_or_equal_to =>  MIN_PRICE_FOR_USED}, :unless => Product.find_by_id(:product_id).try(:new)
  validates_with UsedItemsPriceValidation
  #, :allow_blank => false
  validates_with PriceValidation, :fields => [:price]
  validates_numericality_of :item_count, :greater_than => 0, :less_than_or_equal_to => 1000000, :allow_blank => false, :only_integer => true

  after_save :set_min_product_price
  after_destroy :set_min_product_price

  def set_min_product_price
    min_price = ItemType.where("product_id = #{self.product_id}").minimum(:price)
    min_count = ItemType.where("product_id = #{self.product_id}").where("item_count > 0").all
    if min_count.blank?
      Product.find_by_id(self.product_id).update_attribute(:accepted, nil)
    end
    unless min_price.blank?
      Product.find_by_id(self.product_id).update_attribute(:price, min_price)
    end
  end

  def self.find_or_create(product_id, size_category_id, color_category_id)
    params = {}

    params[:product_id] = product_id
    params[:size_category_id] = size_category_id
    params[:color_category_id] = color_category_id

    item_type = with_deleted.where(params).first || new(params)
    item_type.deleted_at = nil

    item_type
  end

end

# == Schema Information
#
# Table name: item_types
#
#  id                :integer(4)      not null, primary key
#  product_id        :integer(4)
#  price             :integer(4)
#  item_count        :integer(4)
#  other_color       :string(255)
#  deleted_at        :datetime
#  color_category_id :integer(4)      not null
#  size_category_id  :integer(4)      not null
#

