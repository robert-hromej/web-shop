class ApplicationImage < ActiveRecord::Base

  MAX_IMAGES_PER_PRODUCT = 8
  #PRICE_ONE_IMAGE = 123.45
  #PRICE_ONE_IMAGE = Configuration.get_config('price_one_image').to_f

  belongs_to :product

  if Rails.env.production?
    has_attached_file :image,
                      :default_style => :original,
                      :styles => {:medium => "300x300>", :thumb => "100x100>", :large => "800x600>"},
                      :storage => :s3,
                      :s3_credentials => "#{RAILS_ROOT}/config/s3.yml",
                      :url => ':id/:style/:basename.:extension',
                      :path => ':id/:style/:basename.:extension',
                      :bucket => 'PurpleDevelopment'
  else
    has_attached_file :image,
                      :default_style => :original,
                      :styles => {:medium => "300x300>", :thumb => "100x100>", :large => "800x600>"}
                      #:url => ':id/:style/:basename.:extension',
                      #:path => ':id/:style/:basename.:extension'
  end

  validates_attachment_size :image,
                            :less_than => 5.megabytes

  validates_attachment_content_type :image,
                                    :content_type => [/^image\/(?:jpg|gif|png|jpeg|x-png)$/, nil]
  validates_existence_of :product
  validates_presence_of :image_content_type, :image_file_name, :image_file_size
  validates_uniqueness_of :product_id, :scope => [:position]
  validate :count_of_images, :on => :create

  scope :images_for_product, lambda { |product_id| where(:product_id => product_id) }

  before_create :set_position
  after_create :create_main_image

  after_destroy do |record|
    product = record.product
    if product.main_image_id == record.id
      product.main_image_id = product.images.first.try(:id) || 0
      product.save
    end
  end

  def set_as_the_main
    self.product.update_attribute(:main_image_id, self.id)
  end

  private

  def count_of_images
    if ApplicationImage.images_for_product(product_id).count >= MAX_IMAGES_PER_PRODUCT
      errors.add(:base, "you can not upload more then #{MAX_IMAGES_PER_PRODUCT} images per 1 product ")
    end
  end

  def set_position
    last_product_image = self.class.images_for_product(product_id).last
    self.position = (last_product_image.try(:position) || 0) + 1
  end

  def create_main_image
    product = self.product
    unless product.has_main_image?
      product.update_attribute(:main_image_id, self.id)
    end
  end
end

# == Schema Information
#
# Table name: application_images
#
#  id                 :integer(4)      not null, primary key
#  product_id         :integer(4)
#  description        :text
#  position           :integer(4)      not null
#  image_file_name    :string(255)
#  image_content_type :string(255)
#  image_file_size    :integer(4)
#  image_updated_at   :datetime
#

