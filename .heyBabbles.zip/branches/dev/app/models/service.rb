class Service < ActiveRecord::Base

  TYPE = {
      :home => 1,
      :search => 2
  }

  has_many :product_counters, :foreign_key => "service_type", :primary_key => "service_type"

  with_options :numericality => {:greater_than_or_equal_to => 0, :only_integer => true} do |service|
    service.validates :points
    service.validates :service_type
  end

  validates_with PriceValidation, :fields => [:price]
  validates :title, :length => {:within => 3..50}, :presence => true
  validates :price, :numericality => {:greater_than_or_equal_to => 0.01}
  validates_presence_of :points, :service_type, :title, :price

end

# == Schema Information
#
# Table name: services
#
#  id           :integer(4)      not null, primary key
#  title        :string(255)
#  description  :text
#  price        :float
#  points       :integer(4)
#  service_type :integer(4)
#

