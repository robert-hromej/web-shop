class Address < ActiveRecord::Base

  CITY = 30
  PHONE = 20
  STREET = 50
  ZIP = 20

  belongs_to :user
  belongs_to :country
  belongs_to :state

  with_options :unless => :skip? do |address|
    address.validates :zip, :phone, :street, :city, :presence => true
    #TODO prepare validate country and state is scope for address
    #validates_each :country_id do |record, attr, value|
    #  unless Country.base_shippings.select(:id).collect(&:id).include?(value)
    #    record.errors.add(attr, "is out of scope for address")
    #  end
    #end
    validates_each :country_id do |record, attr, value|
      unless Country.base_shippings.select(:id).collect(&:id).include?(value)
        record.errors.add(attr, "is out of scope for address")
      end unless value.to_s.empty?
    end
    validates_each :state_id do |record, attr, value|
      unless State.where(:id => value).select(:country_id).collect(&:country_id).include?(record.country_id)
        record.errors.add(attr, "is out of scope for country")
      end unless value.to_s.empty?
    end
    address.validates :city, :length => {:maximum => CITY}
    address.validates :street, :length => {:maximum => STREET}
    address.validates :zip, :numericality => true, :length => {:maximum => ZIP}
    address.validates :phone, :length => {:maximum => PHONE}

    address.validates :country_id, :state_id, :presence => true, :numericality => true
  end
  #TODO fix this validates with accepted nested attributes
  #validates :user_id, :presence => true, :uniqueness => true, :existence => true

  def full_address
    adr = [self.try(:country).try(:title), self.try(:city), self.try(:street), self.try(:zip)]
    adr.compact!
    adr.join(", ")
  end

  private

  # If you pass skip attr with then validations
  # will be skipped
  #
  def skip?
    !self.try(:user).try(:seller?)
  end

end

# == Schema Information
#
# Table name: addresses
#
#  id         :integer(4)      not null, primary key
#  state_id   :integer(4)
#  country_id :integer(4)
#  user_id    :integer(4)
#  zip        :string(255)
#  city       :string(255)
#  street     :string(255)
#  phone      :string(255)
#

