class CombinationCs < ActiveRecord::Base
  #belongs_to :category
  belongs_to :combination
  belongs_to :color_cs, :class_name => 'Category', :foreign_key => :color_id
  belongs_to :size_cs, :class_name => 'Category', :foreign_key => :size_id

  scope :for_new_product, lambda { |combination_id| where(:combination_id => combination_id) }
  scope :in_use, lambda { |combination_id| find_by_sql("SELECT DISTINCT products.combination_id, item_types.color_category_id, item_types.size_category_id, combination_cs.id
      FROM products, item_types, combination_cs
        WHERE products.id = item_types.product_id
        AND (products.combination_id, item_types.color_category_id, item_types.size_category_id, combination_cs.id)
        IN
          (SELECT combination_id, color_id, size_id, id
            FROM combination_cs
              WHERE id = #{combination_id})")}

  def color

  end

  def size

  end

  def category_id

  end

  def cat_1

  end

  def cat_2

  end

  def cat_3

  end
end
