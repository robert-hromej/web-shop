class InvoiceItemData < ActiveRecord::Base

  self.per_page = 12

  attr_accessor :clone_info
  attr_accessible :item_price, :price, :item_count, :payment_option_id, :identifier_id, :identifier_type, :receiver_option_id, :status

  belongs_to :identifier, :primary_key => "id", :foreign_key => "identifier_id", :polymorphic => true
  belongs_to :receiver_option
  belongs_to :payment_option

  has_many :additional_params, :class_name => "AdditionalParams", :foreign_key => "identifier_id", :as => :identifier
  has_many :feedbacks, :as => :write_through
  has_one :address_of_seller, :through => :identifier

  delegate :address_of_seller, :to => :identifier

  validates_with PriceValidation, :fields => [:price, :item_price]
  validates :item_count, :numericality => {:greater_than_or_equal_to => 0, :only_integer => true}
  validates_presence_of :item_price, :item_count, :price, :identifier_id, :identifier_type
  validates_existence_of :receiver_option

  scope :only_products, where(:identifier_type => "Product")
  scope :by_user, lambda { |user_id| joins(:receiver_option => {:payment_option => :sender}).where(:users => {:id => user_id}) }
  scope :parallel_datum, lambda { |item_data| joins(:receiver_option).where(:receiver_options =>
                                                                                {:id => item_data.receiver_option.id},
                                                                            :identifier_type => "Product").all }
  scope :with_intracking_number, lambda { |id| joins(:receiver_option).joins(:additional_params).
      where(:receiver_options => {:id => id},
            :identifier_type => "Product",
            :additional_params => {:params_name => "intracking_number"})
  }

  scope :sellers_datums, lambda { |id| find_by_sql("select * from invoice_item_data where identifier_type = 'Product'
                                                and identifier_id in (select id from products where
                                                seller_id=#{id}) order by created_at DESC")
  }


  def method_missing(method_sym, *arguments, &block)
    method_name = method_sym.to_s
    regexp = /^data_for_(.*)$/
    if method_name =~ regexp
      params_name = method_name[regexp, 1]

      @clone_info ||= additional_params

      object = @clone_info.select { |info| info.params_name == params_name }
      object.first.try(:params_value)
    else
      super
    end
  end

  def self.set_additional_params(item_data, params, status, closed)
    parallel_datum = self.parallel_datum(item_data)

    if shipment_closed?(status, closed)
      unless has_intracking_number?(parallel_datum.first)
        create_additional_params(parallel_datum, params)
      end
      close_invoice_item_datum(parallel_datum)
    else
      raise StandardError, "Tracking number can't be modified" if has_intracking_number?(parallel_datum.first)

      create_additional_params(parallel_datum, params)
    end
  end

  def self.sales_fee(seller)
    sales_array = []

    invoice_item_datums = self.sellers_datums(seller.id)

    invoice_item_datums.each do |datum|
      date = datum.additional_params.first.created_at.to_date
      product_name = datum.data_for_name
      id = datum.receiver_option.payment_opt_id
      cost = datum.data_for_tax

      type = "Sales Fee"
      sales = {:date => date, :type => type, :product_name => product_name, :id => id, :cost => cost}
      sales_array << sales
    end
    return sales_array
  end

  private

  class << self

    def has_intracking_number?(item_data)
      with_intracking_number(item_data.receiver_option.id).all.any?
    end

    def close_invoice_item_datum(datum)
      ids = datum.collect(&:id)
      values = ids.map { |n| {:status => 3} }
      InvoiceItemData.update(ids, values)
    end

    def shipment_closed?(status, closed)
      status == "2" && closed == "1"
    end

    def create_additional_params(parallel_datum, params)

      parallel_datum.each do |data|
        data.additional_params.create(params)
      end
    end

  end
end

# == Schema Information
#
# Table name: invoice_item_data
#
#  id              :integer(4)      not null, primary key
#  identifier_id   :integer(4)      not null
#  identifier_type :string(255)     not null
#  price           :float           not null
#  item_price      :float           not null
#  item_count      :integer(4)      not null
#  invoice_data_id :integer(4)      not null
#  created_at      :datetime
#  updated_at      :datetime
#

