class User < ActiveRecord::Base
  require 'constant_contact'
  require 'digest'
  include ConstantContact

  ajaxful_rater

  self.per_page = 10

  # Setup accessible (or protected) attributes for your model
  #
  attr_accessor :password, :reset
  attr_accessible :username, :email, :password, :reset, :password_confirmation,
                  :remember_me, :birthday, :avatar, :about, :newsletter, :reset_password_sent_at,
                  :gender, :seller, :address, :seller_attributes, :address_attributes,
                  :facebook_email, :facebook_uid, :reset_password_token, :registered, :terms_of_service, :suspended

  #Here comes Paperclip settings
  #
  has_attached_file :avatar,
                    :styles => {:medium => "300x300>", :thumb => "100x100>"}

  validates_attachment_size :avatar,
                            :less_than => 5.megabytes

  validates_attachment_content_type :avatar,
                                    :message => 'Please upload correct format',
                                    :content_type => [/^image\/(?:jpeg|gif|png|jpeg|x-png)$/, nil]

  #validates_attachment_content_type :avatar,
  #                                  :message => 'Please upload correct format',
  #                                  :content_type => %w( image/jpeg image/png image/gif image/pjpeg image/x-png )

  has_one :seller, :dependent => :destroy
  has_one :address, :dependent => :destroy

  has_many :line_items, :dependent => :destroy
  has_many :approval_options, :class_name => "ApprovalOptions", :dependent => :destroy, :primary_key => "email", :foreign_key => "sender_email"
  has_many :payment_options, :class_name => "PaymentOption", :dependent => :destroy, :primary_key => "id", :foreign_key => "user_id"
  has_many :feedbacks_given, :class_name => "Feedback", :foreign_key => :writer_id

  accepts_nested_attributes_for :address
  accepts_nested_attributes_for :seller

  #default_scope select("`users`.id,`users`.email,`users`.encrypted_password,`users`.reset_password_token,`users`.reset_password_sent_at,`users`.remember_created_at,`users`.avatar_file_name,`users`.avatar_content_type,`users`.avatar_file_size,`users`.avatar_updated_at,`users`.facebook_uid,`users`.facebook_email,`users`.registered,`users`.salt,`users`.nickname,`users`.gender,`users`.birthday,`users`.about,`users`.newsletter")

  before_create :encrypt_password
  # This watcher required for the event of
  # user creating password with a help of form
  #
  before_update :encrypt_password, :is_suspend

  scope :by_payed, lambda { |user_id|
      select("sellers.id, sellers.first_name, sellers.last_name, invoice_item_data.id as receive_id, invoice_item_data.identifier_id as item_id, products.name as item_name, invoice_item_data.item_price, invoice_item_data.created_at, feedbacks.feedback_text").
      joins("INNER JOIN payment_options ON payment_options.user_id = users.id").
      joins("INNER JOIN invoice_item_data ON invoice_item_data.payment_option_id = payment_options.id").
      joins("INNER JOIN products ON products.id = invoice_item_data.identifier_id").
      joins("INNER JOIN sellers ON sellers.id = products.seller_id").
      joins("LEFT OUTER JOIN feedbacks ON feedbacks.write_through_id = invoice_item_data.id AND feedbacks.write_through_type = 'InvoiceItemData'").
      where("users.id = #{user_id}").where("payment_options.txn_id IS NOT NULL").where("invoice_item_data.identifier_type = 'Product'").
      order("invoice_item_data.created_at DESC") }

  scope :suspended , where("suspended = true")
  scope :active , where("suspended = false")

  validates :password, :presence => true,
            :length => {:within => 6..40},
            :confirmation => true, :if => :reset?
  validates :email, :presence => true,
            :format => {:with => /\A[\w+\-.]+@[a-z\d\-.]+\.[a-z]+\z/i},
            :uniqueness => {:case_sensitive => false}
  validates :username, :presence => true,
            :length => { :within => 5...20 }
  validates_acceptance_of :terms_of_service, :message => "Confirm agree"
  validates :facebook_email, :uniqueness => true , :unless => proc { self.facebook_email.blank? }
  validates :facebook_uid, :uniqueness => true , :unless => proc { self.facebook_uid.blank? }
  validates :birthday, :date => {:before => DateTime.now, :after => "1919-12-31".to_datetime}, :unless => proc { self.birthday.blank? }
  #validates :birthday, :date => {:within => "1970-01-01".to_datetime..DateTime.now}, :unless => proc { self.birthday.blank? }


  ABOUT = 400
  GENDER = 3
  NICKNAME = 20
  GENDERS = ['Male', 'Female', 'Rather not mention']

  def my_products
    Product.joins(:store => :seller).where(:sellers => {:user_id => self.id})
  end

  # You need to pass :reset => 0
  # for escaping password validations
  # This is required for update case within
  # user profile
  #
  def reset?
    self.reset.nil? || self.reset.to_i == 1
  end

  def first_name
    seller.try(:first_name)
  end

  def last_name
    seller.try(:last_name)
  end

  def fullname
    seller.try(:fullname)
  end

  def country_id
    address.try(:country_id)
  end

  def country
    Country.find_by_id(country_id)
  end

  def state
    State.find_by_id(state_id)
  end

  def for_stars_seller(seller_id)
    Seller.find_by_id(seller_id)
  end

  def state_id
    address.try(:state_id)
  end

  def city
    address.try(:city)
  end

  def street
    address.try(:street)
  end

  def zip
    address.try(:zip)
  end

  def phone
    address.try(:phone)
  end

  def address_full
    self.try(:address).try(:full_address)
  end

  def seller?
    !self.try(:seller).nil?
  end

  def has_store?
    !self.try(:seller).try(:store).nil?
  end

  def store
    self.seller.store if seller?
  end

  #TODO NEED REFACTORING
  def product_main(product_id)
    Product.find(product_id)
  end

  def my_product?(product)
    id = case product.class.to_s
           when Product.to_s
             product.id
           when Fixnum.to_s
             product
           when String.to_s
             product
         end
    !!my_products.find_by_id(id)
  end

  # Checks for being registered and link state
  #
  def ready_for_registration?
    !self.link_expired? && !self.registered?
  end

  #Just checking if link has expired
  #
  def link_expired?
    Time.now > (self.reset_password_sent_at + 5.minutes)
  end

  # Invoke adding to Constant Contact
  # check process of adding value to Constant Contact
  # then toggle :registered attr
  #
  def added_to_constant_contact?
    add_to_constant_contact if newsletter?
    self.update_attributes!(:registered => true, :remember_created_at => DateTime.now, :reset => 0)
    #UserMailer.create_welcome_mail(self).deliver
  end

  def send_confirmation_mail
    set_token
    UserMailer.confirm_email(self).deliver
  end

  def send_reset_password_mail
    set_token
    UserMailer.password_reset_mail(self).deliver
  end

  def hash_password?(submitted_password)
    self.encrypted_password == encrypt(submitted_password)
  end

  def seller_id
    self.attributes_before_type_cast[""]
  end

  def fetch_line_item(item_type, ship_to)
    line_items.where(:item_type_id => item_type, :ship_to_id => ship_to).first
  end

  # This block alternative to  def self.authenticate(email,submitted_password);end
  class << self
    def authenticate(email, submitted_password)
      user = first(:conditions => {:email => email}, :include => {:seller => :stores})
      return nil if user.nil?
      return user if user.hash_password?(submitted_password)
    end

    def authenticate_with_salt(id, salt)
      user = first(:conditions => {:id => id}, :include => {:seller => :stores})
      (user && user.salt == salt) ? user : nil
    end
  end

  private

  def encrypt_password
    # Encrypts password when it was created
    # But we can reset password by passing in
    # params {:reset => 1}
    #
    if self.new_record? || self.reset == 1
      # We leave creation of salt for security case
      # during sing in process
      self.salt = make_salt
      # Password can be blank in case of facebook user creation
      self.encrypted_password = encrypt(self.password) unless self.password.blank?
    end
    self.remember_created_at = DateTime.now if self.new_record?
  end


  def make_salt
    secure_hash("#{Time.now.sec}--#{@password}")
  end

  def encrypt(string)
    secure_hash("#{self.salt}--#{string}--car")
  end

  def secure_hash(string)
    Digest::SHA2.hexdigest(string)
  end

  def set_token
    generate_token(:reset_password_token)
    self.reset_password_sent_at = Time.zone.now
    # Escapes password validation
    self.reset = 0
    save!
  end

  def generate_token(column)
    begin
      self[column] = SecureRandom.base64.tr("+/", "-_")
    end while User.exists?(column => self[column])
  end

  # Create or fetch list from service
  # if no list return nil
  #
  def list_fetched?
    ConstantContact.setup(APP_CONFIG[:constant_contact_user_name], APP_CONFIG[:constant_contact_user_pass])
    lists = ConstantContact::ContactList.all
    @list = lists.select { |list| list.name == APP_CONFIG[:constant_contact_list] }.first
    if @list.nil?
      @list = ConstantContact::ContactList.add(APP_CONFIG[:constant_contact_list])
      logger.info "New list created!"
    end
    @list
  end

  # Here we are creating new Contact and
  # then we add him to default ConstantContact list
  #
  def add_to_constant_contact
    begin
      ConstantContact::Contact.add(:email_address => self.email, :contact_lists => [@list.uid])
    rescue => e
      logger.info e
    end if list_fetched?
  end

  def is_suspend
    if self.suspended_changed?
      if self.suspended?
        UserMailer.user_suspended(self).deliver
      else
        UserMailer.user_not_suspended(self).deliver
      end
    end
  end
end



# == Schema Information
#
# Table name: users
#
#  id                     :integer(4)      not null, primary key
#  email                  :string(255)     default(""), not null
#  encrypted_password     :string(128)     default(""), not null
#  reset_password_token   :string(255)
#  reset_password_sent_at :datetime
#  authentication_token   :string(255)
#  avatar_file_name       :string(255)
#  avatar_content_type    :string(255)
#  avatar_file_size       :integer(4)
#  avatar_updated_at      :datetime
#  facebook_uid           :integer(8)
#  facebook_email         :string(255)
#  registered             :boolean(1)      default(FALSE)
#  salt                   :string(255)
#  username               :string(20)
#  gender                 :integer(3)
#  newsletter             :boolean(1)
#  birthday               :date
#  remember_created_at    :datetime
#  about                  :text
#

