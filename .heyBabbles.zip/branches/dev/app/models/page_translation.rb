class PageTranslation < ActiveRecord::Base
  establish_connection "cms"
end