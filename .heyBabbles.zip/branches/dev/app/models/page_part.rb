class PagePart < ActiveRecord::Base
  establish_connection "cms"
end