class Product < ActiveRecord::Base
  include ProductDeprecations
  include ProductInstanceMethods

  STATUSES = ['used', 'new']
  EXPIRATION_TIME = 1.month
  USED_STATUSES = {"In progress" => "", "Rejected" => "0", "Approved" => "1", "Wait for approve" => "2", "Expired" => "3", "All" => "all"}
  #MIN_PRICE_FOR_USED = APP_CONFIG[:min_price_for_used]
  @min_price_for_used = Configuration.get_config('min_price_for_used').to_f
  #@price_one_image = Configuration.get_config('price_one_image').to_f
  self.per_page = 12

  belongs_to :combination
  belongs_to :currency
  belongs_to :store
  belongs_to :origin, :class_name => "Country", :foreign_key => "ship_from_id"
  belongs_to :main_image, :class_name => "ApplicationImage", :foreign_key => "main_image_id"

  has_one :seller, :through => :store
  has_many :sold_one, :class_name => "InvoiceItemData", :foreign_key => "identifier_id", :as => :identifier
  has_many :images, :class_name => "ApplicationImage", :order => "application_images.position ASC"
  has_many :item_types
  has_many :product_counters
  has_many :counter_services, :through => :product_counters
  has_many :product_seasons
  has_many :destinations, :class_name => "ShipTo"

  accepts_nested_attributes_for :product_counters

  delegate :category_id, :subcategory_id, :gender_category_id, :to => :combination, :allow_nil => true
  delegate :name, :to => :store, :prefix => true
  delegate :user, :to => :seller

  before_create :set_default_values
  before_update :change_for_approved

  validates_presence_of :name, :description, :combination_id, :currency_id, :ship_from_id
  validates :name, :length => {:within => 3..65}
  validates :description, :length => {:within => 3..2000}
  #validates :price,:numericality => {:greater_than_or_equal_to => Configuration.get_config('min_price_for_used').to_f}, :unless => :new?, :on => :update
  validates :price, :numericality => {:greater_than_or_equal_to => 0.01}, :if => :new?, :on => :update
  validates :price, :numericality => {:less_than_or_equal_to => 10000}, :on => :update
  validates_with BooleanValidator, :fields => [:new]
  validates_with PriceValidation, :fields => [:price], :new => true, :on => :update

  validate :associated_images_count

  scope :featured_products, select("products.id, products.main_image_id, products.new, products.price, products.name, categories.title, stores.name as label").
      joins(:store, :product_counters, {:combination => :category}).
      where("products.accepted = 1 and product_counters.payed = 1 and product_counters.service_type = #{Service::TYPE[:home]} and products.id in (SELECT products.id as product_id FROM `products` INNER JOIN `product_counters` ON `product_counters`.`product_id` = `products`.`id` INNER JOIN `combinations` ON `combinations`.`id` = `products`.`combination_id` INNER JOIN `categories` ON `categories`.`id` = `combinations`.`category_id` WHERE (product_counters.service_type = #{Service::TYPE[:home]}))").
      order("RAND()").limit(16)

  #scope :featured_products, select("products.*, categories.title, stores.name as label, product_counters.points").
  #    joins(:store, :product_counters, {:combination => :category}).
  #    where("products.accepted = 1 and product_counters.service_type = #{Service::TYPE[:home]} and product_counters.points > 0 and products.id in (SELECT products.id as product_id FROM `products` INNER JOIN `product_counters` ON `product_counters`.`product_id` = `products`.`id` INNER JOIN `combinations` ON `combinations`.`id` = `products`.`combination_id` INNER JOIN `categories` ON `categories`.`id` = `combinations`.`category_id` WHERE (product_counters.service_type = #{Service::TYPE[:home]} and product_counters.points > 0) ORDER BY product_counters.points ASC,categories.title = '#{Category::MAIN_ONE[0]}',categories.title = '#{Category::MAIN_ONE[1]}',categories.title = '#{Category::MAIN_ONE[2]}', categories.title = '#{Category::MAIN_ONE[3]}')").
  #    order("RAND()").limit(16)

  scope :last_added, lambda { |limit, store_id| select("products.*").where("products.store_id = #{store_id} and accepted = 1").#joins(:main_image).#includes(:main_image).
      order("products.created_at ASC").limit(limit) }

  scope :for_current_seller, lambda { |seller_id| where(:seller_id => seller_id) }
  # Deprecated
  scope :history_for_seller, lambda { |seller_id| where(:seller_id => seller_id).joins(:product_counters).uniq }

  scope :for_sale_products, lambda { |seller_id| select("products.id, products.expiration_date, products.name, sum(item_types.item_count) as amount").
      where("products.seller_id = #{seller_id} and products.accepted in (1, 3)").joins(:item_types).
      group("products.id").order("products.expiration_date, products.id DESC") }

  scope :used_products, lambda { |seller_id, condition| select("products.id, products.name, products.accepted, products.expiration_date").
      where("products.seller_id = #{seller_id} and products.new = 0").where(condition).order("products.expiration_date") }

  scope :all_new, where(:products => {:new => true})

  scope :all_used, where(:products => {:new => false})
  scope :not_accepted, where(:products => {:new => false, :accepted => 2})
  scope :rejected, where(:products => {:accepted => 0})
  scope :not_finished, where(:products => {:accepted => nil})


  #scope :seasonal_products, lambda {|season_id| }


  def order_images
    self.images.count - self.payed_images
  end


  def subtotal
    result = {}
    result[:total] = 0.0
    result[:product] = id

    if order_images > 0
      result[:images] = {
          :count => order_images,
          :cost => order_images * Configuration.get_config('price_one_image').to_f
      }
      result[:total] += result[:images][:cost]
    end

    result[:services] = []

    product_counters.not_payed.includes(:service).each do |service|
      result[:services] << {
          :title => service.service.title,
          :cost => service.service.price,
          :id => service.id
      }
      result[:total] += service.service.price
    end

    result[:seasons] = []

    Season.joins(:product_seasons).where(:product_seasons => {:product_id => self.id, :paid => false}).each do |season|
      result[:seasons] << {
          :title => season.title,
          :cost => season.cost,
          :id => season.id
      }
      result[:total] += season.cost
    end

    result
  end


  # TODO REFACTORING for use new script
  # SQL:
  # SELECT countries.*, ship_tos.id FROM countries left JOIN ship_tos ON ship_tos.country_id = countries.id  and ship_tos.product_id = 55 where countries.country_type & 4 and ship_tos.id IS NULL;
  def to_shippings
    # new script:
    #Country.joins("LEFT JOIN ship_tos ON ship_tos.country_id = countries.id AND ship_tos.product_id = #{self.id}").
    #    to_shippings.where(:ship_tos => {:id => nil})

    # old script:
    ar = destinations.all.collect(&:country_id)
    conditions = ar.blank? ? "" : "countries.id NOT IN (#{ar.join(",")})"
    Country.to_shippings.where(conditions)
  end

  #todo Ask Robert
  def product_services
    counters = product_counters.all
    ids = counters.collect(&:service_type)
    Service.all.each do |service|
      unless ids.include?(service.id)
        counters << ProductCounter.new(:service_type => service.id, :product_id => self.id)
      end
    end
    counters.sort_by { |counter| counter.service_type }
  end

  def impressions_for_service(serv_type)
    try(:product_counters).select(:points).where(:service_type => serv_type).first.try(:points)
  end

  def seasons_for_product(id)
    prod_count = Product.where(:product_seasons => {:product_id => id}).select('seasons.title as season_title').joins(:product_seasons => :season).all
    result = prod_count.map { |product| product.attributes_before_type_cast["season_title"] }.join(",")
    result
  end


  class << self
    include ProductSearch
    include ProductFetchFeatured
    #todo Speak with Fedia.About position.
    def category_products(category)
      joins(:combination).where(:combinations => {:category_id => category.id}).order(" products.id DESC")
    end

    def subcategory_products(category)
      joins(:combination).where(:combinations => {:subcategory_id => category.id}).order(" products.id DESC")
    end

    def gender_products(category)
      joins(:combination).where(:combinations => {:gender_category_id => category.id}).order(" products.id DESC")
    end

    def color_products(category)
      joins(:item_types).where(:item_types => {:color_category_id => category.id}).order(" products.id DESC")
    end

    def size_products(category)
      joins(:item_types).where(:item_types => {:size_category_id => category.id}).order(" products.id DESC")
    end

    def season_products(season)
      joins(:product_seasons).where(:product_seasons => {:season_id => season.id}).order(" products.id DESC")
    end

    def seasonal_products(season_id)
      joins(:product_seasons).where(:product_seasons => {:season_id => season_id, :paid => 1}, :accepted => 1).order(" products.id DESC")
    end



  end


  private

  def set_default_values
    self.expiration_date = (Time.zone.now + Product::EXPIRATION_TIME)
  end

  def associated_images_count
    if order_images + payed_images > ApplicationImage::MAX_IMAGES_PER_PRODUCT
      errors.add(:base, "you can not upload more then #{MAX_IMAGES_PER_PRODUCT} images per 1 product ")
    end
  end

  def change_for_approved
    acc = Product.find_by_id(self.id).accepted
    if self.accepted_changed?
      unless self.accepted == nil
        if self.accepted == 0
          UserMailer.product_not_approved(self.seller.user, self).deliver
        elsif self.accepted == 1 && acc != nil
          UserMailer.product_approved(self.seller.user, self).deliver
        end
      end
    end
  end


end

# == Schema Information
#
# Table name: products
#
#  id              :integer(4)      not null, primary key
#  currency_id     :integer(4)
#  seller_id       :integer(4)
#  store_id        :integer(4)
#  combination_id  :integer(4)
#  price           :float
#  accepted        :integer(4)
#  description     :text
#  return_policy   :text
#  name            :string(255)
#  product_sid     :string(255)
#  shipping_policy :text
#  expiration_date :datetime
#  new             :boolean(1)
#  ship_from_id    :integer(4)
#  created_at      :datetime
#  updated_at      :datetime
#  payd_images     :integer(4)      default(2), not null
#  main_image_id   :integer(4)      default(0), not null
#

