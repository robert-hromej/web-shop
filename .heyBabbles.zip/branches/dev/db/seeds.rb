# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ :name => 'Chicago' }, { :name => 'Copenhagen' }])
#   Mayor.create(:name => 'Daley', :city => cities.first)



  Configuration.create([
#main configuration
    {:name => "X-PAYPAL-SECURITY-USERID", :value => "seller_1320835241_biz_api1.gmail.com"},
    {:name => "X-PAYPAL-SECURITY-PASSWORD", :value => "1320835266"},
    {:name => "X-PAYPAL-SECURITY-SIGNATURE", :value => "AxpYVIyCi77cBfAvaFI2yS0j05JhA3afAjdzprO8ItKdyoVLchM14NKX"},
    {:name => "X-PAYPAL-APPLICATION-ID", :value => "APP-80W284485P519543T"},
    {:name => "X-PAYPAL-DEVICE-IPADDRESS", :value => "0.0.0.0"},
    {:name => "X-PAYPAL-REQUEST-DATA-FORMAT", :value => "JSON"},
    {:name => "X-PAYPAL-RESPONSE-DATA-FORMAT", :value => "JSON"},

#payment configuration
    {:name => "PurplePail-PayPal-acount", :value => "seller_1320835241_biz@gmail.com"},
    {:name => "tax-percent-new", :value => "10%"},
    {:name => "tax-percent-used", :value => "5%"},
    {:name => "feesPayer", :value => "EACHRECEIVER"},

#paypal server configuration
    {:name => "SERVER", :value => "svcs.sandbox.paypal.com"},
    {:name => "PORT", :value => "443"},
    {:name => "postback_validation_domain", :value => "sandbox.paypal.com"},

#preapproval settings
    {:name => "maxAmountPerPayment", :value => "200.00"},
    {:name => "maxNumberOfPayments", :value => "30"},
    {:name => "displayMaxTotalAmount", :value => "true"},
    {:name => "maxTotalAmountOfAllPayments", :value => "1500.00"},
    {:name => "pinType", :value => "NOT_REQUIRED"},


#site domain configuration
    {:name => "main_domain", :value => "http://ec2-107-22-184-225.compute-1.amazonaws.com"},
    {:name => "ipn_domain", :value => "http://ec2-107-22-184-225.compute-1.amazonaws.com/ipns"},



#other configuration
=begin
    {:name => "", :value => ""},
    {:name => "", :value => ""},

=end

  ])













#end
