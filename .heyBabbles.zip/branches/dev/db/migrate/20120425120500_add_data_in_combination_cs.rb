class AddDataInCombinationCs < ActiveRecord::Migration
  def self.up
    sqlstr="INSERT INTO combination_cs (combination_id, color_id, size_id) SELECT DISTINCT products.combination_id, item_types.color_category_id, item_types.size_category_id FROM products, item_types WHERE products.id = item_types.product_id"
    begin
      execute sqlstr
    rescue StandardError => er
      puts er
    end
  end

  def self.down
    sqlstr="DELETE FROM combination_cs"
    begin
      execute sqlstr
    rescue StandardError => er
      puts er
    end
  end
end
