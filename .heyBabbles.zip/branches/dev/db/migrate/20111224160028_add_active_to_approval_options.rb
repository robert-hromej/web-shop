class AddActiveToApprovalOptions < ActiveRecord::Migration
  def self.up
    add_column :approval_options, :active, :boolean, :null => false, :default => false
  end

  def self.down
    remove_column :approval_options, :active
  end
end
