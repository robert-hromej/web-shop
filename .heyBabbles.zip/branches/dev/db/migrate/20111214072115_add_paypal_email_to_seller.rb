class AddPaypalEmailToSeller < ActiveRecord::Migration
  def self.up
    add_column :sellers, :paypal_email, :string, :null => false
    add_index :sellers, :paypal_email, :unique => true
  end

  def self.down
    remove_column :sellers, :paypal_email
    remove_index :sellers, :paypal_email
  end
end
