# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
RefineryPail::Application.config.secret_token = '46cd10d746a94e3751e77dcfcfd8d0ea2e02e76f5bfe6831aed3201f325d828f7ce36b50731a93c5676baae9da7e3b26efcf4c48ff0447428c74e79d6279360f'
