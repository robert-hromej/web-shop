Then /^I should login in facebook pop window "(.*)\/(.*)"$/ do |email, pass|
  #last = page.driver.browser.window_handles.last
  #first = page.driver.browser.window_handles.first
  #within_window(last) do
    And %{I fill in "email" with "#{email}"}
    And %{I fill in "pass" with "#{pass}"}
    And %{I click element "label.uiButton input"}
  #end
  #within_window(first) do
    And %{I should be signed in}
  #end
end
Then /^last window$/ do
  #within_window(page.driver.browser.window_handles.last) do
  #  And %{I should be signed in}
  #end
end
Then /^I sign on staging as "(.*)\/(.*)"$/ do |email, password|
  And %{I am on the staging sign out}
  And %{I am on the staging sign in}
  And %{I fill in "Email" with "#{email}"}
  And %{I fill in "Password" with "#{password}"}
  And %{I press "Sign in"}
end

Then /^I exiting from the staging$/ do
  And %{I am on the staging sign out}
end
Given /^I click facebook connect$/ do
  And %{I click element "div#facebook_connect a.fb_button"}
  And %{sleep "5"}
end
Given /^I am not signed in on Facebook$/ do
  And %{I am on the facebook}
  And %{I click element "a#navAccountLink"}
  And %{I click element "form#logout_form label.uiLinkButton input"}
  And %{I am on the staging server}
end
When /^I sign on Facebook with "(.*)\/(.*)"$/ do |email, password|
  And %{I am on the facebook}
  And %{I fill in "email" with "#{email}"}
  And %{I fill in "pass" with "#{password}"}
  And %{I click element "label.uiButton input"}
end