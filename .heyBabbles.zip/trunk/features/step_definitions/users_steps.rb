Given /^populated database$/ do
    DatabaseCleaner.start
    populate = SeedDB.new("cucumber")
    populate.seed_products(35)
    populate.featured_seller
  #Factory(:product, :store_id => 1, :shippings => 1, :home_page_featured => 1)
end

Given /^no user exists with an email of "(.*)"$/ do |email|
  clean_db
  User.first(:conditions => {:email => email}).should be_nil
end

Given /^I am a( "[^\"]*")? user with an email "([^"]*)" and password "([^"]*)"$/ do |registered, email, password|
  clean_db
  #DatabaseCleaner.start
  Factory(:user, :email => email, :password => password, :password_confirmation => password, :registered => !registered.nil?)
end

Given /^I am a seller with( "[^\"]*")? an email "([^"]*)" and password "([^"]*)"$/ do |store, email, password|
  clean_db
  user = Factory(:user, :email => email, :password => password, :password_confirmation => password, :registered => true)
  seller = Factory(:seller, :user_id => user.id)
  if store.blank?
    seller.store.destroy
  end
end

And /^data for select populated$/ do
  Factory(:country)
  And %{I am a "registered" user with an email "bla@bla.com" and password "please1"}
end

Given /I have not completed registration with "(.*)\/(.*)"/ do |email, password|
  clean_db
  FactoryGirl.create(:user, :email => email, :password => password, :password_confirmation => password)
end

Given /^I am a new, authenticated user$/ do
  email = 'testing@man.net'
  login = 'Testing man'
  password = 'secretpass'

  Given %{I have one users "#{email}" with password "#{password}"}
  And %{I go to login}
  And %{I fill in "user_email" with "#{email}"}
  And %{I fill in "user_password" with "#{password}"}
  And %{I press "Sign in"}
end


Given /^I am signed up as "(.*)\/(.*)"$/ do |email, password|
  Given %{I am not logged in}
  When %{I go to the sign up page}
  And %{I fill in "Email" with "#{email}"}
  And %{I fill in "Password" with "#{password}"}
  And %{I fill in "Password confirmation" with "#{password}"}
  And %{I press "Sign up"}
  Then %{I should see "You have signed up successfully"}
  And %{I am logout}
end

Given /^I am logout$/ do
  visit('/users/sign_out')
end

When /^I sign in as "(.*)\/(.*)"$/ do |email, password|
  Given %{I am not logged in}
  When %{I go to the sign in page}
  And %{I fill in "Email" with "#{email}"}
  And %{I fill in "Password" with "#{password}"}
  And %{I press "Sign in"}
end

Then /^I should be followed to my profile$/ do
  Then %{I should be on the user show "user@test.com" page by "email"}
  And %{I should see "Signed in successfully."}
end

Then /^I should be blocked$/ do
  Then %{I should see "You have not finished registration!"}
end

Then /^I sign out$/ do
  Then %{I follow "Sign out"}
end

When /^I return next time$/ do
  And %{I go to the home page}
end

Then /^I should be signed out$/ do
  And %{I should see "Sell"}
  And %{I should see "Sign in"}
  And %{I should not see "Logout"}
end

Then /^I should be signed in$/ do
  And %{I should see "Sell"}
  And %{I should see "Sign out"}
  And %{I should see "My account"}
end

Given /^I am not logged in$/ do
  visit('/signout') # ensure that at least
end

And /^sleep(?: "([^\"]*)")?$/ do |sec|
  sec = 100 if sec.nil?
  sleep(sec.to_i)
end

When /^I see sign up form$/ do
  FactoryGirl.create(:country)
  And %{I go to "the sign up page"}
end

When /^I should see store inputs$/ do
  And %{I should see "Store Name"}
  And %{I should see "Store Description"}
  And %{I should see "Store Bio"}
  And %{I should see "Store Return Policy"}
end

When /^I follow the password recovery link for email "([^"]*)"$/ do |email|
  DatabaseCleaner.start
  reset_password_token = User.find_by_email(email).reset_password_token
  And %{I am on the update password page by token "#{reset_password_token}"}
end

When /^I follow the finish registration link for email "([^"]*)"$/ do |email|
  DatabaseCleaner.start
  user = User.find_by_email(email)
  token = user.reset_password_token
  id = user.id
  token = token[0..token.length-2]
  And %{I am on the finish registration page by token "#{token}" and by id "#{id}"}
end

When /^I must be on the users page with email "([^"]*)"$/ do |email|
  DatabaseCleaner.start
  And %{I should be on the users page with id "#{User.find_by_email(email).id}"}
end

When /^My link with email "([^"]*)" has expired$/ do |email|
  DatabaseCleaner.start
  user = User.find_by_email(email)
  user = user.update_attributes!( :reset_password_sent_at => (Time.now - 5.days), :reset => 0)
end

When /^I have "([^"]*)" sold products as "(.*)\/(.*)"$/ do |st_products, email, password|
  products = st_products.to_i
  DatabaseCleaner.start
    populate = SeedDB.new("cucumber")
    populate.seed_products_as_user(products,email,password)
    populate.invoices(products)
    populate.carts(products)
    populate.carts_without_info(products)
end
Then /^I should see in table only "([^"]*)"$/ do |value|
  pending
end


Given /^I am a logged in user$/ do
  #pending # express the regexp above with the code you wish you had
  And %{I am on the sign in page}
  And %{I am a "registered" user with an email "user1@mail.com" and password "111111"}
  And %{I follow "Register"}
  And %{I sign in as "user1@mail.com/111111"}
end
