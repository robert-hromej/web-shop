Then /^I should see seller form$/ do
  And %{I should see "First Name*:"}
  And %{I should see "Last Name*:"}
  And %{I should see "Last Name*:"}
  And %{I should see "Country*:"}
  And %{I should see "State*:"}
  And %{I should see "City*:"}
  And %{I should see "Street*:"}
  And %{I should see "Zip code*:"}
  And %{I should see "Phone #:"}
  And %{I should see element "input#user_seller_attributes_first_name"}
  And %{I should see element "input#user_seller_attributes_last_name"}
  And %{I should see element "select#user_address_attributes_country_id"}
  And %{I should see element "select#user_address_attributes_state_id"}
  And %{I should see element "input#user_address_attributes_city"}
  And %{I should see element "input#user_address_attributes_street"}
  And %{I should see element "input#user_address_attributes_zip"}
  And %{I should see element "input#user_address_attributes_phone"}
end

Then /^I should see seller registration form$/ do
  And %{I should see seller form}
  And %{I should see "Terms and Conditions"}
end
When /^There is countries and states generated$/ do
  c = Country.create(:title => "country")
  State.create(:title => "state", :country => c)
end