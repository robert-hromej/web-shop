Given /^There is generated categories$/ do
  cat = []
  16.times { |n| cat[n+1] = Category.create!(:title => "category#{n+1}").id }
  4.times { |n| Combination.create!(:category_id => cat[n+1], :subcategory_id => cat[5], :gender_category_id => cat[14]) }
  4.times { |n| Combination.create!(:category_id => cat[n+1], :subcategory_id => cat[5], :gender_category_id => cat[15]) }
  4.times { |n| Combination.create!(:category_id => cat[n+1], :subcategory_id => cat[6], :gender_category_id => cat[14]) }
  4.times { |n| Combination.create!(:category_id => cat[n+1], :subcategory_id => cat[6], :gender_category_id => cat[15]) }
  4.times { |n| Combination.create!(:category_id => cat[n+1], :subcategory_id => cat[6], :gender_category_id => cat[15]) }
  Combination.create!(:category_id => cat[1], :subcategory_id => cat[7], :gender_category_id => cat[16])
  Combination.create!(:category_id => cat[2], :subcategory_id => cat[7], :gender_category_id => cat[16])
  Combination.create!(:category_id => cat[3], :subcategory_id => cat[8], :gender_category_id => cat[16])
  Combination.create!(:category_id => cat[4], :subcategory_id => cat[8], :gender_category_id => cat[16])
  Combination.create!(:category_id => cat[1], :subcategory_id => cat[9], :gender_category_id => cat[16])
  Combination.create!(:category_id => cat[2], :subcategory_id => cat[10], :gender_category_id => cat[16])
  Combination.create!(:category_id => cat[3], :subcategory_id => cat[11], :gender_category_id => cat[16])
  Combination.create!(:category_id => cat[4], :subcategory_id => cat[12], :gender_category_id => cat[16])
  Combination.create!(:category_id => cat[4], :subcategory_id => cat[13], :gender_category_id => cat[16])
end

When /^I should see "([^"]*)" of options in "([^"]*)" select$/ do |length, id|
  page.evaluate_script("$('#{id} option').length;").should == length.to_i
end
When /^There is shippings$/ do
  15.times { |n| FromShipping.create!(:name => "from#{n+1}") }
  4.times { |n| ToShipping.create!(:name => "To#{n+1}") }
  4.times {|n| Currency.create!(:title => "currency#{n+1}")}
  4.times{|n| Size.create!(:title => "size#{n+1}")}
end