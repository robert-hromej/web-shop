ENV["RAILS_ENV"] ||= "test"

require 'rubygems'
require 'spork'
require 'database_cleaner'
require 'database_cleaner/cucumber'

Spork.prefork do
  require File.expand_path(File.dirname(__FILE__) + '/../../config/environment')

  # So that Pickle's AR adapter properly picks up the application's models.
  #Dir["#{Rails.root}/app/models/*.rb"].each { |f| load f }


  require 'cucumber/rails'
  require 'cucumber/formatter/unicode' # Remove this line if you don't want Cucumber Unicode support
  require 'cucumber/rails/world'
  require 'cucumber/web/tableish'

  #Capybara.server_port = 49158
  #Capybara.app_host = "http://0.0.0.0:49158"
  require 'webmock/cucumber'

  require 'capybara/rails'
  require 'capybara/cucumber'
  require 'capybara/session'
  Capybara.default_selector = :css
  Capybara.current_driver = :selenium
  Capybara.javascript_driver = :selenium
  Capybara.default_wait_time = 10
  WebMock.allow_net_connect!

  require 'faker'
  require 'factory_girl'
  require 'factory_girl/step_definitions'
  #require File.dirname(__FILE__) + "/../../spec/factories" # or wherever your factories are

  def clean_db
    DatabaseCleaner.strategy = :truncation
    DatabaseCleaner.start #cleaning database
    DatabaseCleaner.clean
  end

  def populate_db(clean = true)
    clean_db if clean
    DatabaseCleaner.start
    yield
    ""
  end

  def establish(clean = true)
    clean_db
    begin
      ActiveRecord::Base.establish_connection("test")
    rescue => e
      DatabaseCleaner.start
    ensure
      yield
    end

    ""
  end


end

Spork.each_run do

  ActionController::Base.allow_rescue = false
  Cucumber::Rails::World.use_transactional_fixtures = true

  if defined?(ActiveRecord::Base)
    begin
      require 'database_cleaner'
      clean_db
    rescue LoadError => ignore_if_database_cleaner_not_present
    end
  end

end

# You may also want to configure DatabaseCleaner to use different strategies for certain features and scenarios.
# See the DatabaseCleaner documentation for details. Example:
#
#
#   Before('~@no-txn', '~@selenium', '~@culerity', '~@celerity', '~@javascript') do
#     DatabaseCleaner.strategy = :transaction
#   end

