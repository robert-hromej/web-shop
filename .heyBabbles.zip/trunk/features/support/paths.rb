module NavigationHelpers
  # Maps a name to a path. Used by the
  #
  #   When /^I go to (.+)$/ do |page_name|
  #
  # step definition in web_steps.rb
  #
  def path_to(page_name)
    case page_name

      when /the home\s?page/
        '/'

      when /the fill staging with data/
        'http://rmd-sw.dyndns.info:4013/users/reload/1?rake=fb_users&env=staging'

      when /the staging sign in/
        'http://rmd-sw.dyndns.info:4011/signin'

      when /the staging sign out/
        'http://rmd-sw.dyndns.info:4011/signout'

      when /the login redmine page/
        'http://rmd-sw.dyndns.info:4013/login'

      when /the facebook/
        'http://www.facebook.com/'

      when /the staging server/
        'http://rmd-sw.dyndns.info:4011/'

      when /the sign up page/
        new_user_path

      when /the reset password page/
        new_password_reset_path
      when /the render reset password page/
        "/password_reset"

      when /the sign in page/
        signin_path

      when /the users page with id "([^\"]*)"$/i
        user_path($1)

      when /^the finish registration page by token "([^\"]*)" and by id "([^\"]*)"$/i
        finish_registration_path($2, :token => $1)

      when /^the update password page by token "([^\"]*)"$/i
        self.send("edit_password_reset_path", $1)

      when /the create store page/
        new_store_path

      when /the sold products page/
        sold_products_path

      when /the used products page/
        used_products_path

      when /the for sale products page/
        for_sale_products_path

      when /the create seller page/
        new_seller_path

      when /the product page/
        pending

      when /^the (.*) (edit|show|overview|new)( "([^\"]*)")? page by "([^\"]*)"$/i
        case $2
          when "edit", "show"
            klass = $1.singularize.capitalize.constantize
            obj = klass.send("find_by_#{$5.singularize}", $4) if $4 && $5
            raise "could not find #{$3} #{$1}" unless obj
            return self.send("edit_#{$1.downcase.singularize}_path", obj) if $2 == "edit"
            return self.send("#{$1.singularize}_path", obj) if $2 == "show"
          when "new"
            self.send("new_#{$1.downcase.singularize}_path")
          when "overview"
            self.send("#{$1.downcase.pluralize}_path")
        end

      when /the forgot password page/
        new_password_reset_path

      # Add more mappings here.
      # Here is an example that pulls values out of the Regexp:
      #
      #   when /^(.*)'s profile page$/i
      #     user_profile_path(User.find_by_login($1))

      else
        begin
          page_name =~ /the (.*) page/
          path_components = $1.split(/\s+/)
          self.send(path_components.push('path').join('_').to_sym)
        rescue Object => e
          raise "Can't find mapping from \"#{page_name}\" to a path.\n" +
                    "Now, go and add a mapping in #{__FILE__}"
        end
    end
  end
end

World(NavigationHelpers)
