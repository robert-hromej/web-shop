#!/bin/bash
function b_p {
  tput bold;
  echo $pr
  tput sgr0;
}

function p_dir {
  cur_dir="$( cd "$( dirname "$0" )" && pwd )"
  echo $cur_dir
}

if [ "$1" == "" ];then
 env="RAILS_ENV=development"
else
 env="RAILS_ENV=$1"
fi

echo $env
DIR="$( cd "$( dirname "$0" )" && pwd )"

if [[ $DIR =~ "/trunk" ]];then
    comand="../branches/cms/"
else
    comand="../cms/"
fi

pr="$comand reset db"
b_p
p_dir
echo `rake db:migrate:reset $env $2`
cd $comand
pr="migrating cms"
p_dir
b_p
echo `rake db:migrate $env $2`
cd $DIR
pr="migrating application"
p_dir
b_p
echo `rake db:migrate $env $2`

if [ "$1" == "" ];then
 pr="preparing for paralel test"
 b_p
 p_dir
 echo `rake parallel:prepare $env $2`
 pr="FINALLY FINISHED"
 b_p
fi