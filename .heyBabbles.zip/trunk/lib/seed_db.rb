require "factory_girl_rails"
require "database_cleaner"
require File.expand_path("../../spec/support/factory_extension", __FILE__)

class SeedDB
  attr_accessor :address, :user, :seller, :products, :product, :services,
                :combinations, :shipping, :store, :product_counters

  def initialize(env = "development")
    ActiveRecord::Base.establish_connection(env) unless env == "cucumber"
    DatabaseCleaner.strategy = :transaction
    DatabaseCleaner.clean_with :truncation
    DatabaseCleaner.start
    ActiveRecord::Base.establish_connection(env) unless env == "cucumber"
    @seller = nil; @store = nil; @address = nil; @user = nil; @seller = nil; @product = nil
    @products = []; @services = []; @carts = []
    @product_counters = []
    #todo need nicer population
    #country_seed = seed("1 country with 10 state")
    #@state = country_seed[1].first
    #@currency = FactoryGirl(:currency)
    ActiveRecord::Base.transaction do
      @country = Factory(:country)
      seed_service
      seed_seasons(5)
      seed_combinations
      seed_categories
    end

  end

  def seed_countries(number = 1)
    ActiveRecord::Base.transaction do
      number.times do
        Factory(:country, :country_type => rand(7)+1)
      end
    end
  end

  def seed_seasons(number = 1)
    ActiveRecord::Base.transaction do
      number.times do
        Factory(:season)
      end
    end
  end

  def seed_products(number = 1)
    @user = Factory(:user, :registered => true, :email => "admin@admin.com")
    @seller = Factory(:seller, :user_id => @user.id)
    store = @seller.store
    number.times do
      accepted = [nil, 0, 1].at(Kernel::rand(3))
      new = [0, 1].at(Kernel::rand(2))
      #Removed because of refactoring
      #:season_type => (rand(5) + 10)
      #,:home_page_featured => 1
      #:shippings => [random_instance_of("shippings")],
      product = Factory(:product, :store_id => @store.id,
                        :combination => random_instance_of("combinations"),
                        :accepted => accepted, :new => new)
      @products << product
    end
    @product = @products.last
  end


  def seed_items(number = 1, options = {})
    options.reverse_merge!(:email => "admin@admin.com", :password => "please1", :factory_label => :item)
    items = []
    number.times do
      @products << Factory(options[:factory_label], :accepted => [nil, 1, 2].at(Kernel::rand(3)))
      Factory(:product_season, :product_id => @products.last.id, :season_id => Kernel::rand(5)+1)
    end

    @product= @products.last
    @store = @product.store
    @seller = @store.seller
    @user = @product.store.seller.user
    @user.update_attributes(:email => options[:email], :password => options[:password],
                            :password_confirmation => options[:password], :registered => true)

    index = 0
    @combinations = @subcategories.collect { |category|
      index = index + 1
      Factory(:combination, :subcategory => category, :category => Category.find(index))
    }

    products = []
    14.times do |i|
      options = {
          :name => ((i/4) % 2 == 0) ? "aaa #{13-i+1}" : "bbb #{13-i+1}",
          :description => ((i/2) % 2 == 0) ? "aaa" : "bbb",
          :new => i%2,
          :combination => @combinations[(i/8) % 2]
      }
      products << Factory(:product, options)
    end

    Factory.create(:product,
                   :name => "t-shorts name",
                   :description => "this is description of named t-shorts",
                   :combination => @combinations[2])
    Factory.create(:product,
                   :name => "t-shorts description",
                   :description => "this is description of descripted t-shorts. this is one more word \"this\"",
                   :combination => @combinations[2])
    Factory.create(:product,
                   :name => "t-shorts categoried",
                   :description => "this is description",
                   :combination => @combinations[3])

  end

  def seed_recommendations
    Factory(:invoice_with_recommendations)
  end

  def seed_products_as_user(number = 1, email = "admin@admin.com", password = "please1")
    ActiveRecord::Base.transaction do
      @user = Factory(:user, :registered => true, :email => email, :password => password, :password_confirmation => password)
      @seller = Factory(:seller, :user_id => @user.id)
      @store = @seller.store
      number.times do
        @products << Factory(:product, :store_id => @store.id,
                             :shippings => [random_instance_of("shippings")],
                             :combination => random_instance_of("combinations"),
                             :home_page_featured => 1)
      end
      @product = @products.last
    end
  end

  def populate_sold_items(items_count = 1, invoiced_item_count = 1)
    items_count.times do
      prod = Factory(:independent_product)

    end
    items_count.times do
      data = Factory(:receiver_option)
      data.seller.user = Factory(:user)
      invoiced_item_count.times do
        Factory(:invoiced_product, :receiver_option_id => data.id, :identifier_id => rand(items_count)+1)
        Factory(:invoiced_service, :receiver_option_id => data.id, :identifier_id => rand(items_count)+1)
      end
    end
  end

  def featured_seller
    Factory(:featured_vendor)
  end

  def address
    @user.nil? ? nil : @user.address
  end

  def states
    @country.nil? ? nil : @country.states
  end

  private

  def seed_categories
    @subcategories = []
    @subcategories << Factory(:sub_category, :title => "aaa")
    @subcategories << Factory(:sub_category, :title => "bbb")
    @subcategories << Factory(:sub_category, :title => "ccc")
    @subcategories << Factory(:sub_category, :title => "categoried description")
  end

  # Just populate DB with valid combinations
  #
  # TODO: separate into seed_categories & seed combinations
  def seed_combinations
    @combinations = []
    category_name = Category::MAIN_ONE.keys
    comb = {category_name[0] => {"Clothes" => ["Female"], "Accessories" => ["Female"], "Shoes" => ["Female"]},
            category_name[1] => {"Clothes" => ["Female", "Male", "Unisex"], "Accessories" => ["Female", "Male", "Unisex"], "Shoes" => ["Female", "Male", "Unisex"], "Toys" => ["Female", "Male", "Unisex"]},
            category_name[2] => {"Clothes" => ["Female", "Male", "Unisex"], "Accessories" => ["Female", "Male", "Unisex"], "Shoes" => ["Female", "Male", "Unisex"], "Toys" => ["Female", "Male", "Unisex"]},
            category_name[3] => {"Clothes" => ["Male"], "Accessories" => ["Male"], "Shoes" => ["Male"], "Toys" => ["Male"]}}
    sub_category = ["Clothes", "Accessories", "Shoes", "Toys"]
    gender = ["Male", "Female", "Unisex"]
    #rescue => e

    comb.keys.each { |category| Factory(:category, :title=> category, :level => 1) }
    sub_category.each { |category| Factory(:category, :title => category, :level => 2) }
    gender.each { |category| Factory(:category, :title => category, :level => 3) }

    comb.each do |category, hash|
      main_id = Category.find_by_title(category).id
      hash.each do |sub, genders|
        sub_id = Category.find_by_title(sub).id
        genders.each do |gender|
          gender_id = Category.find_by_title(gender).id
          @combinations << Factory(:default_combination, :category_id => main_id, :subcategory_id => sub_id, :gender_category_id => gender_id)
        end
      end
    end
  end

  def seed_shippings(number = 1)
    number.times { @to_shippings << Factory(:to_shipping) }
    number.times { @from_shippings << Factory(:from_shipping) }
    5.times do
      @shippings << Factory(:shipping, :to_shipping => ToShipping.find_by_id(random_id("to_shippings")),
                            :from_shipping => FromShipping.find_by_id(random_id("from_shippings")))
    end
  end

  def seed_service
    Factory(:home_service)
    Factory(:search_service)
  end

  # Randomly choose combination
  #
  def random_id(accessor)
    array = eval "#{accessor}.collect(&:id)"
    array[rand(array.length)]
  end

  def random_instance_of(accessor)
    length = eval "#{accessor}.length"
    eval "#{accessor}[#{rand(length-1)}]"
  end

end
