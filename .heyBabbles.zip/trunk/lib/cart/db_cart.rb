module DbCart

  class Cart

    attr_accessor :current_user

    def initialize(current_user)
      self.current_user = current_user
    end


    def get_items
      self.current_user.line_items
    end

    def fetch_line_item(params)
      self.current_user.fetch_line_item(params[:item_type_id], params[:ship_to_id])
    end

    def get_item_type(line_item)
      line_item.item_type
    end

    def update_line_item(line_item, count)
      line_item.update_attribute(:count, count)
    end

    def destroy_line_item(line_item)
      line_item.destroy
    end

    def add_item(line_item)
      line_item.user = self.current_user
      return line_item.save
    end

  end
end
