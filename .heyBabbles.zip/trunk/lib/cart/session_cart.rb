module SessionCart

  class Cart

    attr_accessor :session

    def initialize(session)
      self.session = session
    end


    def get_items
      cart_items = []
      if self.session[:cart_items]
        self.session[:cart_items].each do |hash_line_item|
          cart_items << LineItem.new(:item_type_id => hash_line_item.keys.first, :ship_to_id => hash_line_item.values.first[:ship_to], :count => hash_line_item.values.first[:count])
        end
      end
      return cart_items
    end

    def fetch_line_item(params)
      session[:cart_items].find_all { |e| e.keys.include?(params[:item_type_id].to_i) }.find { |e| e.values.first[:ship_to] == params[:ship_to_id].to_i }
    end

    def get_item_type(line_item)
      ItemType.find_by_id(line_item.keys.first)
    end

    def update_line_item(line_item, count)
      index = session[:cart_items].rindex(line_item)
      line_item.values.first[:count] = count
      session[:cart_items][index] = line_item
    end

    def destroy_line_item(line_item)
      index = session[:cart_items].rindex(line_item)
      session[:cart_items].delete_at(index)
    end

    def add_item(line_item)
      if session[:cart_items]
        if line_item.already_in_cart?(session[:cart_items])
          return false
        else
          session[:cart_items] << line_item.to_cart_hash
          return true
        end
      else
        session[:cart_items] = []
        session[:cart_items] << line_item.to_cart_hash
        return true
      end
    end

  end

end
