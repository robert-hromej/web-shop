class DataRangeValidation < ActiveModel::Validator

  def validate(record)
    return false if options[:fields].blank?
    return false if options[:fields].size != 2
    last_model_instance = nil

    range = options[:fields].map do |field|
      last_model_instance = record.class.order("#{field} ASC").last
      last_model_instance.try(field)
    end

    return false unless last_model_instance
    return false unless range

    date_range = (range.first..range.second).to_a

    options[:fields].each do |field|
      value = record.send(field)
      return false if value.blank?

      if date_range.include?(value.to_date)
        record.errors[:base] << "Invalid date for #{field}.Already reserved for other '#{record.class}'."
      end
    end

  end

end