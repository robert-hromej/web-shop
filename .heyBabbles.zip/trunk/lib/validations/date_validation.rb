class DateValidation < ActiveModel::Validator
  def validate(record)
    return false if options[:fields].blank?
    options[:fields].each do |field|
      value = record.send(field)
      return false unless value

    end

  end
end