class PriceValidation < ActiveModel::Validator
  def validate(record)
    return false if options[:fields].blank?

    options[:fields].each do |field|

      value = record.send(field)
      return false unless value

      unless /^\d+?(?:\.\d{0,2})?$/i === value.to_s
        record.errors[field] << (options[:message] || "is not valid price")
      end

    end

  end
end