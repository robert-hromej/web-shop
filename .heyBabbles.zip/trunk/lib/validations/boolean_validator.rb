class BooleanValidator < ActiveModel::Validator

  def validate(record)
    return false if options[:fields].blank?

    options[:fields].each do |field|

      value = record.send(field)
      if !value.is_a?(TrueClass) && !value.is_a?(FalseClass)
        record.errors[field] << (options[:message] || "Should be a boolean")
      end

    end

  end

end
