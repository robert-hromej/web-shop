module ProductSearch

  # searches products, which contain q in name, or belongs to category that contain q and sorts the result
  # if query likes '"strong equal"', it will search whole phrase, else it will search every word
  # @param query [query]
  # @param category_id [category to filter]
  # @return search results
  #
  def search(query, options = {})
    options[:per_page] ||= Product.per_page

    unless query.empty?
      # perform phrase or words searching
      words = query[/".*"/] ? query[1...-1] : query.split.compact.join("|")
      condition = "(#{words})+"

      results = search_by(condition, options[:category]).page(options[:page]).per_page(options[:per_page])
    else
      results = Product.page(options[:page]).per_page(options[:per_page])
    end

    results
  end

  private

  def search_by(condition, main_category)
    filters = []
    filters << search_by_name(condition, main_category)
    filters << search_by_description(condition, main_category)
    filters = filters + search_by_categories(condition, main_category)

    unions = make_union(filters)

    select("products.*, sum(products.search_points) as total_search_points").from("(#{unions}) as products").group(:id).order("total_search_points DESC")
  end

  def search_by_name(condition, main_category)
    search_points(100, main_category).where("name regexp ?", condition)
  end

  def search_by_description(condition, main_category)
    search_points(10, main_category).where("description regexp ?", condition)
  end

  def search_by_subcategory(condition, main_category)
    search_points(10, main_category).where("description regexp ?", condition)
  end

  def search_by_categories(condition, main_category)
    filters = []

    #categories = Category.group_by_levels(condition)
    #
    #return [] if categories.empty?
    #
    #subcategory_ids = Category.sub_one.collect(&:id)
    #gender_ids = Category.gender_one.collect(&:id)
    #color_ids = Category.color_one.collect(&:id)
    #size_ids = Category.size_one.collect(&:id)
    subcategory_ids = []
    gender_ids = []
    color_ids = []
    size_ids = []

    categories = Category.where("`categories`.`title` regexp ?", condition)

    return [] if categories.empty?

    categories.each do |category|
      case category.level
        when Category::SUB_CATEGORIES_LEVEL
          subcategory_ids << category.id
        when Category::GENDER_CATEGORIES_LEVEL
          gender_ids << category.id
        when Category::COLOR_CATEGORIES_LEVEL
          color_ids << category.id
        when Category::SIZE_CATEGORIES_LEVEL
          size_ids << category.id
      end
    end

    filters << search_points(1002, main_category).joins(:combination).where(:combinations => {:subcategory_id => subcategory_ids}) unless subcategory_ids.empty?
    filters << search_points(1004, main_category).joins(:combination).where(:combinations => {:gender_category_id => gender_ids}) unless gender_ids.empty?
    filters << search_points(1006, main_category).joins(:item_types).where(:item_types => {:color_category_id => color_ids}) unless color_ids.empty?
    filters << search_points(1008, main_category).joins(:item_types).where(:item_types => {:size_category_id => size_ids}) unless size_ids.empty?
    filters
  end

  def base_results
    select("`products`.*").joins("left join `product_counters` on `product_counters`.`product_id` = `products`.`id` and `product_counters`.`service_type` = 2")
  end

  def search_points(points, category)
    chain = base_results.select("(#{points} + if(payed is not null, ((points > 0) * payed),0)) as search_points")
    chain = chain.joins(:combination).where(:combinations => {:category_id => category.id}) if category
    chain
  end

  def make_union(relations = [])
    sql = ""
    relations[0..-2].each { |r| sql << "(#{r.to_sql}) union " }
    sql << "(#{relations[-1].to_sql})"
    sql
  end

end
