module ProductFetchFeatured
  # This method returns random set of featured products
  # @return [[4.products],[4.products],[4.products],[4.products]]
  #
  def fetch_features

    featured_products = Product.featured_products.all
    output = []
    Category::MAIN_ONE.keys.each do |category_name|
      # Sorting by 4 main categories
      array = featured_products.select { |product| product if product.attributes_before_type_cast.values.include?(category_name) }

      if array.length <= 4
        output << array
      else
        output << divide(array)
      end if !array.blank?

    end if !featured_products.blank?
    output
  end

  # @param ids [1,2,3,4]
  # Decrements impressions of products
  def decrement_counters(ids, limit)
    sql = ActiveRecord::Base.connection()
    unless ids.blank?
      sql.update("UPDATE product_counters SET points = IF(points=0,0,points-#{limit}) WHERE id in (#{ids.join(",")})")
      sql.delete("DELETE from product_counters WHERE (product_counters.points = 0)")
    end
  end

  private
  # @param input [array with more than 4 values]
  # @return [4 random values]
  # We are dividing income set of arrays and pass to
  # the randomize which return not 'linear distribution'
  #
  def divide(input)
    output=[]
    parts = 3
    income_length = input.length
    pieces_in_part = income_length / parts
    rest = income_length % parts

    (0..parts-1).each do |part|
      #index of first element in current part
      start = part * pieces_in_part
      #index of last element in current part
      endd = start + (pieces_in_part-1)
      #If current part is last
      if (part == parts-1)
        additional_rest = rest
      else
        additional_rest = 0
      end
      #generating output array with elements from input array
      output[part] = input[start..endd+additional_rest]
    end
    randomize(output)
  end

  # @param multiple_array [[n],[n],[n]]
  # n more or equal 4
  def randomize(multiple_array)
    output =[]
    multiple_array.each do |array|
      if array.length != 1
        # IF current array is last?
        if array != multiple_array.last
          # Here we randomly push array with 1 element
          array = array.sort_by { rand }
          output << [array[0]]
        else
          array = array.sort_by { rand }
          # Form last element of output with 2 values
          # this element must be Array
          output << [array[0], array[1]]
        end
      else
        output << array
      end
    end
    output = output.reverse
    output.flatten!
  end

end