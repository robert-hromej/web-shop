module ProductInstanceMethods
  def has_main_image?
    !self.main_image.blank?
  end

  def recommendations
    product_id = self.id
    Product.where("id IN (SELECT DISTINCT identifier_id FROM invoice_item_data  WHERE receiver_option_id IN
        (SELECT DISTINCT receiver_option_id FROM invoice_item_data
          WHERE identifier_id = #{product_id} and identifier_type = 'Product') AND identifier_id <> #{product_id})")
  end

  def search_counter
    product_counters.where(:service_type => Service::TYPE[:search]).first
  end

  def search_count
    search_counter.try(:points).to_i
  end

  def default_image
    return self.main_image.image.url if self.main_image
    "/images/cart.jpeg"
  end

  def category
    combination.try(:category)
  end

  def subcategory
    combination.try(:subcategory)
  end

  def gender
    combination.try(:gender)
  end

  def category_id
    combination.try(:category_id)
  end

  def subcategory_id
    combination.try(:subcategory_id)
  end

  def gender_id
    combination.try(:gender_category_id)
  end

  def home_page_count
    product_counters.find_by_service_type(Service::TYPE[:home]).try(:points).to_i
  end


  def image_count
    images.count.to_i
  end

  def ship_from_country
    origin.try(:title)
  end

  def return_policy
    if attributes_before_type_cast[:return_policy].nil?
      try(:store).try(:return_policy)
    else
      attributes_before_type_cast[:return_policy]
    end
  end

  def address_of_seller
    try(:seller).try(:address)
  end

  def impressions_for_service(type)
    product_counters.where(:service_type => type).first.try(:points).to_i
  end

  def available
    item_types.sum(:item_count)
  end

  def status
    states = {nil => "In Progress", 1 => "Approved", 2 => "Rejected"}
    states.fetch self.accepted
  end

  def amount
    read_attribute_before_type_cast("amount")
  end


  def days_left
    days_between_dates(Time.zone.now, expiration_date)
  end

  private

  def days_between_dates(first, last)
    first > last ? 0 : (last.to_date - first.to_date).ceil
  end


end
