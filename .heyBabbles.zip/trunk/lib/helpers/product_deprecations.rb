module ProductDeprecations
  private
  #'Deprecated'
  # Sets counter impressions
  # @param type [counter_type]
  # @param impressions [Fixnum]
  # @param overwrite [true? ? given_impressions : old + given]
  def set_simple_counter(type, impressions, overwrite=false)
    feature = self.product_counters.find_by_service_id(type)
    if feature
      feature.update_attribute('impressions', (overwrite ? impressions : feature.impressions + impressions))
    else
      self.product_counters.build(:service_id => type, :impressions => impressions)
    end
  end

  #'Deprecated'
  # Finds combination appropriate to incoming parameters and sets it's id for product
  def set_combination_id
    if (!@category_id.nil? && !@subcategory_id.nil? && !@gender_id.nil?)
      combination = Combination.first(:conditions => ["category_id = ? and subcategory_id = ? and gender_category_id = ?", @category_id, @subcategory_id, @gender_id])
      self.combination = combination unless combination.nil?
    end
  end

  #'Deprecated'
  # Sets from shipping id to all of the shippings according to one ship_from parameter
  def set_ship_from
    self.shippings.each do |s|
      ((@ship_from.class == String) ? s.from_shipping_id = @ship_from : s.from_shipping_id = @ship_from.id) unless (s.nil? || @ship_from.nil?)
    end
  end

  #'Deprecated'
  # Sets all product counters according to incoming params
  def set_product_counters
    set_simple_counter(1, 1000) if self.home_page_featured.try(:to_i) == 1
    set_simple_counter(2, 1000) if self.search_featured.try(:to_i) == 1
    self.errors.add(:images, 'must be less than 9') if self.images.length > 8
    set_simple_counter(3, self.images.length, true) unless self.images.nil?
    set_simple_counter(self.season_type, nil, true) unless self.season_type.blank?
  end
end