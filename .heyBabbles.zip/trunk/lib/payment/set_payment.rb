module AdaptivePayment
  class SetPayment < Base

    attr_accessor :data, :response

    def initialize(options = {})
      @data = options.reverse_merge!("requestEnvelope" => DEFAULT_DATA["requestEnvelope"])
    end

    def build_business_model
      #..
    end

    def fetch
      @response = send("/AdaptivePayments/SetPaymentOptions", data)

      p @response
      response = decode_response(@response)
      p response
      p response['responseEnvelope']['ack']

      response_valid?(@response)
    end
  end
end
