module AdaptivePayment

  def form_for_payment(options = {})
    html = <<-HTMLERB
    <script src="https://www.paypalobjects.com/js/external/dg.js"></script>
    <form action="https://www.sandbox.paypal.com/webapps/adaptivepayment/flow/pay" target="light">
      <input id="type" type="hidden" name="expType" value="light">
      <input id="paykey" type="hidden" name="paykey" value="#{options[:paykey]}">
      <input id="preapprovalkey" type="hidden" name="preapprovalkey" value="#{options[:preapprovalkey]}">
      <input type="submit" id="submitBtn" value="Pay with PayPal"></form>
    <script> var dgFlow = new PAYPAL.apps.DGFlow({ trigger: 'submitBtn' }); </script>
    HTMLERB
    html.html_safe
  end

end
