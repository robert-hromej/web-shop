#Test Account: 	seller_1320835241_biz@gmail.com
#API Username: 	seller_1320835241_biz_api1.gmail.com
#API Password: 	1320835266
#Signature: 	  AxpYVIyCi77cBfAvaFI2yS0j05JhA3afAjdzprO8ItKdyoVLchM14NKX
#seller login password: 320835171

#buyer account:   buyer_1320835920_per@gmail.com
#password:        320835851


module AdaptivePayment
  class Base
    cattr_accessor :headers, :endpoints


#service version - cite: "PayPal recommends not specifying a version unless it is absolutely required"
#"X-PAYPAL-SERVICE-VERSION" => "1.0.0",

    @@headers = {"X-PAYPAL-SECURITY-USERID" => "seller_1320835241_biz_api1.gmail.com",
                 "X-PAYPAL-SECURITY-PASSWORD" => "1320835266",
                 "X-PAYPAL-SECURITY-SIGNATURE" => "AxpYVIyCi77cBfAvaFI2yS0j05JhA3afAjdzprO8ItKdyoVLchM14NKX",
                 "X-PAYPAL-APPLICATION-ID" => "APP-80W284485P519543T",
                 "X-PAYPAL-DEVICE-IPADDRESS"=>"0.0.0.0",
                 "X-PAYPAL-REQUEST-DATA-FORMAT" => "JSON",
                 "X-PAYPAL-RESPONSE-DATA-FORMAT" => "JSON"}

    @@endpoints = {"SERVER" => "svcs.sandbox.paypal.com", "PORT" => "443", "SERVICE" =>""}

    DEFAULT_DATA = {"actionType"=>"PAY", "currencyCode"=>"USD", "requestEnvelope"=>{"errorLanguage"=>"en_US", "detailLevel" => "ReturnALL"}}
    DEFAULT_URLS = {"main_domain" => "http://rmd-sw.dyndns.info:4012/", "ipn_domain" => "http://irromance.com/ipn_test/"}


    # @param options [In options we specify callback URL`s]
    def initialize(options = {})
      opt = options.reverse_merge!(DEFAULT_DATA).clone
      if has_urls?(options)
        opt.merge!("returnUrl" => (DEFAULT_URLS["main_domain"] + options["returnUrl"]),
                   "cancelUrl"=> (DEFAULT_URLS["main_domain"] + options["cancelUrl"]),
                   "ipnNotificationUrl"=> (DEFAULT_URLS["ipn_domain"] + options["ipnNotificationUrl"])
        )
      end
      opt
    end

    # @param service [name of Service]
    # @param data [Data we sending in body to PayPal]
    def send(service, data)
      raise "You have specified wrong attr" if service.blank? || data.blank?
      endpoints["SERVICE"] = service

      http = Net::HTTP.new(endpoints["SERVER"], endpoints["PORT"])
      # we need to use a certificate here (will be VERIFY_PEER)
      http.verify_mode = OpenSSL::SSL::VERIFY_NONE #unless ssl_strict
      http.use_ssl = true
      http = http.post(endpoints["SERVICE"], ActiveSupport::JSON.encode(data), headers)

      Rails.logger.info "Post has been sent!"
      http
    end

    # Checks encoded json
    # @param response [Hash (2 element(s))]
    # @return [false || true]
    def response_valid?(response)
      raise "Response Failed" if response.blank?
      return false unless response.is_a?(Net::HTTPOK)
      response = decode_response(response)

      if response['responseEnvelope']['ack'] == "Success"
        Rails.logger.info "Acknowledged: Success"
        Rails.logger.debug "Response is: #{response}"
        true
      else
        Rails.logger.info "Acknowledged: Failure"
        Rails.logger.debug "Response is: #{response}"
        false
      end
    end

    # @param response [Net object]
    def decode_response(response)
      ActiveSupport::JSON.decode(response.body)
    end

    private

    def has_urls?(options)
      !options["returnUrl"].blank? && !options["cancelUrl"].blank? && !options["ipnNotificationUrl"].blank?
    end

  end
end

require 'net/http'
require 'net/https'
require "helper"
require "adaptive_payment/approval_key"
require "adaptive_payment/pay_key"
