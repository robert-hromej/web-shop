module AdaptivePayment
  class PayKey < Base
    attr_accessor :data, :response

    def initialize(options = {})
      opt = super(options)
      opt.merge!("receiverList"=>{"receiver"=> []})
      @data = opt
    end

    def receiver_list(receivers = [])
      raise ArgumentError, "Receivers can't be blank!" if receivers.blank?
      receivers.each { |receiver| data["receiverList"]["receiver"] << receiver }
      self
    end

    def fetch_pay_key
      raise "Request can't be sent.You have not specified receivers!" if data["receiverList"]["receiver"].blank?
      @response = send("/AdaptivePayments/Pay", data)
      response_valid?(@response) ? decode_response(@response)["payKey"] : nil
    end

  end
end
