module AdaptivePayment
  class ApprovalKey < Base
    attr_accessor :data, :response

    def initialize(options = {})
      @data = super(options)
    end

    # @param options [We recieve options for making special request for PreApprove]
    def approval_settings(options = {})
      set_default_period(options)
      options.reverse_merge!(:maxAmountPerPayment => 200.00,
                             :maxNumberOfPayments => 30,
                             :displayMaxTotalAmount => true,
                             :feesPayer => "SENDER",
                             :maxTotalAmountOfAllPayments => 1500.00,
                             :pinType => "NOT_REQUIRED"
      )
      data.merge!(options)
      self
    end

    def fetch_approval_key
      @response = send("/AdaptivePayments/Preapproval", data)
      response_valid?(@response) ? decode_response(@response)["preapprovalKey"] : nil
    end

    private
    # Here we just manage to set some default 'time range'.
    def set_default_period(options)
      unless options.include?(:endingDate) && options.include?(:startingDate)
        date = Time.new
        start_date = date.strftime("%Y-%m-%d")
        end_date = "#{date.year + 1}-#{date.strftime("%m")}-#{date.strftime("%d")}"
        data.merge!(:endingDate => end_date, :startingDate => start_date)
      end
    end

  end
end

