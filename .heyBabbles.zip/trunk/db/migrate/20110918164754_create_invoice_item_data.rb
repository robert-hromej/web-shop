class CreateInvoiceItemData < ActiveRecord::Migration
  def self.up
    create_table :invoice_item_data do |t|
      t.references :identifier, :null => false, :polymorphic => true

      t.float :price, :null => false, :precision => 5, :scale => 2
      t.float :item_price, :null => false, :precision => 5, :scale => 2
      t.integer :item_count, :null => false
      t.integer :invoice_data_id, :null => false
      #t.integer :status
      #t.text :shipping_info
      #t.string :intracking_number

      t.timestamps
    end
  end

  def self.down
    drop_table :invoice_item_data
  end
end
