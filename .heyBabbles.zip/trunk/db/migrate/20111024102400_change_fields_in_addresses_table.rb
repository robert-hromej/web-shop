class ChangeFieldsInAddressesTable < ActiveRecord::Migration

  def self.up
    change_column :addresses, :user_id, :integer, :null => false, :unique => true
    change_column :addresses, :zip, :string, :limit => Address::ZIP
    change_column :addresses, :city, :string, :limit => Address::CITY
    change_column :addresses, :street, :string, :limit => Address::STREET
    change_column :addresses, :phone, :string, :limit => Address::PHONE

    add_index :addresses, :user_id, :unique => true
  end

  def self.down
    change_column :addresses, :user_id, :integer
    change_column :addresses, :zip, :string
    change_column :addresses, :city, :string
    change_column :addresses, :street, :string
    change_column :addresses, :phone, :string

    remove_index :addresses, :user_id
  end

end