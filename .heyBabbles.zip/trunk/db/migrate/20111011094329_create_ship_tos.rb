class CreateShipTos < ActiveRecord::Migration

  def self.up
    create_table :ship_tos do |t|
      t.integer :product_id
      t.integer :country_id
      t.integer :cost, :null => false, :default => 0
      t.integer :additional_cost, :null => false, :default => 0
      t.integer :product_limit, :null => false, :default => 0

      t.timestamps
    end
  end

  def self.down
    drop_table :shipp_tos
  end

end
