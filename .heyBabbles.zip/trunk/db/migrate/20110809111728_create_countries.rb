class CreateCountries < ActiveRecord::Migration
  def self.up
    create_table :countries do |t|
      t.string :title, :null => false, :limit => Country::TITLE
      t.integer :country_type, :null => false, :limit => Country::TYPE, :default => Country::COUNTRY_TYPE[:base]
    end
    add_index :countries, [:title], :unique => true, :name => 'title'
  end

  def self.down
    drop_table :countries
  end
end
