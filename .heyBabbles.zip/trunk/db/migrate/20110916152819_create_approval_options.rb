class CreateApprovalOptions < ActiveRecord::Migration
  def self.up
    create_table :approval_options do |t|
      t.string :preapproval_key, :unique => true, :null => false
      t.boolean :approved, :default => false, :null => false
      t.datetime :starting_date, :null => false
      t.datetime :ending_date, :null => false
      t.string :sender_email, :unique => true
      t.string :pin_type, :default => "NOT_REQUIRED", :null => false

      t.text :params, :limit => 2000, :null => false
      t.timestamps
    end
  end

  def self.down
    drop_table :approval_options
  end
end
# Serialized params is:
#t.decimal :current_total_amount_of_all_payments, :scale => 2
#t.integer :max_number_of_payments
#t.decimal :max_total_amount_of_all_payments, :scale => 2
#t.decimal :max_amount_per_payment, :scale => 2
#t.text :memo, :limit => 1000
#t.integer :max_number_of_payments_per_periods
#t.string :ipnNotificationUrl
#t.string :day_of_week
#t.string :payment_periods
#t.string :request_envelopes
#t.integer :date_of_months
#t.string :currencyCode
