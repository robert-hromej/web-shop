class RenameFieldsInPaymentOptions < ActiveRecord::Migration
  def self.up
    rename_column :payment_options, :sender_email, :user_id

    change_column :payment_options, :user_id, :integer

    add_column :payment_options, :txn_id, :string
  end

  def self.down
    rename_column :payment_options, :user_id, :sender_email

    change_column :payment_options, :sender_email, :string

    remove_column :payment_options, :txn_id
  end
end