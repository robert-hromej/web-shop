class ChangeColumnRatingInSellers < ActiveRecord::Migration
  def self.up
    rename_column :sellers, :rating, :rating_average_behavior

    change_column :sellers, :rating_average_behavior, :decimal, :default => 0, :precision => 5, :scale => 2
  end

  def self.down
    rename_column :sellers, :rating_average_behavior, :rating

    change_column :sellers, :rating, :integer
  end
end