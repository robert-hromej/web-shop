class AddItemTypeCategoryIndex < ActiveRecord::Migration
  def self.up
    add_index :item_types, [:size_category_id]
    add_index :item_types, [:color_category_id,:size_category_id], :name => "full_product_categories"
  end

  def self.down
    remove_index :item_types, [:size_category_id]
    remove_index :item_types, :name => "full_product_categories"
  end
end
