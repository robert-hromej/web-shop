class MoveColorsSizesToCategories < ActiveRecord::Migration
  def self.up
    drop_table :colors
    drop_table :sizes
    drop_table :product_combinations

    remove_column :item_types, :product_combination_id

    add_column :item_types, :color_category_id, :integer, :null => false
    add_column :item_types, :size_category_id, :integer, :null => false

    rename_column :combinations, :gender_id, :gender_category_id
  end

  def self.down
    rename_column :combinations, :gender_category_id, :gender_id

    remove_column :item_types, :size_category_id
    remove_column :item_types, :color_category_id

    add_column :item_types, :product_combination_id, :integer
    add_index :item_types, :product_combination_id

    create_table :product_combinations do |t|
      t.integer :color_id
      t.integer :size_id
    end

    create_table :sizes do |t|
      t.string :title
    end

    create_table :colors do |t|
      t.string :title
    end
  end
end
