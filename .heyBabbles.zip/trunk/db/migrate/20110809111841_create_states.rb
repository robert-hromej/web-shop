class CreateStates < ActiveRecord::Migration
  def self.up
    create_table :states do |t|
      t.string :title, :null => false, :limit => State::TITLE
      t.integer :country_id, :null => false
    end
    add_index :states, [:title, :country_id], :unique => true, :name => 'title'
  end

  def self.down
    drop_table :states
  end
end
