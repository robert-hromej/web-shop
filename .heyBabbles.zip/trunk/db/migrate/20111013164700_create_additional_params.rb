class CreateAdditionalParams < ActiveRecord::Migration
  def self.up
    create_table :additional_params do |t|
      t.string :params_name
      t.string :params_value
      t.integer :identifier_id
      t.string :identifier_type

      t.timestamps
    end
  end

  def self.down
    drop_table :additional_params
  end
end
