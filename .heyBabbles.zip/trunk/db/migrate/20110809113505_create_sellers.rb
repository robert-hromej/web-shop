class CreateSellers < ActiveRecord::Migration
  def self.up
    create_table :sellers do |t|
      t.integer :user_id
      t.string :first_name, :limit => Seller::FIRST_NAME
      t.string :last_name, :limit => Seller::LAST_NAME
      t.integer :rating

      t.timestamps
    end
  end

  def self.down
    drop_table :sellers
  end
end
