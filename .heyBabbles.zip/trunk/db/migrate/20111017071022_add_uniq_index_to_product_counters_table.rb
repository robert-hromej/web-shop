class AddUniqIndexToProductCountersTable < ActiveRecord::Migration

  def self.up
    ProductCounter.delete_all
    add_index :product_counters, [:service_type, :product_id], :unique => true
  end

  def self.down
    remove_index :product_counters, [:service_type, :product_id]
  end

end
