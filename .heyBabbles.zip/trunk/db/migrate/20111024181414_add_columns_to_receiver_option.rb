class AddColumnsToReceiverOption < ActiveRecord::Migration
  def self.up
    add_column :receiver_options, :subtotal, :float
    add_column :receiver_options, :total_tax, :float
    add_column :receiver_options, :total_shipping, :float
  end

  def self.down
    remove_column :receiver_options, :total_shipping
    remove_column :receiver_options, :total_tax
    remove_column :receiver_options, :subtotal
  end
end
