class CreateStores < ActiveRecord::Migration
  def self.up
    create_table :stores do |t|
      t.string :name, :limit => Store::NAME
      t.integer :seller_id
      t.text :return_policy, :limit => Store::RETURN_POLICY
      t.text :description, :limit => Store::DESCRIPTION
      t.text :bio, :limit => Store::BIO
      t.string :logo_file_name
      t.string :logo_content_type
      t.integer :logo_file_size
      t.datetime :logo_update_at

      t.timestamps
    end
  end

  def self.down
    drop_table :stores
  end
end
