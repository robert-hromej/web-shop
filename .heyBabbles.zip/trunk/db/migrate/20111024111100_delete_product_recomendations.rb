class DeleteProductRecomendations < ActiveRecord::Migration
  def self.up
    drop_table :product_recomendations
  end

  def self.down
    create_table :product_recomendations do |t|
      t.integer :product_id
      t.integer :user_id
      t.timestamps
    end
  end
end