class RenameSeasonProductsTable < ActiveRecord::Migration

  def self.up
    rename_table :season_products, :product_seasons
  end

  def self.down
    rename_table :product_seasons, :season_products
  end

end
