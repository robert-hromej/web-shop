class AddCombinationCategoryIndex < ActiveRecord::Migration
  def self.up
    add_index :combinations, [:category_id,:subcategory_id,:gender_category_id], :name => "full_categories"
    add_index :combinations, [:category_id,:gender_category_id]
  end

  def self.down
    remove_index :combinations, :name => "full_categories"
    remove_index :combinations, [:category_id,:gender_category_id]
  end
end
