class CreateCombinations < ActiveRecord::Migration
  def self.up
    create_table :combinations do |t|
      t.integer :category_id
      t.integer :subcategory_id
      t.integer :gender_id
    end
  end

  def self.down
    drop_table :combinations
  end
end
