class AddPaydImagesFieldToProductTable < ActiveRecord::Migration

  def self.up
    add_column :products, :payd_images, :integer, :default => 2, :null => false
    add_column :products, :main_image_id, :integer, :default => 0, :null => false
    remove_column :application_images, :paid
    remove_column :application_images, :main
  end

  def self.down
    remove_column :products, :payd_images
    remove_column :products, :main_image_id
    add_column :application_images, :paid, :boolean, :null => false, :default => false
    add_column :application_images, :main, :boolean, :null => false, :default => false
  end

end
