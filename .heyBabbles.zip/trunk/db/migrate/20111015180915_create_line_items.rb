class CreateLineItems < ActiveRecord::Migration
  def self.up
    create_table :line_items do |t|
      t.belongs_to :item_type
      t.belongs_to :ship_to
      t.belongs_to :user
      t.integer :count

      t.timestamps
    end

    add_index :line_items, [:item_type_id, :ship_to_id, :user_id], :unique => true

  end

  def self.down
    drop_table :line_items
  end
end
