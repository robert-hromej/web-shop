class CreatePaymentOptions < ActiveRecord::Migration
  def self.up
    create_table :payment_options do |t|
      t.string :sender_email, :null => false
      t.string :pay_key, :unique => true, :null => false
      t.text :params, :limit => 2000, :null => false
      t.timestamps
    end
  end

  def self.down
    drop_table :payment_options
  end
end
