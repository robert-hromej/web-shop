class CreateApplicationImages < ActiveRecord::Migration
  def self.up
    create_table :application_images do |t|
      t.references :product
      t.boolean :main
      t.text :description
      t.integer :position, :null => false
      t.boolean :paid, :default => false

#     Paperclip columns
      t.string :image_file_name
      t.string :image_content_type
      t.integer :image_file_size
      t.datetime :image_updated_at

    end
  end

  def self.down
    drop_table :application_images
  end
end
