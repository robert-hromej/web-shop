class CreateItemTypesTable < ActiveRecord::Migration

  def self.up
    create_table :item_types do |t|
      t.integer :product_combination_id
      t.integer :product_id
      t.integer :price
      t.integer :item_count
      t.string :other_color
    end
    add_index :item_types, :product_combination_id
    add_index :item_types, :product_id
  end

  def self.down
    drop_table :item_types
  end

end
