class CreateProductCombinations < ActiveRecord::Migration
  def self.up
    create_table :product_combinations do |t|
      t.integer :color_id
      t.integer :size_id
    end
  end

  def self.down
    drop_table :product_combinations
  end
end
