class RenameFieldInProduct < ActiveRecord::Migration

  def self.up
    rename_column :products, :payd_images, :payed_images
  end

  def self.down
    rename_column :products, :payed_images, :payd_images
  end

end
