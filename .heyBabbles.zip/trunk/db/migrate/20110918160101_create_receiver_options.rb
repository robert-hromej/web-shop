class CreateReceiverOptions < ActiveRecord::Migration
  def self.up
    create_table :receiver_options do |t|
      t.text :description
      t.integer :custom_id # This is seller_id.
      t.integer :payment_opt_id, :null => false
      t.string :email, :null => false # this is receiver email should be PayPal one. I guess.

      t.timestamps
    end
  end

  def self.down
    drop_table :receiver_options
  end
end
