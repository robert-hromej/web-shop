class RenameFieldInInvoiceItemData < ActiveRecord::Migration
  def self.up
    rename_column :invoice_item_data, :invoice_data_id, :receiver_option_id
  end

  def self.down
    rename_column :invoice_item_data, :receiver_option_id, :invoice_data_id
  end
end
