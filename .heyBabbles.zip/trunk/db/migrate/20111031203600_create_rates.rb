class CreateRates < ActiveRecord::Migration
  def self.up
    create_table :rates do |t|
      t.integer :rater_id, :null => false
      t.integer :rateable_id, :null => false
      t.string :rateable_type, :null => false, :limit => 50
      t.integer :stars, :null => false, :limit => Rate::STAR_SIZE
      t.string :dimension, :null => false, :limit => Rate::DIMENSION_SIZE
    end

    add_index :rates, [:rater_id], :name => 'rater_id'
  end

  def self.down
    drop_table :rates
  end
end