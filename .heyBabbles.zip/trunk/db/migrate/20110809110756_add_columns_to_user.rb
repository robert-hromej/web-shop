class AddColumnsToUser < ActiveRecord::Migration
  def self.up
    add_column :users, :avatar_file_name, :string
    add_column :users, :avatar_content_type, :string
    add_column :users, :avatar_file_size, :integer
    add_column :users, :avatar_updated_at, :datetime
    add_column :users, :facebook_uid, :integer, :unique => true, :limit => 8
    add_column :users, :facebook_email, :string, :unique => true
    add_column :users, :registered, :boolean, :default => false
    add_column :users, :salt, :string
    add_column :users, :username, :string, :limit => User::NICKNAME
    add_column :users, :gender, :integer, :limit => User::GENDER
    add_column :users, :newsletter, :boolean
    add_column :users, :birthday, :date
    add_column :users, :remember_created_at, :datetime
    add_column :users, :about, :text, :limit => User::ABOUT

  end

  def self.down
    remove_column :users, :avatar_file_name
    remove_column :users, :avatar_content_type
    remove_column :users, :avatar_file_size
    remove_column :users, :avatar_updated_at
    remove_column :users, :facebook_uid
    remove_column :users, :facebook_email
    remove_column :users, :registered
    remove_column :users, :username
    remove_column :users, :address_id
    remove_column :users, :gender
    remove_column :users, :newsletter
    remove_column :users, :birthday
    remove_column :users, :about
    remove_column :users, :remember_created_at
  end
end
