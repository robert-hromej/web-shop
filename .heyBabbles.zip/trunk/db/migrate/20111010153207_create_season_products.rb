class CreateSeasonProducts < ActiveRecord::Migration

  def self.up
    create_table :season_products do |t|
      t.references :season
      t.references :product
      t.boolean :paid, :null => false, :default => false

      t.timestamps
    end

    add_index :season_products, :season_id
    add_index :season_products, :product_id

    add_index :season_products, [:season_id, :product_id], :unique => true
  end

  def self.down
    drop_table :season_products
  end

end
