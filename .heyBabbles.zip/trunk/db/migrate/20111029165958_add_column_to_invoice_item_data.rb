class AddColumnToInvoiceItemData < ActiveRecord::Migration
  def self.up
    add_column :invoice_item_data, :status, :integer
  end

  def self.down
    remove_column :invoice_item_data, :status
  end
end
