class CreateFeaturedVendors < ActiveRecord::Migration
  def self.up
    create_table :featured_vendors do |t|
      t.integer :seller_id
      t.date :start_date
      t.date :end_date
    end
  end

  def self.down
    drop_table :featured_vendors
  end
end
