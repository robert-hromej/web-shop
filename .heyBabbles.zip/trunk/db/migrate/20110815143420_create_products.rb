class CreateProducts < ActiveRecord::Migration
  def self.up
    create_table :products do |t|
      t.integer :currency_id
      t.integer :seller_id
      t.integer :store_id
      t.integer :combination_id

      t.float :price, :precision => 5, :scale => 2
      t.integer :accepted
      t.text :description
      t.text :return_policy
      t.string :name
      t.string :product_sid
      t.text :shipping_policy
      t.datetime :expiration_date
      t.boolean :new
      t.integer :ship_from_id

      t.timestamps
    end
  end

  def self.down
    drop_table :products
  end
end
