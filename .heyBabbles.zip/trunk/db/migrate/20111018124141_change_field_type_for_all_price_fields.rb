class ChangeFieldTypeForAllPriceFields < ActiveRecord::Migration

  def self.up
    change_column :invoice_item_data, :price, :float, :precision => 5, :scale => 2, :default => 0, :null => false
    change_column :invoice_item_data, :item_price, :float, :precision => 5, :scale => 2, :default => 0, :null => false
    change_column :item_types, :price, :float, :precision => 5, :scale => 2, :default => 0, :null => false
    change_column :products, :price, :float, :precision => 5, :scale => 2, :default => 0, :null => false
    change_column :seasons, :cost, :float, :precision => 5, :scale => 2, :default => 0, :null => false
    change_column :services, :price, :float, :precision => 5, :scale => 2, :default => 0, :null => false
    change_column :ship_tos, :cost, :float, :precision => 5, :scale => 2, :default => 0, :null => false
    change_column :ship_tos, :additional_cost, :float, :precision => 5, :scale => 2, :default => 0, :null => false
  end

  def self.down
    change_column :invoice_item_data, :price, :float, :null => false
    change_column :invoice_item_data, :item_price, :float, :null => false
    change_column :item_types, :price, :integer
    change_column :products, :price, :float
    change_column :seasons, :cost, :float
    change_column :services, :price, :float
    change_column :ship_tos, :cost, :integer, :default => 0, :null => false
    change_column :ship_tos, :additional_cost, :integer, :default => 0, :null => false
  end

end
