class CreateProductCounters < ActiveRecord::Migration
  def self.up
    create_table :product_counters do |t|
      t.references :product
      t.integer :service_type

      t.integer :points, :null => false, :default => 0
      t.boolean :payed, :null => false, :default => false
    end
  end

  def self.down
    drop_table :product_counters
  end
end
