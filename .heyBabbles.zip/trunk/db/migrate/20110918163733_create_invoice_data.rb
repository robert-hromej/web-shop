class CreateInvoiceData < ActiveRecord::Migration
  def self.up
    create_table :invoice_data do |t|
      t.float :total_tax, :precision => 5, :scale => 2, :null => false
      t.float :total_shipping, :precision => 5, :scale => 2, :null => false
      t.float :subtotal, :precision => 5, :scale => 2, :null => false
      t.integer :receiver_opt_id, :null => false

      t.timestamps
    end
  end

  def self.down
    drop_table :invoice_data
  end
end
