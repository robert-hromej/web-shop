class CreateFeedbacks < ActiveRecord::Migration
  def self.up
    create_table :feedbacks do |t|
      t.integer :writer_id, :null => false
      t.integer :writeable_id, :null => false
      t.string :writeable_type, :null => false, :limit => 50
      t.string :feedback_text, :null => false, :limit => Feedback::MAX_FEEDBACK_SIZE
      t.integer :write_through_id, :null => false
      t.string :write_through_type, :null => false, :limit => 50

      t.timestamps
    end

    add_index :feedbacks, [:writer_id], :name => 'writer_id'
  end

  def self.down
    drop_table :feedbacks
  end
end