class CreateAddresses < ActiveRecord::Migration
  def self.up
    create_table :addresses do |t|
      t.integer :state_id #, :null => false
      t.integer :country_id #, :null => false
      t.integer :user_id #, :null => false
      t.string :zip
      t.string :city
      t.string :street
      t.string :phone

    end
  end

  def self.down
    drop_table :addresses
  end
end
