class AddFieldToProductCountersTable < ActiveRecord::Migration

  def self.up
    add_column :product_counters, :status, :boolean, :default => false, :null => false
  end

  def self.down
    remove_column :product_counters, :status
  end

end
