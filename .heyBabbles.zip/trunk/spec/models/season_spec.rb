require 'spec_helper'

describe Season do

  def params
    {
        :start_date => Time.now,
        :end_date => (Time.now + 10.days),
        :title => "Home featured",
        :cost => 123.65
    }
  end

  it { should respond_to :start_date }
  it { should respond_to :end_date }
  it { should respond_to :title }
  it { should respond_to :description }
  it { should respond_to :product_seasons }

  it { should_not be_valid }

  {
      :start_date => ["", nil],
      :end_date => ["name", "", nil],
      :title => ["", ("s" * 200), "s"],
      :cost => [nil, -123, -123.45, "bla bla bla", ""]
  }.each do |field, values|
    values.each do |value|
      it "should not be valid if field #{field} with value #{value.inspect}" do
        Season.new(params.merge(field => value)).should_not be_valid
      end
    end
  end

end

# == Schema Information
#
# Table name: seasons
#
#  id          :integer(4)      not null, primary key
#  title       :string(255)
#  description :text
#  start_date  :date
#  end_date    :date
#  cost        :float
#  created_at  :datetime
#  updated_at  :datetime
#

