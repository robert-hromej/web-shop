require 'spec_helper'


describe PaymentOption, :focus => true do

  def params
    user_id ||= Factory(:user).id
    {
        :pay_key => "AP-1234", :params => {:key => "value"},
        :user_id => user_id
    }
  end

  it { should respond_to :user_id }
  it { should respond_to :params }
  it { should respond_to :pay_key }
  it { should respond_to :sender }

  context "with valid params" do
    it { PaymentOption.new(params).should be_valid }
  end

  it "'pay_key' should be unique" do
    PaymentOption.create(params)
    PaymentOption.new(params).should_not be_valid
  end

  it "should not be valid if valid params missed" do
    params.each do |key, value|
      PaymentOption.new(params.merge(key => "")).should_not be_valid
    end
  end

  context "Call" do
    before(:all) { @payment_option = Factory(:payment_option, :params => params[:params]) }
    after(:all) { clean_db }

    it "#sender should return User" do
      @payment_option.sender.should be_a(User)
      @payment_option.sender.should_not be_nil
    end

    it "#params should be a Hash" do
      @payment_option.params.should be_a(Hash)
    end

  end

end

# == Schema Information
#
# Table name: payment_options
#
#  id           :integer(4)      not null, primary key
#  sender_email :string(255)     not null
#  pay_key      :string(255)     not null
#  params       :text            default(""), not null
#  created_at   :datetime
#  updated_at   :datetime
#

