require 'spec_helper'

describe Rate do

  context "have db" do
    context "columns" do
      it { should have_db_column(:rater_id).of_type(:integer).with_options(:null => false) }
      it { should have_db_column(:rateable_id).of_type(:integer).with_options(:null => false) }
      it { should have_db_column(:rateable_type).of_type(:string).with_options(:null => false, :limit => 50) }
      it { should have_db_column(:stars).of_type(:integer).with_options(:null => false, :limit => 2) }
      it { should have_db_column(:dimension).of_type(:string).with_options(:null => false, :limit => 30) }
    end

    context "indexes" do
      it { should have_db_index(:rater_id) }
    end
  end

  context "have mass assignment" do
    it { should allow_mass_assignment_of(:rate) }
    it { should allow_mass_assignment_of(:dimension) }
  end

  context "have associations" do
    context "belongs" do
      it { should belong_to(:rater) }
      it { should belong_to(:rateable) }
    end
  end

  context "have validations" do
    context "presence" do
      it { should validate_presence_of(:rater_id) }
      it { should validate_presence_of(:rateable_id) }
      it { should validate_presence_of(:rateable_type) }
      it { should validate_presence_of(:stars) }
      it { should validate_presence_of(:dimension) }
    end
  end

end