require 'spec_helper'

describe LineItem do

  describe "Associations" do
    it { should belong_to(:user) }
    it { should belong_to(:item_type) }
    it { should belong_to(:ship_to) }
    it { should validate_presence_of(:item_type_id) }
    it { should validate_numericality_of(:count) }
  end

  describe "Call" do
    before(:each) do
      @line_item = stub_model(LineItem, :count => 7, :item_type => stub_model(ItemType, :id => 1), :ship_to => stub_model(ShipTo, :id => 1))
    end

    describe "already_in_cart?" do
      before(:each) do
        @cart = [{1 => {:ship_to => 1, :count => 1}}, {2 => {:ship_to => 2, :count => 7}}, {1 => {:ship_to => 2, :count => 1}}]
      end

      it "should be true if item is in cart" do
        @line_item.already_in_cart?(@cart).should be_true
      end
      it "should be false if item isn't in cart" do
        @line_item.ship_to.id = 4
        @line_item.already_in_cart?(@cart).should be_false
      end
      it "should find the item even if 2 items have the same item_type.id" do
        @line_item.ship_to.id = 2
        @line_item.already_in_cart?(@cart).should be_true
      end
    end

    describe "to_cart_hash" do
      it "should convert line_item to hash used in session[:cart]" do
        @line_item.to_cart_hash.should eq({1 => {:ship_to => 1, :count => 7}})
      end
    end

    describe "self" do
      describe "#build_from_params" do
        it "should build a line items from params hash" do
          origin = Factory(:line_item)
          pattern = lambda { |line_item| {:destination => line_item.ship_to_id,
                                          :product_id => line_item.item_type.product_id,
                                          :quantity => line_item.count,
                                          :color => line_item.item_type.color_category_id,
                                          :size => line_item.item_type.size_category_id} }

          line_item = LineItem.build_from_params(pattern.call(origin))
          pattern.call(line_item).should eq(pattern.call(origin))
        end
      end
    end

  end

  describe "validations" do

    before(:each) do
      @line_item = LineItem.new(:item_type => stub_model(ItemType, :id => 1, :item_count => 14), :ship_to => stub_model(ShipTo, :id => 1), :count => 7)
    end

    it "should accept a valid object" do
      @line_item.should be_valid
    end

    it "should reject an object without count" do
      @line_item.count = nil
      @line_item.should_not be_valid
    end

    it "should reject an object with count > item_type.item_count" do
      @line_item.count = 20
      @line_item.should_not be_valid
    end

    it "should reject an object with count == 0" do
      @line_item.count = 0
      @line_item.should_not be_valid
    end

    it "should reject an object with float count" do
      @line_item.count = 1.24
      @line_item.should_not be_valid
    end

  end

end

# == Schema Information
#
# Table name: line_items
#
#  id           :integer(4)      not null, primary key
#  item_type_id :integer(4)
#  ship_to_id   :integer(4)
#  user_id      :integer(4)
#  count        :integer(4)
#  created_at   :datetime
#  updated_at   :datetime
#

