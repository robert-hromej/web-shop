require 'spec_helper'


describe ReceiverOption do
  def params
    {:email => "a@a.com",
     :description => "bla",
     :payment_opt_id => 1,
     :custom_id => 1,
     :subtotal => 15.00,
     :total_tax => 10.00,
     :total_shipping => 15.00}
  end

  context "have associations" do
    context "has_many" do
      it { should have_many(:feedbacks) }
    end
  end

  it { should respond_to :email }
  it { should respond_to :description }
  it { should respond_to :products }
  it { should respond_to :seller }

  it { should respond_to :subtotal }
  it { should respond_to :total_tax }
  it { should respond_to :total_shipping }
  it { should respond_to :products }

  context "with valid params" do
    it { ReceiverOption.new(params).should be_valid }
  end

  it "should not be valid if valid params missed" do
    params.keys.each do |key|
      PaymentOption.new(params.merge(key => "")).should_not be_valid
    end
  end

  context "Call" do

    before(:each) do
      @roptions = create(:receiver_option)
      @product = create(:invoiced_product, :receiver_option_id => @roptions.id)
    end

    it "#seller should return Seller" do
      @roptions.seller.should be_a(Seller)
      @roptions.seller.should_not be_nil
    end

    it "#payment_option should return PaymentOption" do
      @roptions.payment_option.should be_a(PaymentOption)
      @roptions.payment_option.should_not be_nil
    end

    it "#products should return collection of Product`s" do
      @roptions.products.should be_a(Array)
      @roptions.products.should include(@product)
    end

  end

  context "#datum_for_seller" do
    before(:each) do
      @seller = Factory(:seller)
      roptions = Factory(:receiver_option, :custom_id => @seller.id)
      product = Factory(:invoiced_product, :receiver_option_id => roptions.id)
      product2 = Factory(:invoiced_product, :receiver_option_id => roptions.id)
      product.update_attributes(:status => 1)
      product2.update_attributes(:status => 2)
    end

    it "should return Array" do
      ReceiverOption.datum_for_seller(@seller.id, nil).should be_a(Array)
    end

    describe "should filtered" do
      hash = {nil => 1, 1 => 1, 2 => 1, 3 => 0}
      hash.each do |key, value|
        it "if filter-key = #{key} then array size shold be #{value}" do
          ReceiverOption.datum_for_seller(@seller.id, key).size.should == value
        end
      end
    end
  end

  context "#products_with_item_type" do
    before(:each) do
      @roptions = Factory(:receiver_option)
      @product = Factory(:invoiced_product, :receiver_option_id => @roptions.id, :identifier_type => "Product")
      product2 = Factory(:invoiced_product, :receiver_option_id => @roptions.id, :identifier_type => "Season")
    end

    it "should return 1 product" do
      @roptions.products_with_item_type.should be_a(ActiveRecord::Relation)
      @roptions.products_with_item_type.should include(@product)
      @roptions.products_with_item_type.count.should == 1
    end

  end
end

# == Schema Information
#
# Table name: receiver_options
#
#  id             :integer(4)      not null, primary key
#  description    :text
#  custom_id      :integer(4)
#  payment_opt_id :integer(4)      not null
#  email          :string(255)     not null
#  created_at     :datetime
#  updated_at     :datetime
#

