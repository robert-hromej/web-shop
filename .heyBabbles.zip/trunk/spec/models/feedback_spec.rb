require 'spec_helper'

describe Feedback do

  context "have db" do
    context "columns" do
      it { should have_db_column(:writer_id).of_type(:integer).with_options(:null => false) }
      it { should have_db_column(:writeable_id).of_type(:integer).with_options(:null => false) }
      it { should have_db_column(:writeable_type).of_type(:string).with_options(:null => false, :limit => 50) }
      it { should have_db_column(:feedback_text).of_type(:string).with_options(:null => false, :limit => 400) }
      it { should have_db_column(:write_through_id).of_type(:integer).with_options(:null => false) }
      it { should have_db_column(:write_through_type).of_type(:string).with_options(:null => false, :limit => 50) }
      it { should have_db_column(:created_at).of_type(:datetime)}
    end

    context "indexes" do
      it { should have_db_index(:writer_id) }
    end
  end

  context "have mass assignment" do
    it { should allow_mass_assignment_of(:feedback_text) }
    it { should allow_mass_assignment_of(:writeable_id) }
    it { should allow_mass_assignment_of(:writeable_type) }
    it { should allow_mass_assignment_of(:write_through_type) }
    it { should allow_mass_assignment_of(:write_through_id) }
    it { should allow_mass_assignment_of(:writer_id) }
  end

  context "have associations" do
    context "belongs" do
      it { should belong_to(:writer) }
      it { should belong_to(:writeable) }
      it { should belong_to(:write_through) }
    end

    context "has_many" do
      it { should have_many(:ratings_given) }
    end
  end

  context "have validations" do
    context "presence" do
      it { should validate_presence_of(:feedback_text) }
      it { should validate_presence_of(:writer_id) }
      it { should validate_presence_of(:writeable_id) }
      it { should validate_presence_of(:writeable_type) }
      it { should validate_presence_of(:write_through_id) }
      it { should validate_presence_of(:write_through_type) }
    end

    context "length" do
      it { should ensure_length_of(:feedback_text).is_at_least(5) }
      it { should ensure_length_of(:feedback_text).is_at_most(400) }
    end
  end

end