require 'spec_helper'


describe FeaturedVendor do
  def params
    start_date = Time.now + 200.days
    end_date = start_date + 10.days
    {:end_date => end_date, :start_date => start_date, :seller_id => Factory(:seller).id}
  end

  def create_vendors
    @vendors = []
    2.times { @vendors << Factory(:featured_vendor) }
  end

  it { should respond_to(:seller) }
  it { should respond_to(:seller_id) }
  it { should respond_to(:id) }
  it { should respond_to(:start_date) }
  it { should respond_to(:end_date) }
  it { should_not be_valid }

  it "should be valid for valid 'params'" do
    instance = FeaturedVendor.new(params)
    instance.should be_valid, instance.errors
  end

  it "#ascendants should return 'vendors'" do
    create_vendors
    FeaturedVendor.ascendants.should eq @vendors
  end

  {:start_date => ["", Date.today],
   :end_date => ["", Date.today],
   :seller_id => ["", 10000, "r"]}.each do |field, values|
    values.each do |value|
      it "should not be valid for '#{field}' with value '#{value.inspect}'" do
        create_vendors
        instance = FeaturedVendor.new(params.merge(field => value))
        instance.should_not be_valid, instance.attributes.inspect
      end
    end
  end

end

# == Schema Information
#
# Table name: featured_vendors
#
#  id         :integer(4)      not null, primary key
#  seller_id  :integer(4)
#  start_date :date
#  end_date   :date
#

