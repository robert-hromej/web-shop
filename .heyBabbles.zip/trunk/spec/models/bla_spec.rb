require 'spec_helper'

describe Product do
  it "bla" do
    product = Factory(:product_with_impressions)
    main_image = mock_model(ApplicationImage)
    main_image.stub(:image_file_name => "bla.jpg")
    main_image.stub(:id => 10)
    product.stub(:main_image => main_image)
    product.main_image_path.should == "10/medium/bla.jpg"
    #product.main_image_path
  end
end