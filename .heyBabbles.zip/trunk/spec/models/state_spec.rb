require 'spec_helper'

describe State do

  def params
    country = Factory(:country)
    country.states.first.update_attribute(:title, "State copy")
    {:title => "State", :country_id => country.id}
  end

  it { should respond_to(:addresses) }
  it { should respond_to(:country) }
  it { should respond_to(:id) }
  it { should respond_to(:title) }
  it { should respond_to(:country_id) }

  it "should be valid for 'params'" do
    instance = State.new(params)
    instance.should be_valid, instance.errors
  end

  {:title => [nil, "", "STATE COPY", "S"*31, "S"], :country_id => ["", nil]}.each do |field, values|
    values.each do |value|
      it "should not be valid for '#{field}' with value #{value.inspect}" do
        State.new(params.merge(field => value)).should_not be_valid
      end
    end
  end

  {:country_type => [2, 4, 6]}.each do |field, values|
    values.each do |value|
      it "should not be valid for '#{field}' with value '#{value.inspect}" do
        country = Country.create(:title => "Country", field => value)
        State.new(:title => "State", :country_id => country.id).should_not be_valid
      end
    end
  end

end

# == Schema Information
#
# Table name: states
#
#  id         :integer(4)      not null, primary key
#  title      :string(30)      not null
#  country_id :integer(4)      not null
#

