require 'spec_helper'

describe Store do
  before(:all) { clean_db }
  before(:each) do
    @seller = create(:seller)
    @attr = {:name => "Store Name Store", :return_policy => "Return Policy Store",
             :description => "Description Store", :bio => "Bio Store", :logo => Rails.root.join("spec/fixtures/rails.png").open}
  end

  it "should create new object with valid attributes" do
    @seller.stores.create!(@attr)
  end

  describe "should have attribute" do
    before(:each) do
      @store = @seller.stores.create!(@attr)
    end

    it "a name attribute" do
      @store.should respond_to(:name)
    end

    it "a Return policy attribute" do
      @store.should respond_to(:return_policy)
    end

    it "a Description attribute" do
      @store.should respond_to(:description)
    end

    it "a Bio attribute" do
      @store.should respond_to(:bio)
    end
  end

  describe "seller associations" do
    before(:each) do
      @store = @seller.stores.create(@attr)
    end

    it "should have a seller attribute" do
      @store.should respond_to(:seller)
    end

    it "should have the right associated seller" do
      @store.seller_id.should == @seller.id
      @store.seller.should == @seller
    end
  end

  describe "validations" do
    #todo need Bogdan review
    #it "should require a Seller_id" do
    #  Store.new(@attr).should_not be_valid
    #end

    it "should require nonblank name" do
      @seller.stores.build(@attr.merge(:name => "")).should_not be_valid
    end

    it "should reject long name" do
      @seller.stores.build(@attr.merge(:name=> "a" * (Store::NAME + 1))).should_not be_valid
    end

    it "should require nonblank Return_policy" do
      @seller.stores.build(@attr.merge(:return_policy => "")).should_not be_valid
    end

    it "should reject long Return_policy" do
      @seller.stores.build(@attr.merge(:return_policy => "a" * (Store::RETURN_POLICY + 1))).should_not be_valid
    end

    it "should require nonblank Description" do
      @seller.stores.build(@attr.merge(:description => "")).should_not be_valid
    end

    it "should reject long Description" do
      @seller.stores.build(@attr.merge(:description => "a" * (Store::DESCRIPTION + 1))).should_not be_valid
    end

    it "should require nonblank Bio" do
      @seller.stores.build(@attr.merge(:bio => "")).should_not be_valid
    end

    it "should reject long Bio" do
      @seller.stores.build(@attr.merge(:bio => "a" * (Store::BIO + 1))).should_not be_valid
    end
  end

end

# == Schema Information
#
# Table name: stores
#
#  id                :integer(4)      not null, primary key
#  name              :string(100)
#  seller_id         :integer(4)
#  return_policy     :text
#  description       :text
#  bio               :text
#  logo_file_name    :string(255)
#  logo_content_type :string(255)
#  logo_file_size    :integer(4)
#  logo_update_at    :datetime
#  created_at        :datetime
#  updated_at        :datetime
#

