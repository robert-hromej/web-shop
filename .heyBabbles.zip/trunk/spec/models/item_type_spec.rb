require 'spec_helper'

describe ItemType do

  def params
    Factory.build(:item_type).attributes
  end

  specify { ItemType.new(params).should be_valid }
  #specify { ItemType.create!(params) }
  it { should_not be_valid }

  it { should respond_to(:price) }
  it { should respond_to(:item_count) }
  it { should respond_to(:product) }
  it { should respond_to(:color) }
  it { should respond_to(:size) }

  {
      :product_id => ["", nil, "abc", 0, -123],
      :color_category_id => ["", nil, "abc", 0, -134],
      :size_category_id => ["", nil, "abc", 0, -123],
      :price => ["", nil, "abc", -123, -123.45, 1.234],
      :item_count => ["", nil, "abc", -123, -123.45]
  }.each do |field, values|
    values.each do |value|
      it "should not be valid for '#{field}' with value '#{value.inspect}'" do
        ItemType.new(params.merge(field => value)).should_not be_valid
      end
    end
  end

end

# == Schema Information
#
# Table name: item_types
#
#  id                :integer(4)      not null, primary key
#  product_id        :integer(4)
#  price             :integer(4)
#  item_count        :integer(4)
#  other_color       :string(255)
#  deleted_at        :datetime
#  color_category_id :integer(4)      not null
#  size_category_id  :integer(4)      not null
#

