require 'spec_helper'

describe Service do

  def params
    Factory(:home_service).attributes
  end

  it { should respond_to :title }
  it { should respond_to :price }
  it { should respond_to :points }
  it { should respond_to :product_counters }

  it "should be valid for 'params'" do
    instance = Service.new(params)
    instance.should be_valid, instance.errors
  end

  it "should have constant TYPE" do
    Service::TYPE.should eq({:home => 1, :search => 2})
  end

  {
      :title => ["s", "", nil, ("a"*60)],
      :price => ["", nil, "0.001", -123, -123.45],
      :service_type => ["s", "", nil, "0.001"],
      :points => ["", "r", nil, "0.1", "0.001", -123, -123.45]
  }.each do |field, values|
    values.each do |value|
      it "should not be valid for '#{field}' with value '#{value.inspect}'" do
        instance = Service.new(params.merge(field => value))
        instance.should_not be_valid, instance.attributes.inspect
      end
    end
  end


end

# == Schema Information
#
# Table name: services
#
#  id           :integer(4)      not null, primary key
#  title        :string(255)
#  description  :text
#  price        :float
#  points       :integer(4)
#  service_type :integer(4)
#

