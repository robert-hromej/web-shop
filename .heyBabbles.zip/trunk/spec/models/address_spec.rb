require 'spec_helper'

describe Address do

  it { should respond_to(:city) }
  it { should respond_to(:country) }
  it { should respond_to(:country_id) }
  it { should respond_to(:phone) }
  it { should respond_to(:state) }
  it { should respond_to(:state_id) }
  it { should respond_to(:street) }
  it { should respond_to(:user) }
  it { should respond_to(:user_id) }
  it { should respond_to(:zip) }
  it { should respond_to(:id) }

  describe "CREATE" do
    describe "FAIL if has seller" do
      before(:each) do
        @attr = {:city => 'bla', :country_id => 1, :state_id => 1, :zip => 1, :phone => 1, :street => 'bla'}
      end

      it 'should not save without city' do
        address = Address.new(@attr.merge!(:city => nil))
        address.stub(:skip? => false)
        address.should_not be_valid
      end

      it 'should not save without country_id' do
        address = Address.new(@attr.merge!(:country_id => nil))
        address.stub(:skip? => false)
        address.should_not be_valid
      end

      it 'should not save without state_id' do
        address = Address.new(@attr.merge!(:state_id => nil))
        address.stub(:skip? => false)
        address.should_not be_valid
      end

      it 'should not save when country_id is not numericality' do
        address = Address.new(@attr.merge!(:country_id => 'bla'))
        address.stub(:skip? => false)
        address.should_not be_valid
      end

      it 'should not save when state_id is not numericality' do
        address = Address.new(@attr.merge!(:state_id => 'bla'))
        address.stub(:skip? => false)
        address.should_not be_valid
      end

      it 'should not save without zip' do
        address = Address.new(@attr.merge!(:zip => nil))
        address.stub(:skip? => false)
        address.should_not be_valid
      end

      it 'should not save without phone' do
        address = Address.new(@attr.merge!(:phone => nil))
        address.stub(:skip? => false)
        address.should_not be_valid
      end

      it 'should not save when zip is not numericality' do
        address = Address.new(@attr.merge!(:zip => 'bla'))
        address.stub(:skip? => false)
        address.should_not be_valid
      end

      it 'should not save when phone is not numericality' do
        address = Address.new(@attr.merge!(:phone => 'bla'))
        address.stub(:skip? => false)
        address.should_not be_valid
      end
    end

    context "SUCCESS if all attr valid" do
      it 'should be save with valid data' do
        user = Factory(:default_user)
        @attr = { :city => 'bla', :country_id => 1, :state_id => 1, :zip => 1, :phone => 1, :street => 'bla',
                  :user_id => user.id }
        address = Address.new(@attr)
        address.should be_valid
      end
    end
    context "SUCCESS if skip == 1" do
      it 'should be save with nil data and "skip = 1"' do
        user = Factory(:default_user)
        @attr = { :city => nil, :country_id => nil, :state_id => nil, :zip => nil, :phone => nil, :street => nil,
                 :user_id => user.id }
        address = Address.new(@attr)
        address.should be_valid
      end

      it 'should be save with invalid data and "skip = 1"' do
        user = Factory(:default_user)
        @attr = { :city => nil, :country_id => 'bla', :state_id => 'bla', :zip => 'bla', :phone => 'bla', :street => nil,
                 :user_id => user.id }
        address = Address.new(@attr)
        address.should be_valid
      end
    end
  end

end

# == Schema Information
#
# Table name: addresses
#
#  id         :integer(4)      not null, primary key
#  state_id   :integer(4)
#  country_id :integer(4)
#  user_id    :integer(4)
#  zip        :string(255)
#  city       :string(255)
#  street     :string(255)
#  phone      :string(255)
#

