require 'spec_helper'


describe Category do
  def params
    @attr = {:title => "Category", :level => 1}
  end

  it "should have constant 'MAIN_ONE'" do
    Category::MAIN_ONE.should eq({"Babies"=>1, "Maternity"=>2, "Daddies"=>3, "Kids"=>4})
  end
  it { Category.new(params).should be_valid }
  it { Category.new({}).should_not be_valid }
  it { should respond_to(:combinations) }
  it { should respond_to(:sub_combinations) }
  it { should respond_to(:gender_combinations) }
  it { should respond_to(:color_item_types) }
  it { should respond_to(:size_item_types) }

  it { should respond_to(:main_products) }
  it { should respond_to(:sub_products) }
  it { should respond_to(:gender_products) }
  it { should respond_to(:size_products) }
  it { should respond_to(:color_products) }

  it { should respond_to(:level) }

  it "return child categories" do
    pending "Fedia"
  end

end

# == Schema Information
#
# Table name: categories
#
#  id    :integer(4)      not null, primary key
#  title :string(255)
#  level :integer(4)
#

