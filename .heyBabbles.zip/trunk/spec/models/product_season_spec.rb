require 'spec_helper'

describe ProductSeason do

  def params
    {
        :paid => true,
        :season_id => Factory(:season).id,
        :product_id => Factory(:item).id
    }
  end

  it { should respond_to :season }
  it { should respond_to :product }
  it { should respond_to :paid }

  it { should_not be_valid }

  it "should be_valid" do
    instance = ProductSeason.new(params)
    instance.should be_valid, instance.errors
  end

  {
      :paid => ["", nil],
      :product_id => ["", 1000000, nil, 0, -123, -123.45],
      :season_id => ["", 1000000, nil, 0, -123, -123.45]
  }.each do |field, values|
    values.each do |value|
      it "should not be valid if field '#{field}' with value #{value.inspect}" do
        instance = ProductSeason.new(params.merge(field => value))
        instance.should_not be_valid, instance.attributes.inspect
      end
    end
  end

  it "should not be valid if present thid object"

end

# == Schema Information
#
# Table name: product_seasons
#
#  id         :integer(4)      not null, primary key
#  season_id  :integer(4)
#  product_id :integer(4)
#  paid       :boolean(1)      default(FALSE), not null
#  created_at :datetime
#  updated_at :datetime
#

