require 'spec_helper'


describe InvoiceItemData do
  def params
    {
        :item_price => 15.00, :item_count => 10, :price => 15.00,
        :identifier_id => 1, :identifier_type => "Product",
        :receiver_option_id => first_instance_of(:receiver_option, :method => :id, :class => ReceiverOption)
    }
  end

  it { should respond_to :receiver_option }
  it { should respond_to :item_price }
  it { should respond_to :item_count }
  it { should respond_to :price }
  it { should respond_to :identifier }
  it { should respond_to :clone_info }
  it { should delegate(:address_of_seller).to(:identifier) }

  it "should be valid for 'params'" do
    instance = InvoiceItemData.new(params)
    instance.should be_valid, instance.errors
  end

  {
      :item_price => ["", nil, "0.001"], :price => ["", nil, "0.001"],
      :item_count => ["", nil, "0.01", ".01", "0.001"], :receiver_option_id => [1000, "", nil],
      :identifier_id => ["", nil], :identifier_type => ["", nil]
  }.each do |field, values|
    values.each do |value|
      it "should not be valid for '#{field}' with value '#{value.inspect}'" do
        instance = InvoiceItemData.new(params.merge(field => value))
        instance.should_not be_valid, instance.attributes.inspect
      end
    end
  end

  it "'method missing' should be tested" do
    invoice = Factory(:invoiced_product)
    add_param = mock_model(AdditionalParams, :params_name => "count", :params_value => 2)
    invoice.stub(:additional_params => [add_param])
    invoice.data_for_count.should eq 2
  end

  context "Call" do

    before { @product = Factory(:invoiced_product, :clone_info => params[:clone_info]) }

    context "#identifier" do

      it "should be polymorphic for Product" do
        @product.identifier.should be_a(Product)
        @product.receiver_option.should_not be_nil
      end

      it "should be polymorphic for ProductCounter" do
        @product = Factory(:invoiced_service)
        @product.identifier.should be_a(ProductCounter)
        @product.receiver_option.should_not be_nil
      end

    end


    it "#receiver_option should return ReceiverOption" do
      @product.receiver_option.should be_a(ReceiverOption)
      @product.receiver_option.should_not be_nil
    end

    context "#shipping_closed?" do

      it "with valid parameters " do
        InvoiceItemData.shipment_closed?("2", "1").should be_true
      end

      it "with invalid parameters " do
        arr = [nil, 1, 2]
        arr.each do |a|
          InvoiceItemData.shipment_closed?("2", a).should be_false
          InvoiceItemData.shipment_closed?(a, "1").should be_false
        end
      end

    end


    specify "#has_intracking_number? when invoice item data have intracking number" do
      relation = stub(:all => [1, 2])
      InvoiceItemData.stub(:with_int_number).with(any_args).and_return relation
      invoice = build(:invoiced_product)
      InvoiceItemData.has_intracking_number?(invoice).should be_true
    end

    context "#close_invoice_item_datum" do

      it "should set status => 3" do
        prod1 = Factory(:invoiced_product)
        prod2 = Factory(:invoiced_product)
        prod1.update_attributes(:staus => 2)
        prod2.update_attributes(:staus => 2)

        datum = [prod1, prod2]

        InvoiceItemData.close_invoice_item_datum(datum)

        InvoiceItemData.find_by_id(prod1.id).status.should eq 3
        InvoiceItemData.find_by_id(prod2.id).status.should eq 3
      end

    end


    specify "#create_additional_params should store pair 'params_name, params_value'" do
      products = [Factory(:invoiced_product), Factory(:invoiced_product)]
      AdditionalParams.destroy_all
      params = [{:params_name => "intracking_number", :params_value => "foo"},
                {:params_name => "date_of_send", :params_value => "10-10-2011"},
                {:params_name => "shipping_info", :params_value => "bar"}]
      InvoiceItemData.create_additional_params(products, params)
      products.each do |product|

        params.each do |param|
          InvoiceItemData.find_by_id(product.id).additional_params.
              where(:params_name => param[:params_name]).first.params_value.should eq(param[:params_value]),
                                                                                   ":params_name => #{param[:params_name]} should have :params_value => #{param[:params_value]}"
        end
      end

    end

    context "#set_additional_params" do

      before(:each) do
        InvoiceItemData.destroy_all
        AdditionalParams.destroy_all
        @item_data = Factory(:invoiced_product)
        @params = [{:params_name => "intracking_number", :params_value => "foo"},
                   {:params_name => "date_of_send", :params_value => "10-10-2011"},
                   {:params_name => "shipping_info", :params_value => "bar"}]
      end

      it "should close InvoiceItemData with status = '2' and closed = '1'" do
        status = "2"
        closed ="1"

        InvoiceItemData.set_additional_params(@item_data, @params, status, closed)
        InvoiceItemData.find_by_id(@item_data.id).status.should eq 3

      end

      it "should raise error, when I have 'intracking_number'" do
        status = "2"
        closed = nil

        #InvoiceItemData.set_additional_params(@item_data, @params, status, closed).should raise_error(StandardError, "Intracking number can't be modified")
        InvoiceItemData.set_additional_params(@item_data, @params, status, closed).should raise_error

      end

      it "should set additional params" do
        AdditionalParams.destroy_all
        status = "2"
        closed = nil
        @params[0][:params_value] = "int_num"
        @params[2][:params_value] = "some_info"

        InvoiceItemData.set_additional_params(@item_data, @params, status, closed)

        InvoiceItemData.find_by_id(@item_data.id).additional_params.
            where(:params_name => "intracking_number").
            select(:params_value).first.params_value.should eq "int_num"

        InvoiceItemData.find_by_id(@item_data.id).additional_params.
            where(:params_name => "shipping_info").
            select(:params_value).first.params_value.should eq "some_info"
      end

    end

    context "SCOPES" do

      context ":with_int_number" do
        before(:each) do
          InvoiceItemData.destroy_all
        end

        it "when invoice item data have intracking number" do
          product = Factory(:invoiced_product)
          product.additional_params.create(:params_name => "intracking_number", :params_value => "11")
          InvoiceItemData.with_int_number(product.receiver_option.id).should_not be_empty
        end

        it "when invoice item data have no intracking number" do
          product = Factory(:invoiced_product)
          AdditionalParams.destroy_all
          InvoiceItemData.with_int_number(product.receiver_option.id).should be_empty
        end

        it "not work for service" do
          service = Factory(:invoiced_service)
          InvoiceItemData.with_int_number(service.receiver_option.id).should be_empty
        end

      end

      context ":parallel datum" do

        it "should return parallel datum" do
          res_opt1 = Factory(:receiver_option)
          res_opt2 = Factory(:receiver_option)

          product1 = Factory(:invoiced_product, :receiver_option => res_opt1)
          product2 = Factory(:invoiced_product, :receiver_option => res_opt1)
          product3 = Factory(:invoiced_product, :receiver_option => res_opt2)

          InvoiceItemData.parallel_datum(product1).should include(product1)
          InvoiceItemData.parallel_datum(product1).should include(product2)
          InvoiceItemData.parallel_datum(product1).should_not include(product3)

          InvoiceItemData.parallel_datum(product1).count.should eq 2
          InvoiceItemData.parallel_datum(product2).count.should eq 2
          InvoiceItemData.parallel_datum(product3).count.should eq 1
        end

      end

      context ":only_products" do
        before { InvoiceItemData.destroy_all }

        it "should return array invoice item datum" do
          product1 = Factory(:invoiced_product)
          product2 = Factory(:invoiced_product)
          serv1 = Factory(:invoiced_service)
          serv2 = Factory(:invoiced_service)

          InvoiceItemData.only_products.count.should eq 2
        end
      end
    end


  end
end

# == Schema Information
#
# Table name: invoice_item_data
#
#  id              :integer(4)      not null, primary key
#  identifier_id   :integer(4)      not null
#  identifier_type :string(255)     not null
#  price           :float           not null
#  item_price      :float           not null
#  item_count      :integer(4)      not null
#  invoice_data_id :integer(4)      not null
#  created_at      :datetime
#  updated_at      :datetime
#

