require 'spec_helper'

describe Seller do

  context "have db" do
    context "columns" do
      it { should have_db_column(:rating_average_behavior).of_type(:decimal).
                      with_options(:default => 0.0, :precision => 5, :scale => 2) }
    end
  end

  context "have associations" do
    context "has_many" do
      it { should have_many(:rates_without_dimension) }
      it { should have_many(:raters_without_dimension) }
      it { should have_many(:feedbacks) }
    end
  end

  describe "store associations" do

    it "should destroy associated stores" do
      Timecop.return

      @seller = Seller.create!(:first_name => "First Name Seller", :last_name => "Last Name Seller")
      @store = Factory(:store, :seller => @seller)
      @seller.destroy
      Seller.find_by_id(@store.seller_id).should be_nil
    end

  end

  describe "featured vendor" do
    before { @vendor = create(:featured_vendor) }

    it "should exist featured vendors" do
      Seller.featured.should_not be_blank
    end

    it "should return right object" do
      Seller.featured.should be_a(Seller)
    end

    it "should return only actual featured vendors" do
      @vendor.update_attribute(:end_date, 1.day.ago)
      Seller.featured.should be_nil
    end

    it "should destroy not actual featured vendors" do
      @vendor.update_attribute(:end_date, 1.day.ago)
      expect { Seller.featured }.should change(FeaturedVendor, :count).by(-1)
    end

    it "should not destroy actual featured vendors" do
      @vendor.update_attribute(:end_date, Date.today + 10.days)
      Seller.featured
      FeaturedVendor.all.count.should == 1
    end

    context "expired" do

      before do
        @vendor.update_attribute(:end_date, Date.today + 100.day)
        @seller = @vendor.seller
      end

      specify { Seller.featured.should eq(@seller) }

      it "should replace existed one" do
        new_featured_vendor = create(:featured_vendor,
                                     :start_date => season_date(:start, FeaturedVendor),
                                     :end_date => season_date(:end, FeaturedVendor))
        new_seller = new_featured_vendor.seller
        @vendor.update_attributes!(:end_date => 200.day.ago, :start_date => 200.day.ago)

        Seller.featured.should eq(new_seller)
        FeaturedVendor.all.count.should == 1
      end

    end
  end

  context "Call" do
    context "#fullname" do
      before(:each) { @seller = Factory(:seller) }
      it "should be blank if seller has no name" do
        @seller.update_attribute(:first_name, nil)
        @seller.update_attribute(:last_name, nil)
        @seller.fullname.should be_blank
      end
      it "should return seller's full name" do
        @seller.update_attributes(:first_name => "fn", :last_name => "ln")
        @seller.fullname.should eq "Fn Ln"
      end
    end
  end
  specify "#has_product? should return true for user" do
    pending
  end

end

# == Schema Information
#
# Table name: sellers
#
#  id         :integer(4)      not null, primary key
#  user_id    :integer(4)
#  first_name :string(30)
#  last_name  :string(30)
#  rating     :integer(4)
#  created_at :datetime
#  updated_at :datetime
#

