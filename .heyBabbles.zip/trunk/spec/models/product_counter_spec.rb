require 'spec_helper'

describe ProductCounter do

  let(:service) { Factory(:search_service) }

  def params
    {
        :service_type => service.service_type,
        :product_id => Factory(:fast_item).id,
        :payed => true,
        :points => service.points
    }
  end

  it { should respond_to(:product) }
  it { should respond_to(:service) }
  it { should respond_to(:points) }
  it { should respond_to(:payed) }

  [:home_counter, :search_counter].each do |scope|
    it "should respond on scope #{scope.inspect}" do
      expect { ProductCounter.send(scope) }.should_not raise_error
    end
  end

  it "should be valid for 'params'" do
    instance = ProductCounter.new(params)
    instance.should be_valid, instance.errors
  end

  it "should return service by association" do
    counter = ProductCounter.create(params)
    counter.service.product_counters.should include counter
  end

  it "should decrement search counter" do
    product = Factory(:fast_item)
    ProductCounter.create!(:product_id => product.id, :payed => true, :points => 100, :service_type => service.service_type)
    ProductCounter.decrement_points([product.id])
    product.reload
    product.search_counter.points.should == 99
  end

  {
      :product_id => ["s", "", nil, 0, -1, -123.45, 123.45],
      :service_type => ["s", "", nil, 1000000, 0, -1, -123.45, 123.45],
      :payed => ["", nil],
      :points => ["", "bla bla bla", nil, -123.45],
      :status => ["", nil]
  }.each do |field, values|
    values.each do |value|
      it "should not be valid for '#{field}' with value '#{value.inspect}'" do
        instance = ProductCounter.new(params.merge(field => value))
        instance.should_not be_valid, instance.attributes.inspect
      end
    end
  end

end

# == Schema Information
#
# Table name: product_counters
#
#  id           :integer(4)      not null, primary key
#  product_id   :integer(4)
#  service_type :integer(4)
#  points       :integer(4)      default(0), not null
#  payed        :boolean(1)      default(FALSE), not null
#  status       :boolean(1)      default(FALSE), not null
#

