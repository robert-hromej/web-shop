require 'spec_helper'

describe ShipTo do

  def params
    {
        :country_id => 1,
        :product_id => 1,
        :cost => 123,
        :additional_cost => 123,
        :product_limit => 123
    }
  end

  it { ShipTo.new(params).should be_valid }
  it { should_not be_valid }

  it { should respond_to(:cost) }
  it { should respond_to(:additional_cost) }
  it { should respond_to(:product_limit) }
  it { should respond_to(:country) }
  it { should respond_to(:product) }

  {
      :country_id => ["", nil, "abc"],
      :product_id => ["", nil, "abc"],
      :cost => ["", nil, "abc"],
      :additional_cost => ["", nil, "abc"],
      :product_limit => ["", nil, "abc"]
  }.each do |field, values|
    values.each do |value|
      it "should not be valid for '#{field}' with value '#{value.inspect}'" do
        ShipTo.new(params.merge(field => value)).should_not be_valid
      end
    end
  end

end

# == Schema Information
#
# Table name: ship_tos
#
#  id              :integer(4)      not null, primary key
#  product_id      :integer(4)
#  country_id      :integer(4)
#  cost            :integer(4)      default(0), not null
#  additional_cost :integer(4)      default(0), not null
#  product_limit   :integer(4)      default(0), not null
#  created_at      :datetime
#  updated_at      :datetime
#  deleted_at      :datetime
#

