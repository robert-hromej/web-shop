require 'spec_helper'

describe ApplicationImage do


  it { should respond_to(:product) }
  it { should respond_to(:set_as_the_main) }
  it { should_not be_valid }

  it { should belong_to(:product) }

  it { should have_callback(:set_position).on(:before_create) }
  it { should have_callback(:create_main_image).on(:after_create) }
  it { should validate_presence_of(:image_content_type) }
  it { should validate_presence_of(:image_file_name) }
  it { should validate_presence_of(:image_file_size) }
  it do
    Factory(:image)
    should validate_uniqueness_of(:product_id).scoped_to(:position)
  end

  [:image, :image_jpg, :image_gif].each do |factory_name|
    it "should be valid for #{factory_name}" do
      attr = Factory.build(factory_name).attributes.except(:id)
      instance = ApplicationImage.new(attr)
      instance.should be_valid, instance.errors
    end
  end

  [:image_big, :image_yml].each do |factory_name|
    it "should_not be valid for #{factory_name}" do
      attr = Factory.build(factory_name).attributes.except(:id)
      instance = ApplicationImage.new(attr)
      instance.should_not be_valid, attr.inspect
    end
  end

  it "denies upload more 8 images per 1 product" do
    @product = Factory(:fast_item)
    8.times { Factory(:image, :product_id => @product.id) }

    expect do
      Factory(:image, :product_id => @product.id)
    end.should raise_error(ActiveRecord::RecordInvalid), "validate :count_of_images fails.Exceeds limit #{ApplicationImage::MAX_IMAGES_PER_PRODUCT}"

    ApplicationImage.images_for_product(@product.id).count.should eq ApplicationImage::MAX_IMAGES_PER_PRODUCT
  end

  it "should set position '1'" do
    Factory(:image).position.should eq(1)
  end

  it "#set_as_the_main should change 'main_image'" do
    product = Factory(:fast_item)
    first_image = Factory(:image, :product_id => product.id)
    product.reload
    product.main_image.should eq(first_image), "check for 'create_main_image' callback"

    second_image = Factory(:image, :product_id => product.id)
    second_image.set_as_the_main
    product.reload
    product.main_image.should eq(second_image), "check for instance_method 'set_as_the_main'"
  end

  it "should have constant MAX_IMAGES_PER_PRODUCT" do
    ApplicationImage::MAX_IMAGES_PER_PRODUCT.should eq(8)
  end
end

# == Schema Information
#
# Table name: application_images
#
#  id                 :integer(4)      not null, primary key
#  product_id         :integer(4)
#  description        :text
#  position           :integer(4)      not null
#  image_file_name    :string(255)
#  image_content_type :string(255)
#  image_file_size    :integer(4)
#  image_updated_at   :datetime
#

