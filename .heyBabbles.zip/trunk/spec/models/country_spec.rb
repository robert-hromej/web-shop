require 'spec_helper'

describe Country do

  def params
    {:title => "Country", :country_type => 1}
  end

  it { should respond_to(:addresses) }
  it { should respond_to(:states) }
  it { should respond_to(:shippings) }
  it { should respond_to(:products) }
  it { should respond_to(:id) }
  it { should respond_to(:title) }
  it { should respond_to(:country_type) }

  it "should create a new instance" do
    expect { Country.create({:title => "country"}) }.should change(Country, :count).by(1)
  end

  {:title => ["Co", "Country", "C"*30], :country_type => 1..7}.each do |field, values|
    values.each do |value|
      it "should be valid for '#{field}' with value '#{value.inspect}'" do
        Country.new(params.merge(field => value)).should be_valid
      end
    end
  end

  {:title => [nil, "", "COUNTRY", "C"*31, "C"], :country_type => [0, 8, "", nil]}.each do |field, values|
    values.each do |value|
      it "should not be valid for '#{field}' with value '#{value.inspect}'" do
        Country.create(params)
        Country.new(params.merge(field => value)).should_not be_valid
      end
    end
  end

  {:base_shippings => {:country_type => [2, 4, 6]},
   :from_shippings => {:country_type => [1, 4, 5]},
   :to_shippings => {:country_type => [1, 2, 3]}
  }.each do |scope, conditions|
    conditions.each do |field, values|
      values.each do |value|
        it "should not be valid for scope #{scope} and '#{field}' with value '#{value.inspect}'" do
          @country = Country.create(:title => "Country", :country_type => value)
          Country.send(scope).should_not include(@country)
        end
      end
    end
  end

end

# == Schema Information
#
# Table name: countries
#
#  id           :integer(4)      not null, primary key
#  title        :string(30)      not null
#  country_type :integer(2)      default(1), not null
#

