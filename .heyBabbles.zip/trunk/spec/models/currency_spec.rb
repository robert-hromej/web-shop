require 'spec_helper'

describe Currency do
  it { Currency.new({:title => "currency"}).should be_valid }
  it { should_not be_valid }
  it { respond_to(:products) }
  it { respond_to(:title) }

  it "should create new object with valid attributes" do
    expect { Currency.create(:title => "currency") }.should change(Currency, :count).by(1)
  end


end

# == Schema Information
#
# Table name: currencies
#
#  id    :integer(4)      not null, primary key
#  title :string(255)
#

