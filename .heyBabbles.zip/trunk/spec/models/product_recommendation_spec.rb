require 'spec_helper'

describe "ProductRecommendation" do

  it "should find recommendation products" do
    items = Factory(:invoice_with_recommendations).products
    item = Product.find_by_id(items.first.identifier_id)
    item.recommendations.collect(&:id).should eq(items.collect(&:identifier_id).uniq.sort - [item.id])
  end

end
