require 'spec_helper'

describe User do

  let(:user) { Factory(:user) }

  before(:each) do
    @attr = {
        :nickname => "Example User",
        :email => "users@example.com",
        :password => "foobar",
        :password_confirmation => "foobar"
    }

    @seller_attr = {
        :last_name => "seller_last_name",
        :first_name => "seller_first_name"
    }

    @address_attr = {
        :state_id => 1,
        :country_id => 1,
        :zip => '88000',
        :city => 'Uzhgorod',
        :street => 'Korzo',
        :phone => '0000'
    }
  end

  context "have associations" do
    context "has many" do
      it { should have_many(:ratings_given) }
      it { should have_many(:feedbacks_given) }
    end
  end

  describe "CREATE" do
    it "should create a new instance given a valid attribute" do
      User.create!(@attr)
    end

    it "should accept parameters for seller" do
      lambda do
        user.update_attributes({:seller_attributes => @seller_attr})
      end.should change(Seller, :count).by(1)
      user.seller.last_name.should match(@seller_attr[:last_name])
      user.seller.first_name.should match(@seller_attr[:first_name])
    end

    context "nested parameters for address" do

      before { @user = User.create!(attributes_for(:user).except(:address_attributes)) }

      it "should be accepted " do
        lambda do
          @user.update_attributes({:address_attributes => @address_attr})
        end.should change(Address, :count).by(1)
        @user.address.zip.should match(@address_attr[:zip])
        @user.address.phone.should match(@address_attr[:phone])
      end

      it "should be returned" do
        lambda do
          @user.update_attributes({:address_attributes => @address_attr})
        end.should change(Address, :count).by(1)
        @user.zip.should match(@address_attr[:zip])
        @user.phone.should match(@address_attr[:phone])
        @user.street.should match(@address_attr[:street])
        @user.country_id.should eql(@address_attr[:country_id])
        @user.state_id.should eql(@address_attr[:state_id])
      end
    end


    describe "FAILURE because of invalid params" do
      it "should require an email address" do
        no_email_user = User.new(@attr.merge(:email => ""))
        no_email_user.should_not be_valid
      end

      it "should accept valid email addresses" do
        addresses = %w[users@foo.com THE_USER@foo.bar.org first.last@foo.jp]
        addresses.each do |address|
          valid_email_user = User.new(@attr.merge(:email => address))
          valid_email_user.should be_valid
        end
      end

      it "should reject invalid email addresses" do
        addresses = %w[users@foo,com user_at_foo.org example.users@foo.]
        addresses.each do |address|
          invalid_email_user = User.new(@attr.merge(:email => address))
          invalid_email_user.should_not be_valid
        end
      end

      it "should reject duplicate email addresses" do
        User.create!(@attr)
        user_with_duplicate_email = User.new(@attr)
        user_with_duplicate_email.should_not be_valid
      end

      it "should reject email addresses identical up to case" do
        upcased_email = @attr[:email].upcase
        User.create!(@attr.merge(:email => upcased_email))
        user_with_duplicate_email = User.new(@attr)
        user_with_duplicate_email.should_not be_valid
      end

      it "should allow empty fb params" do
        user = Factory(:user, :facebook_email => "", :facebook_uid => "")
        @attr.merge!(:facebook_email => "", :facebook_uid => "")
        User.new(@attr).should be_valid
      end

      describe "uniqueness" do
        before(:each) do
          @attr.merge!(:facebook_email => user.facebook_email, :facebook_uid => user.facebook_uid)
        end

        it "should require unique uid for fb" do
          @attr.merge!(:facebook_email => "a@a.com")
          User.new(@attr).should_not be_valid
        end

        it "should require unique email for fb" do
          @attr.merge!(:facebook_uid => 2345679)
          User.new(@attr).should_not be_valid
        end
      end
    end
  end


  describe "passwords" do
    before(:each) do
      @user = User.new(@attr)
    end

    it "should have a password attribute" do
      @user.should respond_to(:password)
    end

    it "should have a password confirmation attribute" do
      @user.should respond_to(:password_confirmation)
    end
  end

  describe "password validations" do
    it "should require a password" do
      User.new(@attr.merge(:password => "", :password_confirmation => "")).
          should_not be_valid
    end

    it "should require a matching password confirmation" do
      User.new(@attr.merge(:password_confirmation => "invalid")).
          should_not be_valid
    end

    it "should reject short passwords" do
      short = "a" * 5
      hash = @attr.merge(:password => short, :password_confirmation => short)
      User.new(hash).should_not be_valid
    end

    it "should reject long passwords" do
      long = "a" * 129
      hash = @attr.merge(:password => long, :password_confirmation => long)
      User.new(hash).should_not be_valid
    end
  end

  describe "password encryption" do
    before(:each) do
      @user = User.create!(@attr)
    end

    it "should have an encrypted password attribute" do
      @user.should respond_to(:encrypted_password)
    end

    it "should set the encrypted password attribute" do
      @user.encrypted_password.should_not be_blank
    end

    it "should not rewrite encrypted password" do
      encrypted_before = @user.encrypted_password
      @user.update_attribute("username", "haHa")
      @user.encrypted_password.should == encrypted_before
    end

    it "should not rewrite encrypted password" do
      encrypted_before = @user.encrypted_password
      @user.update_attributes({:password => "147852", :password_confirmation => "147852"})
      @user.encrypted_password.should eq(encrypted_before)
    end

    it "should update encrypted password" do
      password_before = @user.password
      @user.update_attributes!({:password => "147852", :password_confirmation => "147852", :reset => 1})
      @user.password.should_not eq(password_before)
    end

    it "should not encrypt password for empty one" do
      user = User.new(:email => "a@a.com")
      user.save(:validate => false)
      user.encrypted_password.should be_blank
      # We leave salt not empty.Because we are using it in session.
      user.salt.should_not be_blank
    end
  end

  describe "authenticate method" do
    before(:each) do
      @user = User.create!(@attr)
    end

    it "should return nil on email/password mismatch" do
      User.authenticate("", @user.password)
    end

    it "should return the users on email/password match" do
      User.authenticate(@user.email, @user.password)
    end
  end

  describe "responds" do

    let(:new_user) { User.new }

    it { should respond_to :approval_options }
    it { should respond_to :payment_options }

    it "to 'authentication_token'" do
      new_user.should respond_to :reset_password_sent_at
    end

    it "to 'reset_password_token'" do
      new_user.should respond_to :reset_password_token
    end

    it "to 'registered'" do
      user.should respond_to :registered
    end

    it "to 'send_confirmation_mail'" do
      user.should respond_to :send_confirmation_mail
    end

    it "to 'send_reset_password_mail'" do
      user.should respond_to :send_reset_password_mail
    end

    it "to 'add_to_constant_contact'" do
      user.should respond_to :added_to_constant_contact?
    end
  end

  describe "after create" do
    it "should create a new instance with 'remember_created_at'" do
      Timecop.freeze
      new_user = User.create!(@attr)
      new_user.remember_created_at.should eq(DateTime.now)
    end
  end

  describe "mail methods" do
    describe "send_confirmation_mail" do
      before(:each) do
        user.send_reset_password_mail
      end

      it "should generate_token" do
        user.reset_password_token.should_not be_nil
      end

      it "should set 'reset_password_sent_at'" do
        user.reset_password_sent_at.should_not be_nil
      end
    end
  end

  describe "'reset parameter'" do
    # I have left duplication because it seems that Rspec
    # environment malfunction object behave I want to test
    #
    it "user should not update attributes with no parameter" do
      Factory(:user)
      User.first.update_attributes(:username => "blablalba").should == false
    end

    it "should update attributes" do
      Factory(:user)
      User.first.update_attributes(:username => "blablalba", :reset => 0).should == true
    end
  end

  describe "add to 'Constant Contact'" do
    before(:each) do
      @user = Factory(:user)
    end

    it "should be success" do
      @user.added_to_constant_contact?.should be_true
    end

    it "should test real adding to ConstantContact" do
      pending "Tom"
    end
  end

  describe "stores?" do

    before(:all) { clean_db }
    before(:each) { @user = Factory(:user) }

    context "has store and seller" do
      before do
        @seller = Factory(:seller, :user_id => @user.id)
      end

      it { @user.should be_seller }
      it { @user.has_store?.should be_true }
      it { @user.store.should eq(@seller.store) }
    end

    context "has no store and seller" do
      subject { @user }

      it { @user.store.should be_nil }
      it { should_not be_seller }
      it { @user.has_store?.should be_false }
    end
  end

  context "Call" do
    context "#first_name" do
      it "should return nil if user is not a seller" do
        user.first_name.should be_nil
      end

      it "should return user's first name if user is a seller" do
        user.update_attributes(:seller_attributes => {:first_name => "fn"})
        user.first_name.should eq "fn"
      end
    end

    context "#last_name" do
      it "should return nil if user is not a seller" do
        user.last_name.should be_nil
      end

      it "should return user's last name if user is a seller" do
        user.update_attributes(:seller_attributes => {:last_name => "ln"})
        user.last_name.should eq "ln"
      end
    end

    context "#fullname" do
      it "should return nil if user is not a seller" do
        user.fullname.should be_nil
      end

      it "should return user's full name if user is a seller" do
        user.update_attributes(:seller_attributes => {:first_name => "fn", :last_name => "ln"})
        user.seller.fullname.should eq user.fullname
        user.fullname.should eq "Fn Ln"
      end
    end

    context "#country_id" do
      it "should return user's county_id" do
        user.update_attributes(:address_attributes => {:country_id => 2})
        user.country_id.should eq 2
      end
    end

    context "#country" do
      it "should return user's country" do
        country = Factory(:country)
        user.update_attributes(:address_attributes => {:country_id => country.id})
        user.country.should eq country
      end
    end

    context "#state" do
      it "should return user's state" do
        state = Factory(:country).states.first
        user.update_attributes(:address_attributes => {:state_id => state.id})
        user.state.should eq state
      end
    end

    context "#state_id" do
      it "should return user's state_id" do
        user.update_attributes(:address_attributes => {:state_id => 1})
        user.state_id.should eq 1
      end
    end

    context "#city" do
      it "should return user's city" do
        user.update_attributes(:address_attributes => {:city => "ct"})
        user.city.should eq "ct"
      end
    end

    context "#street" do
      it "should return user's street" do
        user.update_attributes(:address_attributes => {:street => "st"})
        user.street.should eq "st"
      end
    end

    context "#zip" do
      it "should return user's zip" do
        user.update_attributes(:address_attributes => {:zip => "123"})
        user.zip.should eq "123"
      end
    end
  end

  describe "birhtday date" do
    #todo: incorrect behavior if entered a number
    #example:
=begin
        ruby-1.8.7-p352 :014 > u = User.first
         => ... gender: nil, newsletter: nil, birthday: nil, about: nil> 
        ruby-1.8.7-p352 :015 > u.birthday
         => nil 
        ruby-1.8.7-p352 :016 > u.update_attributes(:birthday => 77, :reset => 0)
         => true 
        ruby-1.8.7-p352 :017 > u.birthday
         => 77 
=end
    before(:each) do
      @user = Factory(:user)
      Timecop.return
    end

    it "should be updated if date is correct" do
      @user.update_attributes("birthday(1i)" => "2010", "birthday(2i)" => "4", "birthday(3i)" => "20", :reset => 0).should == true
    end

    it "should not be updated if day is in future" do
      Timecop.travel(1.day.from_now) do
        @user.update_attributes(:birthday => DateTime.now, :reset => 0).should == false
      end
    end

    it "should not be updated if month is in future" do
      Timecop.travel(1.month.from_now) do
        @user.update_attributes("birthday(1i)" => Time.now.year.to_param, "birthday(2i)" => Time.now.month.to_param, "birthday(3i)" => Time.now.day.to_param, :reset => 0).should == false
      end
    end

    it "should not be updated if year is in future" do
      Timecop.travel(1.year.from_now) do
        @user.update_attributes(:birthday => DateTime.now, :reset => 0).should == false
      end
    end
  end

  it "scope #fetch_line_item should return line_items" do
    user = Factory(:user)
    line_item = Factory(:line_item)
    user.line_items << line_item
    user.save
    user.fetch_line_item(line_item.item_type_id, line_item.ship_to_id).should eq line_item
  end


end

# == Schema Information
#
# Table name: users
#
#  id                     :integer(4)      not null, primary key
#  email                  :string(255)     default(""), not null
#  encrypted_password     :string(128)     default(""), not null
#  reset_password_token   :string(255)
#  reset_password_sent_at :datetime
#  authentication_token   :string(255)
#  avatar_file_name       :string(255)
#  avatar_content_type    :string(255)
#  avatar_file_size       :integer(4)
#  avatar_updated_at      :datetime
#  facebook_uid           :integer(8)
#  facebook_email         :string(255)
#  registered             :boolean(1)      default(FALSE)
#  salt                   :string(255)
#  username               :string(20)
#  gender                 :integer(3)
#  newsletter             :boolean(1)
#  birthday               :date
#  remember_created_at    :datetime
#  about                  :text
#

