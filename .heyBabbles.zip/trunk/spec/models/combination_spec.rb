require 'spec_helper'

describe Combination do
  def params
    Factory.build(:slow_combination).attributes
  end

  it { should respond_to(:category) }
  it { should respond_to(:category_id) }
  it { should respond_to(:subcategory) }
  it { should respond_to(:subcategory_id) }
  it { should respond_to(:gender) }
  it { should respond_to(:gender_category_id) }

  it "should be rewriten create process 'TOM'"

  it { Combination.new(params).should be_valid }

  it "should have all categories connections" do
    combination = Factory(:slow_combination)

    combination.category.should_not be_blank
    combination.subcategory.should_not be_blank
    combination.gender.should_not be_blank

    combination.category.level.should eq(1)
    combination.subcategory.level.should eq(2)
    combination.gender.level.should eq(3)
  end

  it "should be unique for [:category_id, :subcategory_id, :gender_category_id]" do
    combination = Factory(:slow_combination)
    options = params.clone
    [:category_id, :subcategory_id, :gender_category_id].each { |field| options.merge!(field => combination.send(field)) }
    Combination.new(options).should_not be_valid
  end

  {:category_id => ["", 1, nil, "r"],
   :subcategory_id => ["", 1, nil, "r"],
   :gender_category_id => ["", 1, nil, "r"]}.each do |field, values|
    values.each do |value|
      it "should not be valid for '#{field}' with value '#{value.inspect}'" do
        Combination.new(params.merge(field => value)).should_not be_valid
      end
    end
  end
end

# == Schema Information
#
# Table name: combinations
#
#  id                 :integer(4)      not null, primary key
#  category_id        :integer(4)
#  subcategory_id     :integer(4)
#  gender_category_id :integer(4)
#

