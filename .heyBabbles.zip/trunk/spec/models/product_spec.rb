require 'spec_helper'

describe Product do

  let(:product) { Factory(:product_with_impressions) }

  it { should respond_to :available }
  it { should respond_to :currency }
  it { should respond_to :seller }
  it { should respond_to :combination }
  it { should respond_to :images }
  it { should respond_to :product_seasons }
  it { should respond_to :default_image }
  it { should respond_to :category }
  it { should respond_to :subcategory }
  it { should respond_to :gender }
  it { should respond_to :category }
  it { should respond_to :category_id }
  it { should respond_to :subcategory }
  it { should respond_to :subcategory_id }
  it { should respond_to :gender }
  it { should respond_to :gender_category_id }
  it { should respond_to :search_counter }
  it { should respond_to :image_count }
  it { should respond_to :shipping_policy }
  it { should respond_to :return_policy }
  it { should respond_to :address_of_seller }
  it { should respond_to :impressions_for_service }
  it { should respond_to :available }
  it { should respond_to :home_page_count }
  it { should respond_to :recommendations }

  it { should delegate(:name).to(:store).with_prefix }
  it { should delegate(:category_id).to(:combination) }
  it { should delegate(:subcategory_id).to(:combination) }
  it { should delegate(:gender_category_id).to(:combination) }

  it "should respond to search counter" do
    product.search_count.should == 0
  end

  it "should respond to season counter" do
    pending "Ask Edgar"
    product.season_count.should == "inactive"
  end

  it "should set expiration date (1 month)" do
    quick_freeze do
      item = Factory(:fast_item)
      item.expiration_date.should == (Time.zone.now + 1.month)
    end
  end

  {:used => nil, :new => 1}.each do |type, value|
    it "should create value #{value.inspect} for field accepted for #{type.inspect} product" do
      item = Factory(:product_without_accepted, :new => (type == :new))
      item.accepted.should eq value
    end
  end

  context "populated by 50 instances" do
    before(:all) do
      clean_db; populate(50)
      @counter_before = product.product_counters.first
    end

    after(:all) { clean_db }

    describe "#search" do
      it "return full array if query is empty" do
        result = Product.search("")
        result.size.should > 0
      end

      it "return empty array if nothing is found" do
        result = Product.search("bla-bla-bla")
        result.total_entries.should == 0
      end

      it "by name" do
        result = Product.search("name")
        result.total_entries.should == 1
        result.all.each { |r| r.name.should =~ /name/ }
      end

      it "by description" do
        result = Product.search("descripted")
        result.total_entries.should == 1
        result.each { |r| r.description.should =~ /descripted/ }
      end

      it "by subcategory title" do
        result = Product.search("categori")
        result.total_entries.should == 1
        result.each { |r|
          r.subcategory.title.should =~ /categori/
        }
      end

      it "by name color size title" do
        result = Product.search("t-shorts xl black")
        result.total_entries.should == 3
        result.each { |r|
          r.name.should =~ /t-shorts/
        }
      end

      it "by single phrase" do
        result = Product.search("\"description of name\"")
        result.total_entries.should == 1
        result.each { |r|
          r.description.should =~ /description of name/
        }
      end

      it "by words" do
        result = Product.search("description name")
        result.total_entries.should == 3
      end

      it "return sorted results" do
        result = Product.search("aaa", :per_page => 8)
        ids = result.map { |p| p.name[/\d+/].to_i }
        ids.should == (7..14).to_a.reverse
      end

      it "by name and category filter" do
        result = Product.search("name", :category => Category.find_by_title("Accessories"))
        result.total_entries.should == 0
      end


      pending "FEDYA" do
      it "by words and category filter" do
        category = Category.where(:title => "Maternity").first
        result = Product.search("description of name", :category => category)
        result.total_entries.should == 2
        result.each { |r|
          r.category.id.should == category.id
        }
      end
      end #pending
    end

    describe "has scope" do
      it ":last_added" do
        Product.last_added(4, @populate.store.id).count == 4
      end

      context "featured_products" do
        it "should return 50" do
          Product.featured_products.count == 50
        end

        it "should have counters greater than 0" do
          Product.featured_products.all.each do |product|
            product.attributes_before_type_cast["points"].to_i.should be > 0
          end
        end
      end
    end

    describe ".fetch_features" do
      it "decrementors should have been tested" do
        pending "Myroslav"
      end

      it "should return 16 values" do
        Product.fetch_features.flatten.length.should have_at_most(16).products
      end

      it "should not be empty" do
        Product.fetch_features.flatten.should_not be_empty
      end

      it "should return empty array for no values" do
        Product.delete_all
        Product.fetch_features.should be_empty
      end
    end

    describe ".decrement_counters" do
      it "should decrement impressions by 1" do
        expect {
          Product.decrement_counters([@counter_before.id], 999)
        }.to change { ProductCounter.find(@counter_before.id).points }.by(-999)
      end

      it "should not decrement impressions" do
        expect {
          Product.decrement_counters([], 999)
        }.to change { ProductCounter.find(@counter_before.id).points }.by(0)
      end
    end

    it "should delete instance of ProductCounter if impressions == 0" do
      expect {
        Product.decrement_counters([@counter_before.id], @counter_before.points)
      }.should change(ProductCounter, :count).by(-1)
    end

    it "#impressions_for_service" do
      product.impressions_for_service(1).should_not be_nil
    end

    it "#impressions_for_service should be 2000" do
      product.product_counters.home_counter.first.update_attributes(:points => 2000)
      product.impressions_for_service(1).should == 2000
    end

    context ":for_sale_products" do

      before { @seller_id = @populate.seller.id }

      it "should not be changed" do
        Product.for_sale_products(@seller_id).to_sql.should == Product.select("products.id, products.expiration_date, products.name, sum(item_types.item_count) as amount").joins(:item_types).group("products.id").where("products.seller_id = #{@seller_id} and products.accepted = 1").order("products.expiration_date, products.id DESC").to_sql
      end

      it "should return array with Items" do
        # This scope search active product.Those active must have accepted 1
        product = @populate.products.select { |product| product.accepted == 1 }.first
        Factory(:item_type, :product_id => product.id)
        Product.for_sale_products(@seller_id).all.should_not be_empty
      end
    end

    context ":used_products" do
      it "should not be changed" do
        seller_id = 1
        condition = ""
        Product.used_products(seller_id, condition).to_sql.should == Product.select("products.id, products.name, products.accepted, products.expiration_date").
            where("products.seller_id = #{seller_id} and products.new = 0").where(condition).order("products.expiration_date").to_sql
      end

      it "should return array with Items" do
        seller_id = 1
        condition = ""
        Product.used_products(seller_id, condition).all.should_not be_empty
      end
    end
  end

  context ":sold_products" do
    before(:each) do
      data = Factory(:receiver_option)
      data.seller.user = Factory(:user)
      10.times { Factory(:invoiced_product, :receiver_option_id => data.id) }
    end

    after(:each) { clean_db }

    it "should be not empty" do
      seller_id = 1
      status = 1
      ReceiverOption.datum_for_seller(seller_id, status).should_not be_nil
    end
  end

  context "Call" do
     it "#days_left" do
      quick_freeze do
        product.days_left.should be >= 30
      end
    end

    { nil => "In Progress",
      1 => "Approved",
      0 => "Rejected"
    }.each do |key, value|
      it "#status should return #{value} for accepted = #{key.inspect}" do
        product.stub(:accepted => key)
        product.status.should eq value
      end
    end

    it "#amount" do
      product.stub(:read_attribute_before_type_cast).with("amount").and_return(2)
      product.should_receive(:read_attribute_before_type_cast).with("amount")
      product.amount.should eq 2
    end

    it "#history_for_seller" do
      pending "Deprecated.Should be reworked by Myroslav"
    end

    it "#ship_from_country should return a country name" do
      country = Factory(:ship_from)
      product.update_attribute(:ship_from_id, country.id)
      product.ship_from_country.should eq country.title
    end
  end

  it "#has_main_image? should be false" do
    Factory(:fast_item).has_main_image?.should be_false
  end
end

# == Schema Information
#
# Table name: products
#
#  id              :integer(4)      not null, primary key
#  currency_id     :integer(4)
#  seller_id       :integer(4)
#  store_id        :integer(4)
#  combination_id  :integer(4)
#  price           :float
#  accepted        :integer(4)
#  description     :text
#  return_policy   :text
#  name            :string(255)
#  product_sid     :string(255)
#  shipping_policy :text
#  expiration_date :datetime
#  new             :boolean(1)
#  ship_from_id    :integer(4)
#  created_at      :datetime
#  updated_at      :datetime
#  payd_images     :integer(4)      default(2), not null
#  main_image_id   :integer(4)      default(0), not null
#

