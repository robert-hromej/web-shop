require 'spec_helper'


describe ApprovalOptions do
  def params
    date = Time.now
    starting_date = date.strftime("%Y-%m-%d")
    ending_date = "#{date.year + 1}-#{date.strftime("%m")}-#{date.strftime("%d")}"

    {:preapproval_key => "AP-1234", :params => {:key => "value"},
     :sender_email => Factory(:user).email, :ending_date => ending_date,
     :starting_date => starting_date
    }
  end

  it { should respond_to :params }
  it { should respond_to :user }
  it { should respond_to :preapproval_key }
  it { should respond_to :approved }
  it { should respond_to :starting_date }
  it { should respond_to :ending_date }
  it { should respond_to :sender_email }
  it { should respond_to :pin_type }

  context "with valid params" do
    it "ss" do
      ApprovalOptions.new(params).should be_valid
    end
  end

  it "'preapproval_key' should be unique" do
    ApprovalOptions.create(params)
    ApprovalOptions.new(params).should_not be_valid
  end

  it "should not be valid if valid params missed" do
    params.each do |key, value|
      ApprovalOptions.new(params.merge(key => "")).should_not be_valid
    end
  end
end

# == Schema Information
#
# Table name: approval_options
#
#  id              :integer(4)      not null, primary key
#  preapproval_key :string(255)     not null
#  approved        :boolean(1)      default(FALSE), not null
#  starting_date   :datetime        not null
#  ending_date     :datetime        not null
#  sender_email    :string(255)
#  pin_type        :string(255)     default("NOT_REQUIRED"), not null
#  params          :text            default(""), not null
#  created_at      :datetime
#  updated_at      :datetime
#

