module SharedExample

  shared_examples_for "not signed in one" do |action|

    before(:each) { test_sign_out }

    it "Then should redirect" do
      eval("#{action}")
      controller.session[:return_to].should_not be_nil
      response.should be_redirect
    end

    it "Then should assign error message" do
      eval("#{action}")
      cookies['flash'].should match(build_regexp "alert-|-#{I18n.t(:deny)}-|-#{I18n.t(:notice_sign_in)}")
    end

  end

  shared_examples_for "signed in user is not seller" do |action|

    before(:each) do
      user = create(:user)
      test_sign_in(user)
    end

    it "Then should redirect" do
      eval("#{action}")
      response.should be_redirect
    end

    it "Then should assign error message" do
      eval("#{action}")
      cookies['flash'].should match(build_regexp "error-|-#{I18n.t(:seller_profile)}-|-#{I18n.t(:havent_got_seller_profile)}")
    end

  end

  shared_examples_for "signed in user is seller without store" do |action|

    before(:each) do
      #populate
      user = create(:user)
      seller = create(:seller, :user_id => user.id)
      user.store.try(:destroy)
      test_sign_in(user)
    end

    it "Then should redirect" do
      eval("#{action}")
      response.should be_redirect
    end

    it "Then should assign error message" do
      eval("#{action}")
      message = (I18n.t('need_store') + ("<a href='#{new_store_path}'>Create store</a>")).html_safe
      cookies['flash'].should match(build_regexp "error-|-#{I18n.t(:product_management)}-|-#{message}")
    end

  end

  shared_examples_for "BaseResource instance" do
    subject { AdaptivePayment::Base.new }
    it { should respond_to :endpoints }
    it { should respond_to :headers }
    it { should respond_to :decode_response }
    it { should respond_to :send }
  end
end