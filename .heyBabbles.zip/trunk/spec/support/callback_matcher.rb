# Usage:
#
# describe Klass do
#   it { should have_callback(:do_something).on(:before_save) }
#   it { should have_callback(:make_change).on(:after_create) }
#   it { should_not have_callback(:make_change).on(:before_save) }
# end
#
# class Klass < ActiveRecord::Base
#   before_save  :do_something
#   after_create :make_change
# end

module Shoulda
  module ActiveRecord

    module CallbackMatcher
      def have_callback(method)
        HaveCallbackMatcher.new(method)
      end

      class HaveCallbackMatcher
        attr_accessor :filter, :callback_type, :kind, :callbacks, :type_callback

        def initialize(method)
          self.filter = method.to_sym
        end

        def on(callback_type)
          types = callback_type.to_s.split("_")
          self.type_callback = callback_type
          self.kind = types.first.to_sym
          self.callback_type = types.second.to_sym
          self
        end

        def matches?(subject)
          @subject = subject.class
          get_callbacks

          if callbacks
            return is_callback_method?
          else
            return false
          end
        end

        def description
          "has #{callback_type.to_s.gsub('_', ' ').capitalize} Callback method :#{type_callback}"
        end

        def failure_message_for_should
          "\n#{callback_type.to_s.gsub('_', ' ').capitalize} Callback method failure\nExpected: '#{type_callback}'\n     Got: nil"
        end

        def failure_message_for_should_not
          "\n#{callback_type.to_s.gsub('_', ' ').capitalize} Callback method failure\nExpected: nil\n     Got: '#{type_callback}'"
        end

        private

        def is_callback_method?
          callbacks.detect { |callback| callback.raw_filter == filter && callback.kind == kind }
        end

        def get_callbacks
          self.callbacks = @subject.instance_variable_get("@_#{callback_type}_callbacks")
        end
      end
    end

  end
end