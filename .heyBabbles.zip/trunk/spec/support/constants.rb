FIRST_USER_LINK = "My account"
FIRST_USER_EMAIL = "users-0@mail.com"
FACEBO0K_EMAIL = "rmd.metr.team@gmail.com"
FACEBO0K_PASS = "TeamMetrRmd"
RAILS_PATH = Rails.root.to_s

ITEM = {:new_path => "/products/new", :title_id => 'product_name', :description_id => "product_description",
        :status_id => "product_new", :currency_id => "product_currency_id", :price_id => "item_price",
        :product_id_id => "product_product_sid", :ship_from_id => 'product_ship_from',
        :shipping => [
            {:to_id => 'product_shippings_attributes_0__destroy', :cost_id => "product_shippings_attributes_0_shipping_cost",
             :add_cost_id => "product_shippings_attributes_0_additional_shipping_cost"},
            {:to_id => 'product_shippings_attributes_1__destroy', :cost_id => "product_shippings_attributes_1_shipping_cost",
             :add_cost_id => "product_shippings_attributes_1_additional_shipping_cost"},
            {:to_id => 'product_shippings_attributes_2__destroy', :cost_id => "product_shippings_attributes_2_shipping_cost",
             :add_cost_id => "product_shippings_attributes_2_additional_shipping_cost"},
            {:to_id => 'product_shippings_attributes_3__destroy', :cost_id => "product_shippings_attributes_3_shipping_cost",
             :add_cost_id => "product_shippings_attributes_3_additional_shipping_cost"}],
        :categories => {:primary_id => "product_category", :subcategory1=> "product_subcategory", :subcategory2 => "product_gender"},
        :product_combinations => [
            {:color_id => "product_product_combinations_attributes_0_color_id", :size_id => "product_product_combinations_attributes_0_size_id",
             :quantity_id => "product_product_combinations_attributes_0_quantity"},
            {:color_id => "product_product_combinations_attributes_1_color_id", :size_id => "product_product_combinations_attributes_1_size_id",
             :quantity_id => "product_product_combinations_attributes_1_quantity"},],
        :images => [{:file_id => "product_images_attributes_0_image", :description_id => "product_images_attributes_0_description"}]
}
SLEEP = false


def integration_login(id=nil)
  id = 1 if id.nil?
  visit "/sessions/integration_sign_in?id=#{id.to_s}"
end

def visit_proxy_root
  visit APP_CONFIG[:shared_route]
end

def _sleep(time=nil)
  time = 3 unless time
  sleep(time) if SLEEP
end

def select_val(id, val, additional_script=nil)
  page.execute_script("$('##{id}').val(#{val});#{additional_script unless additional_script.nil?}")
end


LOREM_IPSUM = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et
 dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
 consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
 Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
