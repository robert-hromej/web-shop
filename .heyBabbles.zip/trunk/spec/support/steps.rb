def i_should_see_login_page
  page.html.should have_html_tag(:label, :content => ".*Email.*")
  page.html.should have_html_tag(:label, :content => ".*Password.*")
end

def i_should_see_seller_form
  page.html.should have_html_tag(:input, :id => 'user_seller_attributes_first_name')
  page.html.should have_html_tag(:input, :id => 'user_seller_attributes_last_name')
  page.html.should have_html_tag(:select, :id => 'user_address_attributes_country_id')
  page.html.should have_html_tag(:select, :id => 'user_address_attributes_state_id')
  page.html.should have_html_tag(:input, :id => 'user_address_attributes_phone', :size => '30')
  page.html.should have_html_tag(:input, :id => 'user_address_attributes_city')
  page.html.should have_html_tag(:input, :id => 'user_address_attributes_street')
  page.html.should have_html_tag(:input, :id => 'user_address_attributes_zip')
end

def i_should_see_seller_form_with_data
  page.html.should have_html_tag(:input, :id => 'user_seller_attributes_first_name', :value => @data[:first_name])
  page.html.should have_html_tag(:input, :id => 'user_seller_attributes_last_name', :value => @data[:last_name])
  page.html.should have_html_tag(:select, :id => 'user_address_attributes_country_id')
  page.html.should have_html_tag(:select, :id => 'user_address_attributes_state_id')
  page.html.should have_html_tag(:input, :id => 'user_address_attributes_phone', :size => '30', :value => @data[:phone])
  page.html.should have_html_tag(:input, :id => 'user_address_attributes_city', :value => @data[:city])
  page.html.should have_html_tag(:input, :id => 'user_address_attributes_street', :value => @data[:street])
  page.html.should have_html_tag(:input, :id => 'user_address_attributes_zip', :value => @data[:zip])
end

def when_i_enter_valid_data_to_seller_form
  @data = {:first_name => 'first_name', :last_name => "last_name", :phone => '8888', :city => "seller_city",
           :street => "seller_street", :zip => "4444", :country_id => '3', :state_id => "3"}
  fill_in "user_seller_attributes_first_name", :with => @data[:first_name]
  fill_in "user_seller_attributes_last_name", :with => @data[:last_name]
  fill_in "user_address_attributes_phone", :with => @data[:phone]
  fill_in "user_address_attributes_city", :with => @data[:city]
  fill_in "user_address_attributes_street", :with => @data[:street]
  fill_in "user_address_attributes_zip", :with => @data[:zip]
  select_val("user_address_attributes_country_id", @data[:country_id], "countrySelected();")
  select_val("user_address_attributes_state_id", @data[:state_id])
  check('user_terms_of_service')
end

def when_i_enter_invalid_data_to_seller_form
  @data = {:first_name => 'first_name', :last_name => "last_name", :phone => '', :city => "seller_city",
           :street => "seller_street", :zip => "", :country_id => '', :state_id => ""}
  fill_in "user_seller_attributes_first_name", :with => @data[:first_name]
  fill_in "user_seller_attributes_last_name", :with => @data[:last_name]
  fill_in "user_address_attributes_phone", :with => @data[:phone]
  fill_in "user_address_attributes_city", :with => @data[:city]
  fill_in "user_address_attributes_street", :with => @data[:street]
  fill_in "user_address_attributes_zip", :with => @data[:zip]
  select_val("user_address_attributes_country_id", @data[:country_id], "countrySelected();") unless @data[:country_id]==""
  select_val("user_address_attributes_state_id", @data[:state_id]) unless @data[:state_id]==""
end

def i_should_see_message(message)
  page.html.should have_html_tag(:p, :content => message)
end

#=====ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM ITEM=====#

def i_should_see_new_product_page
  page.html.should have_html_tag('span', :content => "this is the new product page", :class => 'temp', :print => true)
end

def i_should_see_new_product_form
#  puts page.html
  page.html.should have_html_tag(:label, :for => ITEM[:title_id], :content => Regexp.escape(I18n.t(:title)), :print => true)
  page.html.should have_html_tag(:input, :id => ITEM[:title_id], :print => false)
  page.html.should have_html_tag(:label, :for => ITEM[:description_id], :content => Regexp.escape(I18n.t(:description)), :print => false)
  page.html.should have_html_tag(:textarea, :id => ITEM[:description_id], :print => false)
  page.html.should have_html_tag(:label, :for => ITEM[:status_id], :content => Regexp.escape(I18n.t(:status)), :print => false)
  page.html.should have_html_tag(:select, :id => ITEM[:status_id], :print => false)
  page.html.should have_html_tag(:label, :for => ITEM[:currency_id], :content=>Regexp.escape(I18n.t(:currency)), :print => false)
  page.html.should have_html_tag(:select, :id => ITEM[:currency_id], :print => false)
  page.html.should have_html_tag(:label, :for => ITEM[:price_id], :content => Regexp.escape(I18n.t(:price)), :print => false)
  page.html.should have_html_tag(:input, :type => 'text', :id => ITEM[:price_id], :print => false)
  page.html.should have_html_tag(:label, :for => ITEM[:product_id_id], :content => Regexp.escape(I18n.t(:product_id)), :print => false)
  page.html.should have_html_tag(:input, :type => 'text', :id => ITEM[:product_id_id], :print => false)
  i_should_see_new_product_shipping_form
  i_should_see_new_product_categories_menu
  i_should_see_new_product_product_combination_menu
  i_should_see_new_product_images_form
end

def i_should_see_new_product_shipping_form(content=nil)
#  data = content ? @data : {:ship_from => '', }
  page.html.should have_html_tag(:select, :id => ITEM[:ship_from_id], :print => false)
  4.times do |n|
    page.html.should have_html_tag(:input, :type => 'checkbox', :id => ITEM[:shipping][n][:to_id], :print => false)
    page.html.should have_html_tag(:input, :type => 'text', :id => ITEM[:shipping][n][:cost_id], :print => false)
    page.html.should have_html_tag(:input, :type => 'text', :id => ITEM[:shipping][n][:add_cost_id], :print => false)
  end
end

def i_should_see_new_product_categories_menu(content=nil)
  page.html.should have_html_tag(:select, :id => ITEM[:categories][:primary_id], :print => false)
  page.html.should have_html_tag(:select, :id => ITEM[:categories][:subcategory1], :print => false)
  page.html.should have_html_tag(:select, :id => ITEM[:categories][:subcategory2], :print => false)
end

def i_should_see_new_product_product_combination_menu(content=nil)
  page.html.should have_html_tag(:select, :id => ITEM[:product_combinations][0][:color_id], :print => false)
  page.html.should have_html_tag(:select, :id => ITEM[:product_combinations][0][:size_id], :print => false)
  page.html.should have_html_tag(:input, :type => "text", :id => ITEM[:product_combinations][0][:quantity_id], :print => false)
end

def i_should_see_new_product_images_form(content=nil)
  page.html.should have_html_tag(:input, :type => "file", :id => ITEM[:images][0][:file_id], :print => false)
  page.html.should have_html_tag(:textarea, :id => ITEM[:images][0][:description_id], :print => false)
end

