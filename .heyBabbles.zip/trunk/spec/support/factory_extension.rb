require "rails"

module FactoryExtension
  include ActiveSupport::Inflector

  def first_instance_of(instance, options = {})
    label = options[:factory_label] || instance
    klass = options[:class].blank? ? "#{instance.to_s.classify}" : "#{options[:class]}"
    if options[:extra].blank?
      obj = (eval(klass + ".first") or Factory.create(label))
    else
      obj = (eval(klass + ".where(#{options[:extra].inspect}).first") or Factory.create(label))
    end
    obj = obj.send(options[:method]) unless options[:method].nil?
    obj
  end

  def season_date(point = :start, klass = Season)
    season = klass.order("end_date ASC").last
    extra_day = 4.days
    if point == :start
      date = season.nil? ? Time.now : (season.end_date + 2.days)
    else
      date = season.nil? ? (Time.now + extra_day) : (season.end_date + extra_day)
    end
    date
  end

  def factory_mock(klass)
    eval "#{klass.to_s.classify}.new.save(:validate => false)"
    eval "#{klass.to_s.classify}.first.id"
  end

  def additional_params_for(invoice, type = :item, status = 0)
    case type
      when :item
        product = invoice.identifier
        begin
          add = [{"sh_cost" => "#{Kernel::rand(10)}"},
                 {"add_sh_cost" => "#{Kernel::rand(20)}"},
                 {"name" => "#{product.try(:name)}"},
                 {"size" => ""},
                 {"color" => ""},
                 {"count" => "#{Kernel::rand(20)}"},
                 {"limit" => "#{Kernel::rand(5)}"},
                 {"tax" => "#{Kernel::rand(0.5)}"}]

          if status%2 == 0
            stat = 1
          else
            stat = 2
            if Kernel::rand(10)%2 == 0
              add = add + [{"shipping_info" => Faker::Lorem.paragraph(3)},
                           {"intracking_number" => "#{Kernel::rand(1000000)}"},
                           {"date_of_sent" => "#{Date.today-Kernel::rand(1000).days}"}]
            end
          end

          add.each do |hash|
            hash.each { |p_name, p_value| Factory(:additional_params, :params_name => p_name, :params_value => p_value, :identifier_id => invoice.id, :identifier_type => invoice.class.to_s) }
          end
          count = add[5]["count"].to_i
          limit = add[6]["limit"].to_i
          sh_cost = add[0]["sh_cost"].to_f
          add_sh_cost = add[1]["add_sh_cost"].to_f
          tax = add[7]["tax"].to_f
          unless product.try(:price).blank?
            item_cost = product.price.to_f.round(2)

            if count - limit > 0
              price = (item_cost + add_sh_cost) * (count - limit) + limit * (sh_cost + item_cost)
            else
              price = count * (sh_cost + item_cost)
            end

            price = (price + item_cost * count * tax).round(2)

            invoice.update_attributes(:item_price => item_cost, :price => price, :item_count => count, :status => stat)

          end
        rescue

        end
    end
  end

end
