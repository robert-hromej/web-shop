require File.expand_path("../base_factory", __FILE__)

FactoryGirl.define do
  factory :payment_option, :class => PaymentOption do
    params "params"
    sequence(:pay_key) { |n| "PA-123#{n}" }
    user_id { first_instance_of(:user, :method => :id) }
    sequence(:txn_id) { |n| "TRANSACTION ID IS #{n}" }
  end

  factory :receiver_option, :class => ReceiverOption do
    custom_id { first_instance_of(:seller, :method => :id) }
    payment_opt_id { first_instance_of(:payment_option, :method => :id, :class => PaymentOption) }
    sequence(:email) { Faker::Internet.email }
    sequence(:description) { |n| Faker::Lorem.paragraph(3) }
    sequence(:subtotal) { Kernel::rand(100) + 100 }
    total_tax { Kernel::rand(100) }
    total_shipping { Kernel::rand(100) }

    trait :recommendation do
      after_create do |option|
        common_product = first_instance_of(:product, :factory_label => :fast_item)
        2.times do

          seller = Factory(:seller_with_5_products)
          products = seller.store.products
          products.each do |product|
            Factory(:invoiced_product, :identifier_id => product.id, :receiver_option_id => option.id)
          end
          #Factory(:invoiced_product, :identifier_id => common_product, :invoice_data_id => invoice.id)
        end

      end

    end

    factory :invoice_with_recommendations, :traits => [:recommendation]
  end

  factory :invoice_product, :class => InvoiceItemData do
    item_price { first_instance_of(:product, :method => :price, :factory_label => :fast_item).to_i }
    item_count { first_instance_of(:product, :method => :available, :factory_label => :fast_item) }
    price { first_instance_of(:product, :method => :price, :factory_label => :fast_item).to_i + (Kernel::rand(100) + 1) }
    status Kernel::rand(3)+1

    trait :product do
      identifier_id { first_instance_of(:product, :method => :id, :factory_label => :fast_item) }
      identifier_type "Product"
      after_create { |product| additional_params_for(product, :item, product.receiver_option.id) }
    end

    trait :service do
      identifier_id { first_instance_of(:product_counter, :method => :id, :factory_label => :home_counter) }
      identifier_type "ProductCounter"
    end

    #invoice_data_id { first_instance_of(:invoice_data, :method => :id, :class => InvoiceData) }
    receiver_option_id { first_instance_of(:receiver_option, :method => :id, :class => ReceiverOption) }

    factory :invoiced_product, :traits => [:product]
    factory :invoiced_service, :traits => [:service]

  end

  factory :additional_params, :class => AdditionalParams do
    params_name "default_name"
    params_value "default_value"
    identifier_id 1
    identifier_type "default_type"
  end

  factory :product_season, :class => ProductSeason do
    product_id { first_instance_of :product, :method => :id, :factory_label => :independent_product }
    paid { Kernel::rand(2) == 1 }
    #season_id {Factory(:season).id}
    season_id { first_instance_of :season, :method => :id }
  end

end
