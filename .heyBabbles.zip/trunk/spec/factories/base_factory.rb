require 'factory_girl'
require 'faker'
require File.expand_path("../../support/factory_extension", __FILE__)
include FactoryExtension