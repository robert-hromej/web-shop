require File.expand_path("../base_factory", __FILE__)

FactoryGirl.define do

  factory :category, :class => Category do

    trait :main do
      title { ["Maternity", "Babies", "Kids", "Daddies"].at(Kernel::rand(3)) }
      level Category::MAIN_CATEGORIES_LEVEL
    end

    trait :sub do
      title { ["Clothes", "Accessories", "Shoes", "Toys"].at(Kernel::rand(3)) }
      level Category::SUB_CATEGORIES_LEVEL
    end

    trait :gender do
      title { ["Female", "Male", "Unisex"].at(Kernel::rand(2)) }
      level Category::GENDER_CATEGORIES_LEVEL
    end

    trait :size do
      sequence(:title) { |n| "Size-#{n}" }
      level Category::SIZE_CATEGORIES_LEVEL
    end

    trait :color do
      sequence(:title) { |n| "Color-#{n}" }
      level Category::COLOR_CATEGORIES_LEVEL
    end

    factory :main_category, :traits => [:main]
    factory :sub_category, :traits => [:sub]
    factory :gender_category, :traits => [:gender]
    factory :color_category, :traits => [:color]
    factory :size_category, :traits => [:size]

    factory :black_category, :traits => [:color] do
      title "Black"
    end
    factory :white_category, :traits => [:color] do
      title "White"
    end

    factory :l_category, :traits => [:color] do
      title "L"
    end
    factory :xl_category, :traits => [:size] do
      title "XL"
    end
  end


  factory :service do

    sequence(:price) { |n| Kernel::rand(100) }
    sequence(:points) { |n| Kernel::rand(1000) }

    trait :home do
      title "Home page featured"
      service_type 1
    end

    trait :search do
      title "Search page featured"
      service_type 2
    end

    factory :home_service, :traits => [:home]
    factory :search_service, :traits => [:search]
  end

  factory :currency do
    sequence(:title) { |n| "currency#{n}" }
  end

  factory :line_item, :class => LineItem do
    sequence(:count) { (Kernel::rand(10) + 1) }
    item_type { Factory(:item_type) }
    ship_to { first_instance_of :ship_to, :factory_label => :shipping_to }
    user { first_instance_of :user }
  end

  factory :shipping_to, :class => ShipTo do
    sequence(:cost) { (Kernel::rand(10) + 1) }
    sequence(:product_limit) { (Kernel::rand(5) + 1) }
    sequence(:additional_cost) { (Kernel::rand(10) + 1) }
    country { Factory(:ship_to) }
    product { Factory(:item) }
  end

  factory :image, :class => ApplicationImage do

    sequence(:position) { |n| n + 1 }
    sequence(:description) { |n| "image-description-#{n}" }

    image Rails.root.join("spec/fixtures/rails.png").open
    product_id { first_instance_of(:product, :factory_label => :fast_item).id }
    trait(:jpg) { image Rails.root.join("spec/fixtures/girl.jpg").open }
    trait(:gif) { image Rails.root.join("spec/fixtures/gif.gif").open }
    trait(:big) { image Rails.root.join("spec/fixtures/bigger5.jpg").open }
    trait(:yml) { image Rails.root.join("spec/fixtures/stub.yml").open }

    factory :image_gif, :traits => [:gif]
    factory :image_big, :traits => [:big]
    factory :image_jpg, :traits => [:jpg]
    factory :image_yml, :traits => [:yml]

  end


  factory :default_country, :class => Country do

    sequence(:title) { |n| "Country-#{n}" }

    trait :associated_instance do
      sequence(:country_type) { Country::BASE_RANGE.at(Kernel::rand(4)) }
      after_create { |record| record.states << Factory(:state, :country_id => record.id) }
    end

    trait :from do
      sequence(:country_type) { Country::FROM_RANGE.at(Kernel::rand(4)) }
    end

    trait :to do
      sequence(:country_type) { Country::TO_RANGE.at(Kernel::rand(4)) }
    end

    factory :country, :traits => [:associated_instance]
    factory :ship_from, :traits => [:from]
    factory :ship_to, :traits => [:to]

  end

  factory :state do
    sequence(:title) { |n| "state#{n}" }
  end

  factory :season, :class => Season do

    sequence(:title) { |n| "Season-#{n}" }
    sequence(:cost) { Kernel::rand(100) + 1 }
    sequence(:description) { Faker::Lorem.paragraph(3) }
    sequence(:start_date) { |n| Date.today + n.days }
    sequence(:end_date) { |n| Date.today + (n.days + 1.day) }

  end

end
