require File.expand_path("../base_factory", __FILE__)

FactoryGirl.define do

  factory :default_user, :class => User do
    username 'Test User'
    sequence(:email) { |n| Faker::Internet.email }
    sequence(:reset_password_token) { |n| SecureRandom.base64.tr("+/", "-_") }
    reset_password_sent_at Time.now
    sequence(:facebook_email) { |n| Faker::Internet.email }
    sequence(:facebook_uid) { |n| (Kernel::rand(1000000) + 1) }
    password 'please1'
    password_confirmation 'please1'
    registered 0

    trait :recomendation do
      after_create do |user|
        5.times { |n| Factory(:product_recomendation, :user_id => user.id) }
      end
    end

    trait :with_address do
      after_create { |user| user.address = Factory(:address, :user_id => user.id) }
    end

    factory :user_with_recommendation, :traits => [:recomendation]
    factory :user, :traits => [:with_address]

  end

  factory :address do
    sequence(:city) { |n| Faker::Address.city }
    sequence(:phone) { |n| Faker::PhoneNumber.phone_number.to_i }
    sequence(:street) { |n| Faker::Address.street_name }
    sequence(:zip) { |n| Faker::Address.zip_code.to_i }

    after_create do |address|
      country = Factory(:country)
      address.country_id = country.id
      address.state_id = country.states.first.id
    end
  end

  factory :default_seller, :class => Seller do
    sequence(:first_name) { |n| "first_name#{n}" }
    sequence(:last_name) { |n| "last_name#{n}" }
    sequence(:rating_average_behavior) { |n| "#{n+1}00" }

    trait :with_store do
      stores { |g| [g.association(:store)] }
    end

    trait :with_5_products do
      after_create do |seller|
        5.times { Factory(:fast_item, :store_id => seller.store.id) }
      end
    end

    trait :with_user do
      user
    end

    trait :fast do
      stores { [first_instance_of(:store)] }
      user_id { first_instance_of(:user, :method => :id) }
    end

    factory :seller_with_user, :traits => [:with_user]
    factory :seller, :traits => [:with_store]
    factory :seller_with_5_products, :traits => [:with_store, :with_5_products]
    factory :fast_seller, :traits => [:fast]
  end

  factory :store do
    sequence(:name) { |n| "name#{n}" }
    sequence(:bio) { |n| Faker::Lorem.paragraph(3) }
    sequence(:description) { |n| Faker::Lorem.paragraph(3) }
    sequence(:return_policy) { |n| Faker::Lorem.paragraph(3) }
    logo_content_type "image/jpeg"
    logo_file_name "2.JPG"
    logo_file_size 1708307
    logo_update_at DateTime.now

    trait :associated_instances do
      seller { Factory :seller_with_user }
    end

    factory :store_with_user, :traits => [:associated_instances]
  end

  factory :default_featured_vendor, :class => FeaturedVendor do
    start_date { season_date(:start, FeaturedVendor) }
    end_date { season_date(:end, FeaturedVendor) }

    trait :new do
      seller
    end

    trait :fast do
      seller { first_instance_of(:seller) }
    end

    factory :featured_vendor, :traits => [:fast]
    factory :new_featured_vendor, :traits => [:new]

  end
end
