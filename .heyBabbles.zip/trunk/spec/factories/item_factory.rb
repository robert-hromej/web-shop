require File.expand_path("../base_factory", __FILE__)

FactoryGirl.define do

  factory :default_product, :class => Product do
    product_sid "ItemProductId"
    sequence(:name) { |n| "product#{n}" }
    sequence(:description) { |n| Faker::Lorem.paragraph(3) }
    sequence(:return_policy) { |n| Faker::Lorem.paragraph(3) }
    sequence(:price) { |n| Kernel::rand(100) }
    sequence(:new) { [true, false].at(Kernel::rand(2)) }

    currency_id { first_instance_of(:currency, :method => :id) }
    seller_id { first_instance_of(:seller, :method => :id, :factory_label => :fast_seller, :class => Seller) }
    ship_from_id { first_instance_of(:ship_from, :method => :id, :factory_label => :ship_from, :class => Country) }
    after_create do |product|
product.accepted = [nil, 1, 2].at(Kernel::rand(3))
end


    trait :associated_instances do
      after_create do |item|
        2.times do
          item.destinations << Factory(:shipping_to, :product_id => item.id)
        end
      end
      combination_id { first_instance_of(:combination, :method => :id) }
      store_id { first_instance_of(:store, :method => :id, :class => Store, :factory_label => :store_with_user) }
    end

    trait :fast do
      combination_id { first_instance_of(:combination, :method => :id) }
      store_id { first_instance_of(:store, :method => :id, :class => Store, :factory_label => :store_with_user) }
      item_types { ItemType.count > 4 ? [first_instance_of(:item_type)] : [Factory(:item_type), Factory(:item_type)] }
      after_create do |item|
        ship_to = ShipTo.first || Factory(:shipping_to, :product_id => item.id)
        item.destinations << ship_to
      end
    end

    trait :more_associations do
      after_create { |item| 2.times { item.images << Factory(:image, :product_id => item.id) } }
      after_create { |item| item.update_attribute(:expiration_date, (DateTime.now() + Kernel::rand(10).days)) }
      item_types { |d| [d.association(:item_type), d.association(:item_type)] }
    end

    trait :independent do
      after_create { |item| item.images << Factory(:image, :product_id => item.id) }
      currency_id { first_instance_of(:currency, :method => :id) }
    end

    trait :impressions do
      product_counters { |d| [d.association(:home_counter)] }
    end

    trait :recommnedations do
      after_create do |product|
        product.product_recomendations << Factory(:recomendation, :product_id => product.id, :user_id => product.seller.user.id)
      end
    end

    trait :with_accepted do
      after_create do |item|
        item.accepted = [nil, 0, 1].at(Kernel::rand(3))
      end
    end

    factory :product_with_impressions, :traits => [:with_accepted, :impressions, :fast]
    factory :fast_item, :traits => [:with_accepted, :fast]
    factory :item, :traits => [:with_accepted, :associated_instances, :more_associations, :impressions]
    factory :independent_product, :traits => [:with_accepted, :associated_instances, :independent]
    factory :product, :traits => [:with_accepted]
    factory :product_without_accepted, :traits => [:associated_instances, :more_associations, :impressions]

  end

  factory :product_counter, :class => ProductCounter do
    sequence(:points) { Kernel::rand(100) }
    payed true
    product_id { first_instance_of(:product, :method => :id, :factory_label => :independent_product) }

    trait :home do
      service_type { first_instance_of(:service, :method => :service_type, :factory_label => :home_service) }
    end

    trait :search do
      service_type { first_instance_of(:service, :method => :service_type, :factory_label => :search_service) }
    end

    factory :home_counter, :traits => [:home]
    factory :search_counter, :traits => [:search]
  end

  factory :default_combination, :class => Combination do
    sequence(:category_id) { |n| (Kernel::rand(5) + 1) }
    trait :fast do
      category_id { first_instance_of(:category, :method => :id, :factory_label => :main_category, :extra => {:level => 1}) }
      subcategory_id { first_instance_of(:category, :method => :id, :factory_label => :sub_category, :extra => {:level => 2}) }
      gender_category_id { first_instance_of(:category, :method => :id, :factory_label => :gender_category, :extra => {:level => 5}) }
    end
    trait :slow do
      category_id { Factory(:main_category).id }
      subcategory_id { Factory(:sub_category).id }
      gender_category_id { Factory(:gender_category).id }
    end
    factory :combination, :traits => [:fast]
    factory :slow_combination, :traits => [:slow]
  end

  factory :default_item_type, :class => ItemType do
    sequence(:item_count) { Kernel::rand(50) + 20 }
    sequence(:price) { Kernel::rand(20) + 1 }
    trait :associated_instances do
      size_category_id { first_instance_of(:category, :extra => {:level => 4}, :factory_label => :size_category).id }
      color_category_id { first_instance_of(:category, :extra => {:level => 5}, :factory_label => :color_category).id }
      product_id { first_instance_of(:product, :factory_label => :independent_product).id }
    end

    trait :black do
      color_category_id { Factory(:black_category).id }
    end

    trait :white do
      color_category_id { Factory(:white_category).id }
    end

    trait :xl do
      size_category_id { Factory(:xl_category).id }
    end

    trait :l do
      size_category_id { Factory(:l_category).id }
    end

    factory :item_type, :traits => [:associated_instances]
    factory :black_xl_item_type, :traits => [:black, :xl]
    factory :white_l_item_type, :traits => [:white, :l]
  end


end

