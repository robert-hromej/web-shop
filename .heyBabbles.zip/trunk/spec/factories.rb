require 'factory_girl'
require 'faker'
require "seed"
require File.expand_path("../support/factory_extension", __FILE__)

include Seed
include FactoryExtension

FactoryGirl.define do

  factory :user do
    username 'Test User'
    sequence(:email) { |n| Faker::Internet.email }
    sequence(:reset_password_token) { |n| SecureRandom.base64.tr("+/", "-_") }
    reset_password_sent_at Time.now
    sequence(:facebook_email) { |n| Faker::Internet.email }
    sequence(:facebook_uid) { |n| (Kernel::rand(1000000) + 1) }
    password 'please1'
    password_confirmation 'please1'
    registered 0
    address_attributes { Factory(:address).attributes.except("id") }
  end

  factory :address do
    sequence(:city) { |n| Faker::Address.city }
    sequence(:phone) { |n| Faker::PhoneNumber.phone_number.to_i }
    sequence(:street) { |n| Faker::Address.street_name }
    sequence(:zip) { |n| Faker::Address.zip_code.to_i }
    country
    state
  end

  factory :seller do
    sequence(:first_name) { |n| "first_name#{n}" }
    sequence(:last_name) { |n| "last_name#{n}" }
    sequence(:rating) { |n| "#{n+1}00" }
    stores { |g| [g.association(:store)] }
  end

  factory :store do
    sequence(:name) { |n| "name#{n}" }
    sequence(:bio) { |n| Faker::Lorem.paragraph(3) }
    sequence(:description) { |n| Faker::Lorem.paragraph(3) }
    sequence(:return_policy) { |n| Faker::Lorem.paragraph(3) }
    logo_content_type "image/jpeg"
    logo_file_name "2.JPG"
    logo_file_size 1708307
    logo_update_at DateTime.now
  end

  factory :item do
    currency
    seller_id 1
    combination_id 1

    product_sid "ItemProductId"
    sequence(:name) { |n| "item#{n}" }
    sequence(:description) { |n| Faker::Lorem.paragraph(3) }
    sequence(:return_policy) { |n| Faker::Lorem.paragraph(3) }
    sequence(:price) { |n| Kernel::rand(100) }
    expiration_date (Time.now() + 30.days)
    sequence(:new) { |n| Kernel::rand(1) }
    accepted 1
    # We don`t need because of before_save and virtual attr
    #item_counters { |g| [g.association(:item_counter)] }
    images { |d| [d.association(:image), d.association(:image)] }
    matrixes { |d| [d.association(:matrix)] }
  end

  factory :item_counter, :class => ItemCounter do
    trait :impressions do
      service_type 1
      sequence(:impressions) { Kernel::rand(100) }
    end
    trait :images do
      service_type 2
      sequence(:impressions) { Kernel::rand(5) + 1 }
    end
    factory :item_impressions, :traits => [:impressions]
    factory :item_images, :traits => [:images]
  end

  factory :service do
    sequence(:title) { |n| "Service type - #{n}" }
    sequence(:service_type) { |n| n }
    sequence(:price) { |n| Kernel::rand(100) }
    sequence(:value) { |n| Kernel::rand(1000) }
    start_date Date.today
    end_date (Date.today + 3.months)
  end

  factory :combination do
    sequence(:category_id) { |n| (Kernel::rand(5) + 1) }
    subcategory_id 1
    gender_id 1
  end

  factory :category do
    sequence(:title) { |n| "Category#{n}" }
    sequence(:level) { |n| (Kernel::rand(3) + 1) }
  end

  factory :currency do
    sequence(:title) { |n| "currency#{n}" }
  end

  factory :shipping do
    from_shipping
    to_shipping
    sequence(:shipping_cost) { (Kernel::rand(1000) + 1) }
    sequence(:additional_shipping_cost) { (Kernel::rand(1000) + 1) }
  end

  factory :invoice do
    sequence(:transaction_info) { |n| Faker::Lorem.paragraph(3) }
    sequence(:subtotal) { (Kernel::rand(1000) + 1) }
    sequence(:pay_date) { DateTime.now.to_date }
  end

  factory :cart do
    sequence(:clone_info) { |n| Faker::Lorem.paragraph(3) }
    sequence(:status) { (Kernel::rand(2) + 1) }
    sequence(:shipping_info) { |n| Faker::Lorem.paragraph(3) }
    sequence(:intracking_number) { (Kernel::rand(1000000)) }
    sequence(:date_sent) { DateTime.now.to_date }
    sequence(:quantity) { (Kernel::rand(10)) }
  end

  factory :item_with_shippings_and_images_matrixes, :parent => :item do
    shippings { |g| [g.association(:shipping), g.association(:shipping)] }
    images { |d| [d.association(:image), d.association(:image)] }
    matrixes { |d| [d.association(:matrix)] }
    combination
  end


  factory :from_shipping do
    sequence(:name) { |n| Faker::Address.country }
  end

  factory :to_shipping do
    sequence(:name) { |n| Faker::Address.country }
  end

  factory :image, :class => ApplicationImage do |t|
    main 1
    description "description"
    trait :jpg do
      image Rails.root.join("spec/fixtures/girl.jpg").open
    end

    image Rails.root.join("spec/fixtures/rails.png").open

    trait :gif do
      image Rails.root.join("spec/fixtures/gif.gif").open
    end

    trait :big do
      image Rails.root.join("spec/fixtures/bigger5.jpg").open
    end

    trait :yml do
      image Rails.root.join("spec/fixtures/authentications.yml").open
    end

    factory :image_gif, :traits => [:gif]
    factory :image_big, :traits => [:big]
    factory :image_jpg, :traits => [:jpg]
    factory :image_yml, :traits => [:yml]
  end

  factory :default_matrix, :class => Matrix do
    trait :first_instances do
      color_id { first_instance_of(:color, :method => :id) }
      size_id { first_instance_of(:size, :method => :id) }
    end
    trait :associated_instances do
      color
      size
    end
    sequence(:quantity) { Kernel::rand(50) }
    factory :fast_matrix, :traits => [:first_instances]
    factory :matrix, :traits => [:associated_instances]
  end

  factory :color do
    title "color"
    seller_id nil
  end

  factory :size do
    title "size"
  end

  factory :country do
    sequence(:title) { Faker::Address.country }
    states { |g| [g.association(:state)] }
  end

  factory :state do
    sequence(:title) { |n| "state#{n}" }
  end

  factory :featured_vendor do
    sequence(:start_date) { |n| Date.today + n.days }
    sequence(:end_date) { |n| Date.today + (n.days + 1.day) }
    seller
  end

  sequence :email do |n|
    "email-#{n}@email.com"
  end

  factory :user_seller, :parent => :user do
    seller
  end

  factory :seller_store, :parent => :seller do
    store
  end

  factory :vendor, :parent => :user do
    seller
  end

  factory :payment_options, :class => PaymentOptions do
    params "params"
    sequence(:pay_key) { |n| "PA-123#{n}" }
    sender_email { first_instance_of(:user, :method => :email) }
  end

  factory :receiver_options, :class => ReceiverOptions do
    custom_id { first_instance_of(:seller, :method => :id) }
    payment_opt_id { first_instance_of(:payment_options, :method => :id, :class => PaymentOptions) }
    sequence(:email) { Faker::Internet.email }
    sequence(:description) { |n| Faker::Lorem.paragraph(3) }
  end

  factory :invoice_data, :class => InvoiceData do
    sequence(:subtotal) { Kernel::rand(100) + 100 }
    total_tax { Kernel::rand(100) }
    total_shipping { Kernel::rand(100) }
    receiver_opt_id { first_instance_of(:receiver_options, :method => :id, :class => ReceiverOptions) }
  end

  factory :invoice_item, :class => InvoiceItemData do
    item_price { first_instance_of(:item, :method => :price, :factory_label => :independent_item) + (Kernel::rand(100) + 1) }
    item_count { first_instance_of(:item, :method => :available, :factory_label => :independent_item) }
    price { first_instance_of(:item, :method => :price) }

    trait :item do
      identifier_id { first_instance_of(:matrix, :method => :id) }
      identifier_type "Matrix"
    end

    trait :service do
      identifier_id { first_instance_of(:item_counter, :method => :id) }
      identifier_type "ItemCounter"
    end

    invoice_data_id { first_instance_of(:invoice_data, :method => :id, :class => InvoiceData) }
    clone_info "info"

    factory :invoiced_item, :traits => [:item]
    factory :invoiced_service, :traits => [:service]
  end

  factory :independent_item, :class => Item do

    currency_id { first_instance_of(:currency, :method => :id) }
    seller_id { first_instance_of(:seller, :method => :id) }
    combination_id { first_instance_of(:combination, :method => :id) }

    category_id { first_instance_of(:combination, :method => :category_id) }
    subcategory_id { first_instance_of(:combination, :method => :subcategory_id) }
    gender_id { first_instance_of(:combination, :method => :gender_id) }

    product_sid "ItemProductId"
    sequence(:name) { |n| "item#{n}" }
    sequence(:description) { |n| Faker::Lorem.paragraph(3) }
    sequence(:return_policy) { |n| Faker::Lorem.paragraph(3) }
    sequence(:price) { |n| Kernel::rand(100) }
    expiration_date (Time.now() + 30.days)
    sequence(:new) { |n| Kernel::rand(1) }
    accepted 1

    shippings { |d| [d.association(:shipping)] }
    images { |d| [d.association(:image)] }

    matrixes { |d| [d.association(:fast_matrix)] }
    trait :impressions do
      item_counters { |d| [d.association(:item_impressions)] }
    end
    factory :item_with_impressions, :traits => [:impressions]
  end
end

