require File.expand_path("../../../app/helpers/home_helper", __FILE__)
#require "spec_helper"

describe HomeHelper do

  let(:helper) { mock.extend HomeHelper }

  context "Call#new?" do

    it "should return true, when product is new" do
      product = mock().as_null_object
      product.stub!(:new).and_return(true)
      helper.new?(product).should == "New"
    end

    it "should return false, when product is not new" do
      product = mock().as_null_object
      product.stub!(:new).and_return(false)
      helper.new?(product).should == "Used"
    end
  end

  context "#seller_fullname" do
    #@seller.stub!(:fullname).and_return("Tom Koptel")
    it "returns the instance variable" do
      pending "Miroslav (comment:'can not stub instance variable')"

      @seller = mock.stub(:fullname => "Tom Koptel")
      helper.seller_fullname.should eq "Featured Vendor is Tom Koptel"
    end
  end

end