require 'spec_helper'

require "action_controller"

describe SessionsHelper do
  describe ".deny_access" do
    #before(:each) do
    #  @request = stub('request')
    #  @request.stub(:fullpath => "#{user_url(1)}")
    #  @request.stub(:flash => {})
    #  @session = stub(:session => {})
    #end
    it "should assign notice" do
      pending("Waiting implementation")
      deny_access
      request.flash.should eq(:notice => {:title => I18n.t(:deny), :message => I18n.t(:notice_sign_in)})
    end
  end

  describe "recent products" do

    it "should add new item" do
      helper.recent_products(2).last.should eq(2)
    end

    it "should not add the same item twice" do
      helper.recent_products(2)
      helper.recent_products(2).length.should eq(1)
    end

    it "should not exceed 6 products" do
      10.times{|n| helper.recent_products(n)}
      helper.recent_products(2).length.should eq(6)
    end

    it "should require Fixnum" do
      expect{ helper.recent_products('2') }.should raise_error("Fixnum required")
    end

  end

end
