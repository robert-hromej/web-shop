require 'spec_helper'

describe ApplicationHelper do
  context "html_id" do
    it "should return a simgle downcase word" do
      helper.html_id("Seller Account").should eq "seller_account"
      helper.html_id("Seller_Account").should eq "seller_account"
      helper.html_id("Seller_account").should eq "seller_account"
      helper.html_id("Seller Account One").should eq "seller_account_one"
    end
    it "should not return the same value" do
      helper.html_id("Seller Account").should_not eq "Seller Account"
    end
  end


  context "cnav_links" do
    it "should be checked too" do
      pending "Laslo"
    end
  end

end
