require 'spec_helper'
#require 'support/factory_extension'

describe FactoryExtension do
  let(:extension) { mock.extend FactoryExtension }

  context "#first_instance_of :product, :factory_label => :independent_product" do

    it "with methods" do
      pending "Deprecated Bodya"
      [:available, :price].each do |method|
        extension.first_instance_of(:product, :factory_label => :independent_product, :method => method).should_not be_blank
      end
    end

    it "with no methods" do
      extension.first_instance_of(:product, :factory_label => :independent_product).should be_a(Product)
    end

  end

  context "#first_instance_of :user" do

    it "with methods" do
      [:id].each do |method|
        extension.first_instance_of(:user, :method => method).should_not be_blank
      end
    end

    it "with no methods" do
      extension.first_instance_of(:user).should be_a(User)
    end

  end

  context "#first_instance_of :payment_option" do

    it "with methods" do
      [:id].each do |method|
        extension.first_instance_of(:payment_option, :method => method, :class => PaymentOption).should_not be_blank
      end
    end

    it "with no methods" do
      extension.first_instance_of(:payment_option, :class => PaymentOption).should be_a(PaymentOption)
    end

  end

  context "#first_instance_of :combination" do

    it "with methods" do
      [:id, :subcategory_id, :category_id, :gender_category_id].each do |method|
        extension.first_instance_of(:combination, :method => method).should_not be_blank
      end
    end

    it "with no methods" do
      extension.first_instance_of(:combination).should be_a(Combination)
    end

  end

  it "#first_instance_of :receiver_options, :method => :id, :class => ReceiverOption" do
    extension.first_instance_of(:receiver_option, :method => :id).should be_a(Fixnum)
  end

  it "#first_instance_of :seller, :method => :id" do
    extension.first_instance_of(:seller, :method => :id).should be_a(Fixnum)
  end

  it "#first_instance_of :currency, :method => :id" do
    extension.first_instance_of(:currency, :method => :id).should be_a(Fixnum)
  end

end