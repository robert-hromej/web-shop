require 'spec_helper'

describe DbCart::Cart do

  before(:each) do
    @user = Factory(:user)
    @cart = DbCart::Cart.new(@user)
    @line_item = Factory(:line_item, :user_id => @user.id)
  end

  it "should initialize a cart with a right user" do
    @cart.current_user.should == @user
  end

  context "get_items" do

    it "should get items from cart" do
      line_items = [@line_item]
      4.times do
        line_items << Factory(:line_item, :user_id => @user.id)
      end
      @cart.get_items.should == line_items
    end

    it "should not get items that is not in cart" do
      line_items = [@line_item]
      4.times do
        line_items << Factory(:line_item, :user_id => (Factory(:user)).id)
      end
      @cart.get_items.should == [@line_item]
    end

  end

  it "should fetch an item from cart by item_type and ship_to" do
    params = {:item_type_id => @line_item.item_type.id, :ship_to_id => @line_item.ship_to.id}
    @cart.fetch_line_item(params).should == @line_item
  end

  it "should get item type of item" do
    @cart.get_item_type(@line_item).should == @line_item.item_type
  end

  it "should update a line item" do
    count = rand(20)
    @cart.update_line_item(@line_item, count)
    @line_item.count.should == count
  end

  it "should destroy a line item" do
    @cart.destroy_line_item(@line_item)
    LineItem.find_by_id(@line_item.id).should be_nil
  end

  it "should add an item to cart" do
    count = LineItem.count
    item = LineItem.new(Factory.attributes_for(:line_item, :user => nil))
    @cart.add_item(item)
    LineItem.count.should == count+1
  end

end
