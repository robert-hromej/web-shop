require 'spec_helper'


describe AdaptivePayment::PayKey, :focus => true do
  include SharedExample
  let(:helper) { TestPayKey::TestHelper.new }

  context "Initialized" do
    subject { AdaptivePayment::PayKey.new() }
    it { should be_an_instance_of(AdaptivePayment::PayKey) }
    it { should respond_to :receiver_list }
    it { should respond_to :fetch_pay_key }
    it { should respond_to :data }
    it { should respond_to :response }
  end

  it_behaves_like "BaseResource instance"

  describe "Call" do

    before(:all) do
      @txn = helper.txn
      @receivers = helper.receivers
    end

    context "#receiver_list" do

      context "with valid params" do
        it "should add new 'receivers'" do

          @txn.receiver_list(@receivers)
          @txn.data["receiverList"]["receiver"].should eq(@receivers)
        end
      end

      context "with invalid params" do
        it "should raise an Error" do
          expect { @txn.receiver_list }.should raise_error("Receivers can't be blank!")
        end
      end

    end

    context "#fetch_pay_key" do

      context "for valid object" do
        before(:each) do
          @pay_key = helper.init_txn
          @txn = helper.txn
        end

        it "should return response with body" do
          @txn.response.body.should_not be_blank
        end

        it "should return response code '200'" do
          @txn.response.code.should eq('200')
        end

        it "should be SUCCESS" do
          response = @txn.response
          @txn.response_valid?(response).should be_true
        end

        it "should return PAY KEY" do
          @pay_key.should match(/AP-\w{17}/)
        end

        it "should send post" do
          pending("still fail")
          #nedd to update all signatures/accounts before fixing this test
          body = {"cancelUrl"=>"http://rmd-sw.dyndns.info:4012/cancel_test", "returnUrl"=>"http://rmd-sw.dyndns.info=>4012/return_test", "receiverList"=>{"receiver"=>[{"amount"=>"1.00", "email"=>"buyer_1320835920_per@gmail.com"}, {"amount"=>"1.00", "email"=>"seller_1301406330_biz@gmail.com"}]}, "ipnNotificationUrl"=>"http://irromance.com/ipn_test", "actionType"=>"PAY", "requestEnvelope"=>{"errorLanguage"=>"en_US"}, "currencyCode"=>"USD"}
          a_request(:post, "svcs.sandbox.paypal.com/AdaptivePayments/Pay").with(
              :body => ActiveSupport::JSON.encode(body),
              :headers => {'Accept'=>'*/*', 'X-Paypal-Application-Id'=>'APP-80W284485P519543T', 'X-Paypal-Device-Ipaddress'=>'0.0.0.0', 'X-Paypal-Request-Data-Format'=>'JSON', 'X-Paypal-Response-Data-Format'=>'JSON', 'X-Paypal-Security-Password'=>'1315324405', 'X-Paypal-Security-Signature'=>'AIfMAwpSlelhLr7i.8pZeH2QER6gAp49vkoLwgaOdeN1uuf6Z02gLKxi', 'X-Paypal-Security-Userid'=>'myapi_1315324344_biz_api1.gmail.com', 'X-Paypal-Service-Version'=>'1.0.0'}
          ).should have_been_made.times(1)
        end
      end

      context "for not valid object" do
        before(:all) do
          @pay_key = helper.init_txn(false)
          @txn = helper.txn
        end

        it "should return response with body" do
          @txn.response.body.should_not be_blank
        end

        it "should return response code '200'" do
          @txn.response.code.should eq('200')
        end

        it "should response with FAILURE" do
          response = @txn.response
          @txn.response_valid?(response).should be_false
        end

        it "should not return 'PayKey'" do
          @pay_key.should be_nil
        end

        it "should send POST anyway" do
          pending("still fail")
          a_request(:post, "svcs.sandbox.paypal.com/AdaptivePayments/Pay").should have_been_made.times(1)
        end
      end

    end

  end
end


module TestPayKey
  class TestHelper
    attr_accessor :params, :txn

    def initialize
      @params = {"returnUrl" => "return_test", "cancelUrl" => "cancel_test", "ipnNotificationUrl" => "ipn_test"}
      @txn = AdaptivePayment::PayKey.new(@params)
    end


    def init_txn(valid = true)
      txn.data.merge!("receiverList" => {"receiver" => receivers(valid)})
      txn.fetch_pay_key
    end

    def receivers(valid = true)
      if valid
        [{"email"=>"buyer_1304600601_per@gmail.com", "amount"=>"1.00"},
         {"email"=>"seller_1301406330_biz@gmail.com", "amount"=>"1.00"}]
      else
        [{"email"=>"buyer_1304600601_per@gmail.com", "amount"=>""},
         {"email"=>"seller_1301406330_biz@gmail.com", "amount"=>""}]
      end
    end

  end
end
