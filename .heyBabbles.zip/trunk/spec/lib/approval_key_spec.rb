require 'spec_helper'


describe AdaptivePayment::ApprovalKey, :focus => true do
  include SharedExample

  def params
    {"returnUrl" => "return_test", "cancelUrl" => "cancel_test", "ipnNotificationUrl" => "ipn_test"}
  end

  before(:all) { Timecop.return }

  context "Initialized" do
    it { should be_an_instance_of(AdaptivePayment::ApprovalKey) }
    it { should respond_to :approval_settings }
    it { should respond_to :fetch_approval_key }
    it { should respond_to :data }
    it { should respond_to :response }
  end

  it_behaves_like "BaseResource instance"

  describe "Call" do
    before(:each) { @txn = AdaptivePayment::ApprovalKey.new(params) }

    context "#approval_settings" do
      before(:each) { Timecop.freeze(Time.now) }

      it "should set default values" do
        @txn.approval_settings
        @txn.data[:maxAmountPerPayment].should eq(200.00)
      end

      it "should set a new value" do
        @txn.approval_settings(:maxAmountPerPayment => 500.00)
        @txn.data[:maxAmountPerPayment].should eq(500.00)
      end

      it "should set time range" do
        @txn.approval_settings
        date = Time.new
        end_date = "#{date.year + 1}-#{date.strftime("%m")}-#{date.strftime("%d")}"

        @txn.data[:endingDate].should eq(end_date)
      end

    end

    context "#fetch_preapproval_key" do
      context "with valid params" do
        before(:each) { @txn.approval_settings }

        it "should return approval key" do
          @txn.fetch_approval_key.should_not be_nil
        end

      end
      context "with invalid params" do
        before(:each) { @txn.approval_settings(:maxTotalAmountOfAllPayments => "invalid") }

        it "should not return approval key" do
          @txn.fetch_approval_key.should be_nil
        end

      end
    end
  end
end