require "spec_helper"


describe AdaptivePayment::Base, :focus => true do
  def params
    {"returnUrl" => "return_test", "cancelUrl" => "cancel_test", "ipnNotificationUrl" => "ipn_test"}
  end

  def response(status = :success)
    case (status)
      when :success
        stub_request(:any, "www.example.com").to_return(:body => "{\"responseEnvelope\":{\"ack\":'Success'}}", :status => 200, :headers => {'Content-Length' => 3})
      when :fail
        stub_request(:any, "www.example.com").to_return(:body => "{\"responseEnvelope\":{\"ack\":'Failure'}}", :status => 200, :headers => {'Content-Length' => 3})
      when :fatal
        stub_request(:any, "www.example.com").to_return(:status => [500, "Internal Server Error"])
    end
    req = Net::HTTP::Get.new("/")
    Net::HTTP.start("www.example.com") { |http| http.request(req) }
  end

  it_behaves_like "BaseResource instance"

  describe "Call" do

    before(:each) { @base = AdaptivePayment::Base.new }

    context "#send" do

      before(:each) { WebMock.disable_net_connect! }

      it "should raise error for no attr" do
        expect { @base.send(nil, nil) }.should raise_error("You have specified wrong attr")
      end

      it "should raise error for no 'service'" do
        expect { @base.send(nil, {:key => "value"}) }.should raise_error
      end

      it "should raise error for no 'data'" do
        expect { @base.send("/Addaptive", nil) }.should raise_error
      end

      context "make a http post request which" do

        before(:each) do
          @stub = stub_request(:post, "https://svcs.sandbox.paypal.com/AdaptivePayments/Pay").
              with(:body => "{\"key\":\"value\"}",
                   :headers => {'Accept'=>'*/*', 'X-Paypal-Application-Id'=>'APP-80W284485P519543T', 'X-Paypal-Device-Ipaddress'=>'0.0.0.0', 'X-Paypal-Request-Data-Format'=>'JSON', 'X-Paypal-Response-Data-Format'=>'JSON', 'X-Paypal-Security-Password'=>'1315324405', 'X-Paypal-Security-Signature'=>'AIfMAwpSlelhLr7i.8pZeH2QER6gAp49vkoLwgaOdeN1uuf6Z02gLKxi', 'X-Paypal-Security-Userid'=>'myapi_1315324344_biz_api1.gmail.com', 'X-Paypal-Service-Version'=>'1.0.0'}).
              to_return(:status => 200, :body => "", :headers => {})
          @response = @base.send("/AdaptivePayments/Pay", {:key => "value"})
        end

        it("should be success") { @stub.should have_been_requested }

        it("should return object") { @response.should_not be_nil }

        it("should return 'Net' object") { @response.should be_a(Net::HTTPOK) }

      end

    end

    context "#decode_response" do
      it "should decode JSON" do
        @base.decode_response(response).should eq({"responseEnvelope" => {"ack" => "Success"}})
      end
    end

    context "#response_valid?" do

      it "should raise error for invalip 'response'" do
        expect { @base.response_valid?(nil) }.should raise_error("Response Failed")
      end

      {:success => true, :fatal => false, :fail => false}.each do |key, value|

        it "should return '#{value.inspect}' #{key == :fatal ? 'if not "Net::HTTPOK"' : ('for Acknowledged as ' + value.inspect) }" do
          @base.response_valid?(response(key)).should be(value)
        end

      end

    end
  end
end