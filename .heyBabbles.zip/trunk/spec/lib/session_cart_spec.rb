require 'spec_helper'

describe SessionCart::Cart do

  before(:each) do
    @item_type = Factory(:item_type)
    @session = {:cart_items => [ {@item_type.id => {:ship_to => 1, :count => 1}}, {2 => {:ship_to => 2, :count => 2}} ]}
    @cart = SessionCart::Cart.new(@session)
    @line_item = @session[:cart_items].first
  end

  it "should initialize a cart with a right session" do
    @cart.session.should == @session
  end

  it "should get items from cart" do
    items = @cart.get_items
    items.length.should == 2
    items.each_with_index do |item, index|
      item.should be_a(LineItem)
      item.count.should == index+1
    end
  end

  it "should fetch an item from cart by item_type and ship_to" do
    @cart.fetch_line_item({:item_type_id => "2", :ship_to_id => "2"}).should == @session[:cart_items].second
  end

  it "should get item type of item" do
    @cart.get_item_type(@line_item).should == @item_type
    @cart.get_item_type(@line_item).should be_a(ItemType)
  end

  it "should update a line item" do
    count = rand(20)
    @cart.update_line_item(@line_item, count)
    @line_item.values.first[:count].should == count
    @session[:cart_items].first.values.first[:count].should == count
  end

  it "should destroy a line item" do
    line_item = @session[:cart_items].second
    @cart.destroy_line_item(@line_item)
    @session[:cart_items].count.should == 1
    @session[:cart_items].first.should == line_item
  end

  context "add to cart" do

    it "should add an item to cart if there are items already" do
      count = @session[:cart_items].count
      line_item = Factory(:line_item)
      @cart.add_item(line_item)
      @session[:cart_items].count.should == count+1
      @session[:cart_items].find_all { |e| e.keys.include?(line_item.item_type_id) }.find { |e| e.values.first[:ship_to] == line_item.ship_to_id }.should_not be_blank
    end

    it "should add an item to cart if cart is empty" do
      @session[:cart_items] = []
      line_item = Factory(:line_item)
      expect {
        @cart.add_item(line_item)
      }.to change(@session[:cart_items], :count).by(1)
      @session[:cart_items].find_all { |e| e.keys.include?(line_item.item_type_id) }.find { |e| e.values.first[:ship_to] == line_item.ship_to_id }.should_not be_blank
    end

    it "should add an item to cart if cart is not exists yet" do
      @session[:cart_items] = nil
      line_item = Factory(:line_item)
      @cart.add_item(line_item)
      @session[:cart_items].count.should == 1
      @session[:cart_items].find_all { |e| e.keys.include?(line_item.item_type_id) }.find { |e| e.values.first[:ship_to] == line_item.ship_to_id }.should_not be_blank
    end

  end

end
