require "spec_helper"

describe CartsController do
  describe "routing" do
    it "should route to" do
      post("/cart/add").should route_to("carts#add")
    end

    it "should route to" do
      post("/cart").should route_to("carts#update")
    end

    it "should route to" do
      post("/cart/remove").should route_to("carts#remove")
    end

    it "should route to" do
      post("/cart/validate").should route_to("carts#validate")
    end

    it "should route to" do
      get("/cart").should route_to("carts#index")
    end
  end
end
