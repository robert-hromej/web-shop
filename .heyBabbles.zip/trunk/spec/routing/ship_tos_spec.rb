require "spec_helper"

describe ShipTosController do

  describe "routing" do

    it "routes to #create" do
      post("/ship_tos").should route_to("ship_tos#create")
    end

    it "routes to #update" do
      put("/ship_tos/1").should route_to("ship_tos#update", :id => "1")
    end

    it "routes to #destroy" do
      delete("/ship_tos/1").should route_to("ship_tos#destroy", :id => "1")
    end

  end

end
