require "spec_helper"

describe ItemTypesController do

  describe "routing" do

    it "routes to #create" do
      post("/item_types").should route_to("item_types#create")
    end

    it "routes to #destroy" do
      delete("/item_types/1").should route_to("item_types#destroy", :id => "1")
    end

  end

end
