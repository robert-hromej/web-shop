require "spec_helper"

describe FeedbacksController do

  describe "routing" do
    it "routes to #index" do
      get("/sellers/1/feedbacks").should be_routable("feedbacks#index", :id => "1")
    end

    it "routes to #create" do
      post("/feedbacks/1/1").should be_routable("feedbacks#create", :writeable_id => "1", :write_through_id => "1")
    end
  end

end