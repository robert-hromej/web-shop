require "spec_helper"

describe PasswordResetController do
  describe "routing" do

    it "routes to #new" do
      get("/password_reset/new").should route_to("password_reset#new")
    end

    it "routes to #edit" do
      get("/password_reset/1/edit").should route_to("password_reset#edit", :id => "1")
    end

    it "routes to #create" do
      post("/password_reset").should route_to("password_reset#create")
    end

    it "routes to #update" do
      put("/password_reset/1").should route_to("password_reset#update", :id => "1")
    end

    it "routes to #begin_process" do
      get("/password_reset/begin_process").should route_to("password_reset#begin_process")
    end

    it "routes to #finish_registration " do
      get("/finish_registration/1").should route_to("password_reset#finish_registration", :id => "1")
    end


  end
end
