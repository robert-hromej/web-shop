require "spec_helper"

describe ProductsController do
  it "routes to #new" do
    get("/products/new").should route_to("products#new")
  end

  it "routes to #create" do
    post("/products").should route_to("products#create")
  end

  it "routes to #dynamic_categories" do
    get("/products/dynamic_categories.js").should route_to("products#dynamic_categories", "format" => "js")
  end

  it "routes to #edit" do
    get("/products/1/edit").should route_to("products#edit", :id => "1")
  end
end
