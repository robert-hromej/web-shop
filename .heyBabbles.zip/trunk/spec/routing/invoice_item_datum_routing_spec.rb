require "spec_helper"

describe InvoiceItemDatumController do
  describe "routing" do
    it "should route to" do
      get("/invoice_item_datum/1").should route_to("invoice_item_datum#show", :id => "1")
      end

    it "should route to" do
      put("/invoice_item_datum/1").should route_to("invoice_item_datum#update", :id => "1")
      end

    it "should route to" do
      get("/invoice_item_datum/1/edit").should route_to("invoice_item_datum#edit", :id => "1")
    end
  end
end
