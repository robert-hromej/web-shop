require "spec_helper"

describe ProductRecommendationsController do

  describe "routing" do
    it "routes to show" do
      get('/product_recommendations/show/2').should route_to(:controller => "product_recommendations", :action => "show", :id => "2")
    end
  end

end
