require "spec_helper"

describe ReportingController do

  describe "routing" do
    describe "get" do
      it "routes to #used_products" do
        get("/reporting/used_products").should be_routable("reporting#used_products")
      end

      it "routes to #for_sale_products" do
        get("/reporting/for_sale_products").should be_routable("reporting#for_sale_products")
      end

      it "routes to #product_history" do
        get("/reporting/product_history").should be_routable("reporting#product_history")
      end
    end

    describe "post" do
      it "routes to #renew_products" do
        post("/reporting/renew_products").should be_routable("reporting#renew_products")
      end
    end
  end

  describe "not routing" do
    describe "get" do
      it "routes to #renew_products" do
        get("/renew_products").should_not be_routable("reporting#renew_products")
      end
    end

    describe "post" do
      it "routes to #for_sale_products" do
        post("/for_sale_products").should_not be_routable("reporting#for_sale_products")
      end
    end
  end
end