require 'spec_helper'

describe ReportingController do
  render_views


  before(:all) do
    @populate = SeedDB.new("test")
    @populate.seed_items(5, :email => 'test@user.com', :password => '123456')
  end
  after(:all) { clean_db }

  context "deny access if " do
    it_behaves_like "signed in user is not seller", "get :sold_products"
    it_behaves_like "signed in user is seller without store", "get :sold_products"
  end

  describe "Sold Items Reporting" do
    context "Success" do
      before { test_sign_in(@populate.user) }

      it "GET sold_products" do
        get :sold_products
        response.should be_success
      end

      it "GET Product_history" do
        get :product_history
        response.should be_success
      end

      describe "#sold_products" do
        before(:each) do
          @inv_dat = mock_model(ReceiverOption).as_null_object
          controller.stub(:params => {:filter => 1, :page => 1})
        end

        it "should receive datum_for_seller with right parameters and return right values" do
          @inv_dat.should_recive(:datum_for_seller).with(1, controller.params[:filter]).and_return(Array)
        end

      end

    end

  end

  describe "GET for_sale_products" do
    before { pending "Bodya" }

    before(:all) { populate }
    after(:all) { clean_db }

    it "should successfully render action" do
      test_sign_in @populate.user
      get :for_sale_products
      response.should be_success
    end

    describe "access control" do
      describe "non register user should deny access" do
        it "GET 'for sale_products'" do
          pending "bodya"
          @user = Factory(:user)
          get :for_sale_products
          response.should redirect_to(signin_path)
        end
      end

      describe "non seller user should redirect to user path" do
        it "GET 'for sale_products'" do
          pending "Bodya"
          @user = Factory(:user, :registered => true)
          test_sign_in @user
          get :for_sale_products
          cookies['flash'].should eq("error-|-#{I18n.t(:seller_profile)}-|-#{I18n.t(:havent_got_seller_profile)}")
          response.should redirect_to(new_seller_path)
        end
      end

      describe "seller user has no store" do
        it "GET 'for sale_products'" do
          pending "Bodya"
          seller = Factory(:seller, :user_id => Factory(:user).id)
          test_sign_in seller.user
          seller.store.destroy
          get :for_sale_products
          cookies['flash'].should eq("error-|-#{I18n.t(:product_management)}-|-#{(I18n.t('need_store') + ("<a href='#{new_store_path}'>Create store</a>"))}")
        end
      end
    end

    describe "GET 'for sale_products'" do
      before(:all) { populate(10) }
      after(:all) { clean_db }
      before(:each) { test_sign_in @populate.user }

      context "with no params" do
        it "should return collection of products" do
          get 'for_sale_products'
          assigns(:products).should have_at_most(10).products
        end

        it "should return exactly accepted products" do
          pending
          get 'for_sale_products'
          assigns(:products).first.should be_accepted
        end
      end

      it "should find for sale products for current_seller" do
        get 'for_sale_products'
        product = assigns(:products).first
        product.seller.should eq(controller.current_user.seller_id)
      end

      context "for seller which has no products" do
        before(:each) do
          seller = Factory(:seller, :user_id => Factory(:user).id)
          test_sign_in seller.user
        end

        it "should not find for_sale one" do
          get 'for_sale_products'
          assigns(:products).should have(0).products
        end

        it "should assign a flash message" do
          get 'for_sale_products'
          cookies['flash'].should eq("notice-|-#{I18n.t("report.title")}-|-#{I18n.t("report.for_sale_products.havent")}")
        end
      end

      describe "renew_products" do
        pending "Bodya"
        it "use 'params[:renew]'"
        it "'params[:renew]' check is 'nil'"
        it "update 'expiration_date' field"
        it "collection in field 'id'"
        it "collection in field 'id' with 'params[:renew]'"
        it "later update 'params[:renew]' is nil"
        it "redirect back or root"
      end
    end
  end
  describe "GET used_products" do
    before { pending "Bodya" }

    it "should render successfully" do
      populate(20)
      test_sign_in @populate.user
      get :used_products
      response.should be_success
    end


    describe "access control" do
      describe "non register user should deny access" do
        it "GET 'used_products'" do
          pending "Bodya"
          @user = Factory(:user)
          get :used_products
          response.should redirect_to(signin_path)
        end
      end

      describe "non seller user should redirect to user path" do
        it "GET 'used_products'" do
          pending "Bodya"
          @user = Factory(:user, :registered => true)
          test_sign_in @user
          get :used_products
          cookies['flash'].should eq("error-|-#{I18n.t(:seller_profile)}-|-#{I18n.t(:havent_got_seller_profile)}")
          response.should redirect_to(new_seller_path)
        end
      end

      describe "seller user has no store" do
        it "GET 'used_products'" do
          pending "Bodya"
          seller = Factory(:seller, :user_id => Factory(:user).id)
          test_sign_in seller.user
          seller.store.destroy
          get :used_products
          cookies['flash'].should eq("error-|-#{I18n.t(:product_management)}-|-#{(I18n.t('need_store') + ("<a href='#{new_store_path}'>Create store</a>"))}")
        end
      end
    end

    describe "GET 'used_products'" do
      before(:all) { populate(20) }
      after(:all) { clean_db }
      before(:each) { test_sign_in @populate.user }

      context "with no params" do
        it "should return collection of products" do
          get 'used_products'
          assigns(:products).should have_at_most(10).products
        end

        it "should return exactly used one" do
          pending
          get 'used_products'
          assigns(:products).first.should_not be_new
        end
      end

      context "with filter param 'ALL'" do
        it "should return collection of products" do
          get 'used_products', :filter => 2
          assigns(:products).should have_at_most(10).products
        end
      end

      context "with filter param 'Approved'" do
        it "should return exactly approved one" do
          get 'used_products', :filter => 1
          assigns(:products).first.accepted.should == 1
        end
      end

      context "with filter param 'Rejected'" do
        it "should return exactly rejected one" do
          get 'used_products', :filter => 0
          assigns(:products).first.accepted.should == 0
        end
      end

      context "with filter param 'In Progress'" do
        it "should return exactly in progress one" do
          get 'used_products', :filter => ""
          assigns(:products).first.accepted.should be_nil
        end
      end

      it "should find used products for current_seller" do
        get 'used_products'
        product = assigns(:products).first
        product.seller.should eq(controller.current_user.seller_id)
      end

      context "for seller which has no products" do
        before(:each) do
          seller = Factory(:seller, :user_id => Factory(:user).id)
          test_sign_in seller.user
        end

        it "should not find used one" do
          get 'used_products'
          assigns(:products).should have(0).products
        end

        it "should assign a flash message" do
          get 'used_products'
          cookies['flash'].should eq("notice-|-#{I18n.t("report.title")}-|-#{I18n.t("report.used_products.havent")}")
        end
      end

      it "should change filter"
      it "should next page current filter is used"

    end
  end
end
