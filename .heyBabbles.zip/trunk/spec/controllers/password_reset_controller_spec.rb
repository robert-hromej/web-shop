require 'spec_helper'


describe PasswordResetController do

  def attributes(user)
    @attr = {:id => user.reset_password_token, :user => {:password => "65e4321", :password_confirmation => "65e4321"}}
  end

  def time
    Timecop.return
    Time.now - 10.minutes
  end

  render_views

  before(:all) { Timecop.return }

  let(:user) { Factory(:user) }


  describe "GET new" do

    it "should be success" do
      get :new
      response.should be_success
    end

  end

  describe "GET 'edit'" do

    describe "success" do
      it "should be success" do
        user = Factory(:user)
        get "edit", :id => user.reset_password_token
        response.should be_success
      end
    end

  end

  describe "POST create" do

    before { @attr = {:email => user.email} }

    describe "success" do

      it "should send email" do
        lambda { post :create, @attr }.should change(ActionMailer::Base.deliveries, :size).by(1)
      end

      it "should redirect to root" do
        post :create, @attr
        response.should redirect_to root_path()
      end

      it "should have a flash notice" do
        post :create, @attr
        cookies['flash'].should match(build_regexp "notice-|-#{I18n.t(:email_service_process)}-|-#{I18n.t(:email_reset_sent)}")
      end

    end
    describe "failure" do

      it "should redirect to root" do
        post :create, :email => {}
        response.should render_template("new")
      end

      it "should have flash error" do
        post :create, :email => {}
        cookies['flash'].should match(build_regexp "error-|-#{I18n.t(:email_service_process)}-|-#{I18n.t(:no_email)}")
      end

    end
  end

  describe "PUT update" do

    describe "success" do

      before do
        freeze_time(Time.now - 100.minutes)
        attributes user
      end

      it "should should be redirect to 'signin'" do
        put :update, @attr
        response.should redirect_to signin_path
      end

      it "should have flash 'success'" do
        put :update, @attr
        cookies['flash'].should match(build_regexp "success-|-#{I18n.t(:reset_password_process)}-|-#{I18n.t(:password_reseted)}")
      end

      it "should change password" do
        password = user.encrypted_password
        put :update, @attr
        controller.user.encrypted_password.should_not eq(password)
      end

    end

    describe "failure" do

      describe "user is missed" do

        it "user be redirect to root" do
          put :update, {:id => "789"}
          response.should redirect_to root_path()
        end

        it "should have a flash message" do
          put :update, {:id => "789"}
          cookies['flash'].should match(build_regexp "error-|-#{I18n.t(:reset_password_process)}-|-#{I18n.t(:record_not_found)}")
        end

      end

      describe "link has expired" do

        before { freeze_time(Time.now + 1.day) }

        it "user should be redirect to root" do
          put :update, attributes(user)
          response.should redirect_to new_password_reset_path
        end

        it "should have alert flash" do
          put :update, attributes(user)
          cookies['flash'].should match(build_regexp "alert-|-#{I18n.t(:reset_password_process)}-|-#{I18n.t(:password_expired)}")
        end

      end

      describe "user entered invalid password" do
        before { freeze_time(Time.now - 100.day) }

        it "should render new" do
          put :update, {:id => user.reset_password_token, :user => {:password => "693258", :password_confirmation => "654321"}}
          response.should render_template('edit')
        end

      end
    end
  end

  describe "finish_registration" do

    describe "success" do
      before do
        @attr = {:id => user.id, :token => user.reset_password_token}
        user.update_attributes!(:reset => 0, :registered => false)
        user.reload
      end

      it "should toggle attribute" do
        get "finish_registration", @attr
        assigns(:user).registered.should eq(true)
      end

      it "should sign in user" do
        get "finish_registration", @attr
        controller.should be_signed_in
      end

      it "should redirect to 'user page'" do
        get "finish_registration", @attr
        response.should redirect_to user_path(user)
      end

      it "should assign flash" do
        get "finish_registration", @attr
        cookies['flash'].should match(build_regexp "success-|-#{I18n.t(:register_process)}-|-#{I18n.t(:welcome)}")
      end
    end

    describe "failure" do
      describe "token has expired" do

        it "should render page if link expired" do
          user.update_attributes!(:reset_password_sent_at => time, :registered => true, :reset => 0)
          get "finish_registration", :id => user.id
          response.should be_success
        end

        it "should render page if user hasn`t finish registration" do
          user.update_attributes!(:registered => true, :reset => 0)
          get "finish_registration", :id => user.id
          response.should be_success
        end

      end
      describe "user not found" do

        it "should redirect" do
          get "finish_registration", :id => "90000"
          response.should redirect_to root_path()
        end

        it "should assign a flash" do
          get "finish_registration", :id => "90000"
          cookies['flash'].should match(build_regexp "alert-|-#{I18n.t(:register_process)}-|-#{I18n.t(:record_not_found)}")
        end

      end
    end
  end

  describe "GET begin_process" do
    before { test_sign_in user }

    it "should sign out" do
      get 'begin_process'
      controller.should_not be_signed_in
    end

    it "should redirect to reset form" do
      get 'begin_process'
      response.should redirect_to new_password_reset_path
    end

  end

  describe "deny access" do
    before do
      test_sign_in user
      attributes(user)[:user].merge!(:reset => 1)
    end

    it "should redirect to profile for 'finish_registering'" do
      get "finish_registration", :id => user.id
      response.should redirect_to user_path(user)
    end
  end

end