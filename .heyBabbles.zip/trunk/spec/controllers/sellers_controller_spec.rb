require 'spec_helper'
include SharedExample

describe SellersController do

  render_views

  def valid_attributes
    {
        :seller_attributes => {"last_name"=>"last_name1", "first_name"=>"first_name1"}
    }
  end

  def invalid_attributes
    {
        :seller_attributes => {"last_name"=>nil, "first_name"=>nil},
        :address_attributes => {"country_id"=>nil, "state_id"=>nil, "street" => nil, "phone"=>nil, "city"=>nil, "zip"=>nil}
    }
  end

  let(:user) { create(:user) }

  shared_examples_for "seller" do |action|
    before(:each) do
      user = stub_model(User, :seller? => true)
      test_sign_in(user)
    end

    it "should redirect" do
      eval("#{action}")
      response.should be_redirect
    end
    #it "should assign error message" do
    #  pending "No message in functionality"
    #  eval("#{action}")
    #  cookies['flash'].should match(build_regexp "error-|-#{I18n.t(:register_process)}-|-#{I18n.t(:already_seller)}")
    #end
  end

  describe "GET new" do
    before(:each) do
      user.seller.try(:destroy)
      test_sign_in(user.reload)
    end

    context "user is not seller" do
      it "assigns a new seller as @seller" do
        get :new
        assigns(:seller).should be_a_new(Seller)
      end

      it "assigns a user" do
        get :new
        assigns(:user).should eq(user)
      end
    end

    context "will deny access" do
      it_behaves_like "not signed in one", "get :new"
      it_behaves_like "seller", "get :new"
    end
  end

  describe "POST create" do
    before(:each) do
      user.reload
      test_sign_in(user)
    end

    describe "with valid params" do
      it "creates a new Seller" do
        expect {
          post :create, :user => valid_attributes
        }.to change(Seller, :count).by(1)
      end

      it "redirects to the created seller" do
        post :create, :user => valid_attributes
        response.should redirect_to(user_path(controller.current_user, :tab=>'seller'))
      end

      it "should assign a flash" do
        post :create, :user => valid_attributes
        cookies['flash'].should match(build_regexp "success-|-#{I18n.t(:register_process)}-|-#{I18n.t(:seller_registered)}")
      end
    end

    describe "with invalid params" do
      it "redirects to the seller new" do
        post :create, :user => invalid_attributes
        response.should redirect_to(new_seller_path)
      end

      it "set the cookie message" do
        post :create, :user => invalid_attributes
        cookies['flash'].should match(/error/)
      end
    end

    context "will deny access" do
      it_behaves_like "not signed in one", "get :new"
      it_behaves_like "seller", "post :create, :user => {}"
    end
  end
end
