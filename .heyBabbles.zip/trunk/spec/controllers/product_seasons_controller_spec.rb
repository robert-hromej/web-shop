require 'spec_helper'

describe ProductSeasonsController do

  describe "GET 'create'" do
    it "should be successful" do
      pending "Robert"
      get 'create'
      response.should be_success
    end
  end

  describe "GET 'destroy'" do
    it "should be successful" do
      pending "Robert"
      get 'destroy'
      response.should be_success
    end
  end

end
