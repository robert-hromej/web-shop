require 'spec_helper'

describe UsersController do

  render_views

  let(:user) { Factory(:default_user, :registered => true) }

  describe "GET 'new'" do
    it "should be success" do
      get :new
      response.should be_success
    end

    it "should assign address" do
      get :new
      assigns(:user).address.should_not be_nil
    end
  end

  describe "GET 'create' register user" do
    before(:each) do
      @attr = {:user => {:id => user.id, :password => "123456", :password_confirmation => "123456", :email => "john@mail.com",
                         :address_attributes => Factory.attributes_for(:address, :user_id => user.id)}}
    end

    describe "success" do
      it "should be success with address attributes" do
        post :create, @attr
        response.should redirect_to root_path
      end

      it "should be success with no address attributes" do
        @attr[:user][:address_attributes].merge!(:state_id => "", :country_id => "", :city => "")
        post :create, @attr
        response.should redirect_to root_path
      end

      it "should have a flash message" do
        post :create, @attr
        cookies['flash'].should match(build_regexp "notice-|-#{I18n.t(:register_process)}-|-#{I18n.t(:confirm_send)}")
      end

      it "should create a user" do
        expect {
          post :create, @attr
        }.should change(User, :count).by(1)
      end

      it "should create address" do
        expect {
          post :create, @attr
        }.should change(Address, :count).by(1)
      end

      it "should send an email" do
        lambda { post :create, @attr }.should change(ActionMailer::Base.deliveries, :size).by(1)
      end
    end

    describe "failure" do
      before(:each) do
        @attr[:user][:password] = ""
      end

      it "should render template 'new' for wrong password" do
        post :create, @attr
        response.should render_template('new')
      end

      it "should set a flash for wrong password" do
        post :create, @attr
        cookies['flash'].should match(build_regexp "alert-|-#{I18n.t(:register_process)}-|-#{controller.errors_messages_for(assigns(:user))}")
      end

      it "should assign address" do
        post :create, @attr
        assigns(:user).should_not be_nil
      end
    end
  end

  describe "GET 'show'" do
    before(:each) do
      test_sign_in user
    end

    it "should be successful" do
      get :show, :id => user
      response.should be_success
    end

    it "should find the right user" do
      get :show, :id => user
      assigns(:user).should == user
    end

    describe "deny access" do
      before(:each) do
        @not_authorised = Factory(:user)
      end

      it "should reject incorrect user" do
        get :show, :id => @not_authorised
        response.should redirect_to user_path(user)
      end

      it "should reject not authenticated user" do
        test_sign_out
        get :show, :id => @not_authorised
        response.should redirect_to signin_path
      end
    end
  end

  describe "get 'resend email'" do
    describe "success" do
      before(:each) do
        user.update_attributes!(:reset => 0, :registered => false)
      end

      it "should send an email" do
        get 'resend_mail', {:id => user.id}
        lambda { UserMailer.confirm_email(user).deliver }.should change(ActionMailer::Base.deliveries, :size).by(1)
      end

      it "should set a flash message" do
        get 'resend_mail', {:id => user.id}
        cookies['flash'].should match(build_regexp "notice-|-#{I18n.t(:register_process)}-|-#{I18n.t(:confirm_send)}")
      end
    end

    describe "failure for unreal user" do
      it "should have a flash message" do
        get 'resend_mail', {:id => "90000"}
        cookies['flash'].should match(build_regexp "notice-|-#{I18n.t(:register_process)}-|-#{I18n.t(:record_not_found)}")
      end
    end

    describe "failure for registered user" do
      it "should have a flash message" do
        get 'resend_mail', {:id => user.id}
        cookies['flash'].should match(build_regexp "alert-|-#{I18n.t(:register_process)}-|-#{I18n.t(:already_registered)}")
      end
    end

    it "should redirect to root" do
      get 'resend_mail', {:id => user.id}
      response.should redirect_to root_path
    end
  end
end
