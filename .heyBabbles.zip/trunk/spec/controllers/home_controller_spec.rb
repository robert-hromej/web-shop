require 'spec_helper'


describe HomeController do
  render_views

  after(:all) do
    CACHE.delete("expiration")
    CACHE.delete("counter")
    CACHE.delete("expiration")
    CACHE.delete("product_ids")
    clean_db
    @populate = nil
  end

  describe "GET 'index'" do

    before { get 'index' }

    context "no data for populate" do

      before(:all) { clean_db }
      it { assigns(:products).should be_empty }
      it { assigns(:last_products).should be_empty }
      it { assigns(:seller).should be_nil }

    end

    it { response.should be_success }
  end

  context "has populated data" do

    before(:all) do
      CACHE.set("expiration", (Time.now - 10.days)); freeze_time(Time.now)
      populate(10, :factory_label => :product_with_impressions)
      @populate.featured_seller
      @impressions = Product.joins(:product_counters).minimum(:points)
      #@populate.product.product_counters.each do |counter|
      #  @impressions = counter.points if counter.service_type == Service::TYPE[:home]
      #end
    end
    describe "GET 'index'" do
      before { get 'index' }

      it { assigns(:products).should_not be_empty }
      it { assigns(:last_products).should_not be_empty }
      it { assigns(:seller).should_not be_blank }

      it "should create CACHE for 'counter'" do
        CACHE.get("counter")[:limit].should_not be_nil
      end

      it "should create CACHE for 'cache expiration'" do
        CACHE.get("expiration").should be > Time.now
      end
      it "should create CACHE 'products ids'" do
        value = assigns(:products).flatten.collect(&:id)
        CACHE.get("product_ids").should_not include value
      end
    end

    describe "XHR 'increment'" do

      before(:each) do
        Timecop.freeze(2018, 10, 5)
      end

      after(:each) { Timecop.return }

      it "should decrement CACHE 'counter'" do
        expect { xhr :post, 'increment' }.to change { CACHE.get('counter')[:count].to_i }.by(1)
      end

      it "should decrement counters" do
        pending
        expect { xhr :post, 'increment' }.should change(ProductCounter, :count).by(-1)
      end

      it "should render template" do
        xhr :post, 'increment'
        response.should render_template("layouts/_links")
      end

      it "invalidates page cache"
      it "runs screen"
    end
  end

end
