require 'spec_helper'
include SharedExample

describe ProductsController do
  render_views


  before do
    seller = Factory(:seller, :user_id => Factory(:user).id)
    test_sign_in(seller.user)
  end

  context "deny access if user" do
    it_behaves_like "not signed in one", "get :new"
    it_behaves_like "not signed in one", "post :create"
  end

  describe "'index' action" do
    context "receives valid params" do
      pending "Fedia"
    end
    context "receives invalid params" do
      pending "Fedia"
    end
  end

  describe "'create' action" do
    context "receives valid params" do
      pending "Robert"
    end
    context "receives invalid params" do
      pending "Robert"
    end
  end
  describe "'update' action should update" do
    context "receives valid params" do
      pending "Robert"
    end
    context "receives invalid params" do
      pending "Robert"
    end
  end

  describe "'edit' action" do
    context "receives valid params" do
      pending "Robert"
    end
    context "receives invalid params" do
      pending "Robert"
    end
  end

  describe "'new' action" do
    context "receives valid params" do
      pending "Robert"
    end
    context "receives invalid params" do
      pending "Robert"
    end
  end

  describe "'paid' action" do
    context "receives valid params" do
      pending "Robert"
    end
    context "receives invalid params" do
      pending "Robert"
    end
  end

  describe "'advanced' action" do
    context "receives valid params" do
      pending "Robert"
    end
    context "receives invalid params" do
      pending "Robert"
    end
  end

  describe "'show' action" do
    render_views false
    let(:product) { stub_model(Product, :accepted => true, :expiration_date => 1.month.from_now, :id => 1, :name => "some product") }

    before do
      Product.stub(:find_by_id).with(1).and_return(product)
    end

    it "get should be successful" do
      get :show, :id => product.id
      response.should be_successful
    end

    it "should find a right product" do
      get :show, :id => 1
      assigns(:product).should eq(product)
    end

    it "should return a user (product -> seller -> user)" do
      user = stub_model(User)
      seller = stub_model(Seller, :user => user)
      product.should_receive(:seller).twice.and_return(seller)
      get :show, :id => product.id
      assigns(:seller).should == user
    end

    it "should return other products" do
      pending "there i have trable with Product.where mocking. Laslo"
      seller = stub_model(Seller, :id => 704)
      product.should_receive(:seller).twice.and_return(seller)
      product1 = stub_model(Product, :seller_id => seller.id)
      product2 = stub_model(Product, :seller_id => seller.id)
      # there
      Product.stub_chain(:where, :limit).with
      get :show, :id => product.id
      assigns(:other_products).should == [product1, product2]
    end

    it "should return <=3 other products" do
      pending "there i have trable with Product.where mocking. Laslo"
      seller = Factory(:seller)
      @product.update_attribute(:seller_id, seller.id)
      seller_products = []
      20.times do
        product = Factory(:independent_product)
        product.update_attribute(:seller_id, seller.id)
        seller_products << product
      end
      get :show, :id => @product.id
      assigns(:other_products).length.should == 3
    end
  end

end
