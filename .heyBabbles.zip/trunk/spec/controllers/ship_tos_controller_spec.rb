require 'spec_helper'

describe ShipTosController do

  render_views

  before(:each) do
    pending "Robert"
    @country = Factory(:ship_to)
    @product = Factory(:product)
    @ship_to = Factory(:shipping_to, :country => @country, :product => @product)

    @attributes_for_create = {
        :country_id => @country.id,
        :product_id => @product.id
    }

    @attributes_for_update = {
        :id => @ship_to.id,
        :ship_to => {
            :cost => 132435,
            :product_limit => 32423,
            :additional_cost => 324
        }
    }
  end

  describe "GET 'create'" do

    it "should be successful" do
      expect do
        xhr :post, :create, :ship_to => @attributes_for_create
      end.should change(ShipTo, :count).by(1)
      #response.should render_template(:create)
    end

    {
        :country_id => ["", nil, "abc"],
        :product_id => ["", nil, "abc"]
    }.each do |field, values|
      values.each do |value|
        it "should not be successful if '#{field}' with value '#{value.inspect}'" do
          expect do
            xhr :post, :create, :ship_to => @attributes_for_create.merge(field => value)
            render_template(:create)
          end.should change(ShipTo, :count).by(1)
        end
      end
    end

  end

  describe "GET 'update'" do

    it "should be successful" do
      xhr :put, :update, @attributes_for_update
      render_template(:update)
    end

    it "should not be successful"

  end

  describe "GET 'destroy'" do

    it "should be successful" do
      xhr :delete, :destroy, :id => @ship_to.id
      render_template(:destroy)
    end

    it "should not be successful"

  end

end
