require 'spec_helper'

describe ApplicationImagesController do

  def preparations(params = {})
    controller.stub(:params => params)
    @params = controller.params
    test_sign_in Factory(:user)
    @image = stub_model(ApplicationImage, :product => stub_model(Product))
  end

  def find_image_by_id(params = {})
    preparations params

    ApplicationImage.should_receive(:find_by_id).with(@params[:id]).
        and_return(@image.as_null_object)
  end

  shared_examples_for "sandwich code which" do |type, action|
    it "should assign 'alert' for 'undefined' @image" do
      @image.stub(:nil? => true)

      xhr type, action, controller.params
      cookies['flash'].should match(build_regexp "alert-|-#{I18n.t('product_management')}-|-#{I18n.t('image.no_image')}")
    end
  end

  shared_examples_for "assigner for @product" do |type, action|
    it "should assign 'product'" do
      xhr type, action, controller.params
      assigns(:product).should eq assigns(:image).product
    end
  end

  shared_examples_for "assigner for @image" do |type, action|
    it "should assign 'image'" do
      xhr type, action, controller.params
      assigns(:image).should eq @image
    end
  end

  describe "XHR 'create'" do
    context "for signed in user" do

      before { preparations :application_image => {} }

      it "should assign new instance" do
        xhr :post, :create, @params
        assigns(:image).should be_a_new(ApplicationImage), assigns(:image)
      end

      it "should be 'success' for successful SAVE" do
        @image.stub(:valid? => true)
        ApplicationImage.should_receive(:new).with(@params[:application_image]).
            and_return(@image)

        xhr :post, :create, @params
        cookies['flash'].should match(build_regexp "success-|-#{I18n.t('product_management')}-|-#{I18n.t('image.created')}")
      end

      it "should be 'alert' for unsuccessful SAVE" do
        @image.stub(:valid? => false)
        ApplicationImage.stub(:new => @image)

        xhr :post, :create, @params
        cookies['flash'].should match(build_regexp "alert-|-#{I18n.t('product_management')}")
      end

      it_behaves_like "assigner for @product", :post, :create

    end

  end


  describe "XHR 'update'" do

    before do
      find_image_by_id(:id => 1, :application_image => {:description => {}})

      @image.stub(:update_attribute).
          with(:description, @params[:application_image][:description])
    end

    it "should receive params[:application_image][:description]" do
      @image.should_receive(:update_attribute).
          with(:description, @params[:application_image][:description])

      xhr :put, :update, @params
    end

    it "should be 'success' for successful UPDATE" do
      @image.stub(:update_attribute => true)

      xhr :put, :update, @params
      cookies['flash'].should match(build_regexp "success-|-#{I18n.t('product_management')}-|-#{I18n.t('image.updated')}")
    end

    it "should be 'alert' for unsuccessful UPDATE" do
      @image.stub(:update_attribute => false)

      xhr :put, :update, @params
      cookies['flash'].should match(build_regexp "alert-|-#{I18n.t('product_management')}")
    end

    it_behaves_like "assigner for @image", :put, :update
    it_behaves_like "sandwich code which", :put, :update, @params
  end

  describe "XHR 'destroy'" do

    before { find_image_by_id(:id => 1) }

    it "should be 'success' for successful DESTROY" do
      @image.should_receive(:destroy).and_return(true)

      xhr :delete, :destroy, @params
      cookies['flash'].should match(build_regexp "success-|-#{I18n.t('product_management')}-|-#{I18n.t('image.deleted')}")
    end

    it "should be 'alert' for unsuccessful DESTROY" do
      @image.should_receive(:destroy).and_return(false)

      xhr :delete, :destroy, @params
      cookies['flash'].should match(build_regexp "alert-|-#{I18n.t('product_management')}")
    end

    it_behaves_like "assigner for @image", :delete, :destroy
    it_behaves_like "assigner for @product", :delete, :destroy
    it_behaves_like "sandwich code which", :delete, :destroy, @params
  end

  describe "XHR 'set_main'" do

    before { find_image_by_id(:id => 1) }

    it "should assign @image" do
      @image.should_receive(:set_as_the_main)

      xhr :post, :set_main, @params
      assigns(:image).should eq @image
    end

    it_behaves_like "assigner for @image", :delete, :destroy
    it_behaves_like "assigner for @product", :delete, :destroy
    it_behaves_like "sandwich code which", :post, :set_main, @params
  end
end
