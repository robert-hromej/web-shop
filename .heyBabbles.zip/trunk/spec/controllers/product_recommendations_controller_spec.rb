require 'spec_helper'

describe ProductRecommendationsController do
  render_views false

  describe "GET 'show'" do

    before(:each) do
      @product = stub.as_null_object
      Product.stub(:find_by_id).with(2).and_return(@product)
    end

    it "should be successful" do
      get 'show', :id => 2
      response.should be_success
    end

    it "should get correct recommendations object" do
      @product.should_receive(:recommendations).and_return([])
      get "show", :id => 2
    end

    it "should not fail without product" do
      Product.stub(:find_by_id => nil)
      get "show", :id => 2
      response.should be_redirect
    end

  end

end
