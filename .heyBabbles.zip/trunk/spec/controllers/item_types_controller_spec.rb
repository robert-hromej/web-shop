require 'spec_helper'

describe ItemTypesController do

  describe "GET 'create'" do
    it "should be successful" do
      pending "Robert"
      get 'create'
      response.should be_success
    end
  end

end
