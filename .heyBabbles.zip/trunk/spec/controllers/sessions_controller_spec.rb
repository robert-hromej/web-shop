require 'spec_helper'
include SharedExample


describe SessionsController do
  def sign_in_attr
    @attr = {:session => {:email => @user.email, :password => @user.password}}
  end

  render_views
  # Works if FactoryGirl.create(:user) defined in before block
  #


  describe "GET 'new'" do
    it "should be successful" do
      get :new
      response.should be_success
    end
  end

  describe "success" do
    before(:each) do
      @user = FactoryGirl.create(:user, :registered => true)
    end

    it "should SIGN IN user" do
      post :create, sign_in_attr
      controller.current_user.should == @user
      controller.should be_signed_in
    end

    it "should redirect on users page" do
      post :create, sign_in_attr
      response.should redirect_to(user_path(@user))
    end

    it "should redirect to remembered path" do
      controller.session[:return_to] = "/test/path"
      post :create, sign_in_attr
      response.should redirect_to("/test/path")
    end

    describe 'DELETE' do
      before(:each) do
        test_sign_in(@user)
      end
      it "should empty 'session'" do
        delete :destroy
        controller.should_not be_signed_in
        response.should redirect_to root_path
      end
      it "should have a flash success" do
        delete :destroy
        cookies['flash'].should match(build_regexp "success-|-#{I18n.t(:authenticate)}-|-#{I18n.t(:signed_out)}")
      end
    end
  end

  describe "failure" do
    before(:each) do
      @user = FactoryGirl.create(:user)
      @attr = {}
    end

    it "should not SIGN IN user" do
      post :create, :session => @attr
      controller.current_user.should be_nil
      controller.should_not be_signed_in
    end

    it "should block user" do
      post :create, sign_in_attr
      controller.should_not be_signed_in
    end

    it "should set flash" do
      expression = Regexp.new("#{I18n.t(:not_finished)}")
      post :create, sign_in_attr
      cookies['flash'].should match(expression)
    end

    it "should redirect to finish registration" do
      post :create, sign_in_attr
      response.should redirect_to root_path
    end

    describe "deny access" do
      before(:each) do
        test_sign_in(@user)
      end

      it "should redirect to profile for 'NEW'" do
        get :new
        response.should redirect_to user_path(@user)
      end

      it "should redirect to profile for 'CREATE'" do
        post :create, :session => @attr
        response.should redirect_to user_path(@user)
      end

      it "should redirect to profile for 'facebook_connect'" do
        get :facebook_connect
        response.should redirect_to user_path(@user)
      end
    end
  end

  describe "facebook connect SUCCESS" do
    before(:each) do
      test_sign_out
      Facebooker2.app_id = "12345"
      Facebooker2.secret = "42ca6de519d53f6e0420247a4d108d90"
      controller.stub!(:params).and_return({})
      controller.stub!(:cookies).and_return("fbs_12345"=>"\"access_token=114355055262088|57f0206b01ad48bf84ac86f1-12451752|63WyZjRQbzowpN8ibdIfrsg80OA.&expires=0&secret=1e3375dcc4527e7ead0f82c095421690&session_key=57f0206b01ad48bf84ac86f1-12451752&sig=4337fcdee4cc68bb70ec495c0eebf89c&uid=12451752\"")
      @facebook_email = "facebook@email.com"
      @facebook_uid = 12451752
    end


    describe "system has facebook credentials" do
      describe "system has facebook_uid" do
        before(:each) do
          @user = FactoryGirl.create(:user)
          user = stub("users", :client= => nil, :fetch => {})
          controller.fb_sign_in_user_and_client(user, Mogli::Client.new)
          controller.current_facebook_user.stub(:email => @user.facebook_email, :id => @user.facebook_uid)
        end

        it "should have active facebook users" do
          get :facebook_connect
          controller.current_facebook_user.should_not be_nil
        end

        it "should be signed in" do
          get :facebook_connect
          controller.should be_signed_in
        end

        it "should be assert users" do
          get :facebook_connect
          assigns(:user).should == @user
        end

        it "should redirect to users profile" do
          get :facebook_connect
          response.should redirect_to @user
        end
      end
      describe "system has facebook_email but has no facebook_uid" do
        before(:each) do
          FactoryGirl.create(:user, :facebook_uid => "")
          user = stub("user", :client= => nil, :fetch => {})
          controller.fb_sign_in_user_and_client(user, Mogli::Client.new)
          controller.current_facebook_user.stub(:email => @facebook_email, :id => @facebook_uid)
        end

        it "should have active facebook users" do
          get :facebook_connect
          controller.current_facebook_user.fetch.should_not be_nil
        end

        it "should sign in users" do
          get :facebook_connect
          controller.should be_signed_in
        end

        it "should update facebook_uid" do
          get :facebook_connect
          controller.current_user.facebook_uid.should == 12451752
        end
      end
    end

    describe "system has no facebook credentials" do
      before(:each) do
        FactoryGirl.create(:user, :facebook_uid => "", :facebook_email => "")
        user = stub("users", :client= => nil, :fetch => {})
        controller.fb_sign_in_user_and_client(user, Mogli::Client.new)
        controller.current_facebook_user.stub(:email => @facebook_email, :id => @facebook_uid)
      end

      it "should create new users instance" do
        expect { get :facebook_connect }.should change(User, :count).by(1)
      end

      it "should create new address instance" do
        expect { get :facebook_connect }.should change(Address, :count).by(1)
      end

      it "should have facebook credentials" do
        get :facebook_connect
        controller.current_user.facebook_email.should == @facebook_email
        controller.current_user.facebook_uid.should == @facebook_uid
      end

      it "should sign in users" do
        get :facebook_connect
        controller.should be_signed_in
      end

      it "should redirect to profile" do
        get :facebook_connect
        response.should redirect_to user_path(controller.current_user)
      end
    end

    describe "sign out process" do
      it "should remove facebook cookies" do
        #pending("Probaly we don`t need this")
        user = stub("users", :client= => nil, :fetch => {})
        controller.fb_sign_in_user_and_client(user, Mogli::Client.new)
        get :destroy
        controller.fb_cookie.should be_nil
      end
    end

  end

  describe "facebook connect FAILURE" do
    it "should redirect away" do
      get :facebook_connect
      response.should be_redirect
    end
  end

  describe "POST 'update_password'" do
    before(:each) do
      @user = Factory(:user)
      test_sign_in(@user)
    end

    context "include valid params" do
      before(:each) do
        # Simulate user with no password - facebook user
        @user = User.new("email" => "a@a.com")
        @user.save(:validate => false)
        test_sign_in(@user)
        @attr = {:password => "123456", :password_confirmation => "123456"}
      end

      it "should update 'users' password" do
        pass = @user.encrypted_password
        post 'update_password', :user => @attr
        pass.should_not eq(controller.current_user.encrypted_password)
      end

      it "should 'sign in' user" do
        post 'update_password', :user => @attr
        controller.current_user.should_not be_nil
      end

      it "should assign flash" do
        post 'update_password', :user => @attr
        cookies['flash'].should match(build_regexp "success-|-#{I18n.t(:my_profile)}-|-#{I18n.t(:password_updated)}")
      end

      it "should redirect to profile page" do
        post 'update_password', :user => @attr
        response.should redirect_to(user_path(@user))
      end

      context "with 'previous_password' parameter" do
        before(:each) do
          @attr.merge!(:previous_password => @user.password)
        end
        it "should redirect to profile if wrong previous pass" do
          post 'update_password', :user => @attr.merge(:previous_password => {})
          response.should redirect_to(user_path(@user))
        end
        it "should change if previous pass equals" do
          pass = @user.encrypted_password
          post 'update_password', :user => @attr
          pass.should_not eq(controller.current_user.encrypted_password)
        end
      end
    end
    context "include invalid params" do

      before(:each) { @attr = {:previous_password => @user.password, :password => "", :password_confiramtion => "123456"} }

      it "should assign flash" do
        post 'update_password', :user => @attr
        cookies['flash'].should match(/confirmation/)
      end

      it "should redirect to root" do
        post 'update_password', :user => @attr
        response.should redirect_to(root_path)
      end

    end

    context "will deny access for" do
      it_behaves_like "not signed in one", "post 'update_password', :user => {}"
    end
  end
end
