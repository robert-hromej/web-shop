require 'spec_helper'

describe InvoiceItemDatumController do
  alias_it_should_behave_like_to(:it_has_behavior, 'has behavior:')

  def preparations(params = {})
    controller.stub(:params => params)
    @params = controller.params.as_null_object

    test_sign_in(Factory(:fast_seller).user)
    @invoice = stub_model(InvoiceItemData, :identifier_id => 1).as_null_object
  end

  def find_invoice_by(params = {})
    preparations params
    InvoiceItemData.should_receive(:find_by_id).with(@params[:id]).
        and_return(@invoice)
  end

  shared_examples_for "denier for strange product" do |type, action, params|

    it "should exit if RecordNotFound" do
      preparations params

      self.send(type, action, params)
      should_assign_message "alert-|-#{I18n.t(:reporting)}-|-#{I18n.t(:record_not_found)}"
      response.should redirect_to(root_path)
    end

    it "should assign @payment_info for SUCCESS" do
      find_invoice_by params

      controller.current_seller.should_receive(:has_product?).
          with(@invoice.identifier_id).and_return(true)
      self.send(type, action, params)

      assigns(:payment_info).should eq @invoice
    end

    it "should exit if seller is NOT OWNER for product" do
      find_invoice_by params

      controller.current_seller.stub(:has_product? => false)
      self.send(type, action, params)

      response.should redirect_to(root_path)
    end
  end

  describe "GET 'show'" do
    it_has_behavior "denier for strange product", :get, :show, {:id => 1}
  end

  describe "GET 'edit'" do
    it_has_behavior "denier for strange product", :get, :edit, {:id => 1}
  end

  describe "PUT 'update'" do
    def prepare_for_update(value = "ha-ha")
      params = {
          :id => 1,
          :invoice_item_data =>{:status => "s", :closed => "2"},
          :inv_it_data => {:intracking_number => {:params_value => value},
                           :date_of_sent => {:params_value => {'month' => "10",
                                                               'day' => "11",
                                                               'year' => "2012"}}}
      }
      preparations params
      controller.stub :deny_if_strange_product
    end

    before { prepare_for_update }

    it "should redirect to sold products page" do
      controller.stub :set_additional_params
      controller.should_receive(:set_additional_params).with(no_args).and_return []

      put :update, @params
      request.should redirect_to sold_products_path
    end

    it "should assign message if 'intracking_number' missed" do
      prepare_for_update []

      put :update, @params
      should_assign_message I18n.t("shipping_info.no_number")
    end

    before { @stub_invoice = InvoiceItemData.stub(:set_additional_params).with(anything, anything, anything, anything) }

    specify "#set_additional_params should assign SUCCESS message" do

      put :update, @params
      should_assign_message I18n.t("shipping_info.updated")
    end

    specify "#set_additional_params should assign FAILURE message" do
      @stub_invoice.and_raise(StandardError)
      put :update, @params
      should_assign_message I18n.t("shipping_info.no_update")
    end


  end

end


