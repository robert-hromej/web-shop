require 'spec_helper'

describe PaymentController do

end
