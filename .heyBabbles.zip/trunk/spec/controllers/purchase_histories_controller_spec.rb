require 'spec_helper'

describe PurchaseHistoriesController do

end
