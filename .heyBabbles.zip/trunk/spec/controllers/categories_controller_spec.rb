require 'spec_helper'

describe CategoriesController do

  pending "FEDYA" do

  before(:each) do
    @category_path = [categories(:babies),
                      categories(:clothes),
                      categories(:male),
                      categories(:l_size),
                      categories(:white_color)]
  end

  describe "'show' action" do
    render_views

    CATEGORIES = ["category", "subcategory", "gender", "color", "size"]

    CATEGORIES.each_with_index do |category, index|
      it "receives valid #{category}" do
        options = {}

        # generate needed params
        CATEGORIES[0...index+1].each_with_index do |param, param_index|
          options[param.to_sym] = @category_path[param_index].id
        end

        # bad, but param name for category is :id
        options[:id] = options[:category]

        # we cann't use should_not_receive because it called from products_selection
        get 'show', options

        # it's' simply to verify finally SQL :)
        final_sql = assigns(:products_selection).to_sql

        CATEGORIES.each_with_index do |param, param_index|
          if param_index < index+1
            final_sql.should include(param)
          else
            final_sql.should_not include(param)
          end
        end
      end

      it "receives invalid #{category}" do
        options = {}

        # generate needed params
        CATEGORIES[0...index].each_with_index do |param, param_index|
          options[param.to_sym] = @category_path[param_index].id
        end

        options[CATEGORIES[index].to_sym] = "sdfsd"

        # bad, but param name for category is :id
        options[:id] = options[:category]

        get 'show', options

        cookies['flash'].should eq("error-|-#{I18n.t(:product_management)}-|-#{I18n.t(:category_not_found)}-|-5000")
      end
    end

    it "uses 'new' filter" do
      get 'show', :id => @category_path[0],
          :subcategory => @category_path[1],
          :filter => "new"

      assigns(:products).each do |product|
        product.new.should == true
      end
    end


    it "uses 'used' filter" do
      get 'show', :id => @category_path[0],
          :subcategory => @category_path[1],
          :filter => "used"

      assigns(:products).each do |product|
        product.new.should == false
      end
    end

  end

  end #pending
end
