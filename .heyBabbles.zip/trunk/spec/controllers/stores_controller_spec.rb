require 'spec_helper'

describe StoresController do
  def valid_attributes
    {:name => "bla", :description => "blas", :bio => "sdadsad", :return_policy => "asadasdasdas", :logo => Rails.root.join("spec/fixtures/rails.png").open}
  end

  def invalid_attributes
    {:name => "", :description => "", :bio => "", :return_policy => "", :logo => ""}
  end

  render_views


  describe "access control" do
    describe "non register user should deny access" do
      before(:each) do
        @user = Factory(:user)
      end

      after(:each) do
        response.should redirect_to(signin_path)
      end

      it "POST 'create'" do
        post :create
      end

      it "GET 'new'" do
        get :new
      end

      it "GET 'edit'" do
        get :edit, :id => @user.id
      end

      it "PUT 'update'" do
        put :update, :id => @user.id
      end
    end

    describe "non seller user should redirect to user path" do
      before(:each) do
        @user = Factory(:user, :registered => true)
        test_sign_in @user
      end

      after(:each) do
        cookies['flash'].should match(build_regexp "error-|-#{I18n.t(:seller_profile)}-|-#{I18n.t(:havent_got_seller_profile)}")
        response.should redirect_to(new_seller_path)
      end

      it "POST 'create'" do
        post :create
      end

      it "GET 'new'" do
        get :new
      end

      it "GET 'edit'" do
        get :edit, :id => @user.id
      end

      it "PUT 'update'" do
        put :update, :id => @user.id
      end
    end
  end

  describe "GET 'new'" do
    describe "seller has no store" do
      before(:each) do
        seller = Factory(:seller, :user_id => Factory(:user).id)
        test_sign_in(seller.user)
        seller.store.destroy
        get :new
      end
      it "should assign a new store as @store" do
        assigns(:store).should be_a_new(Store)
      end
      it "should be success" do
        response.should be_success
      end
      it "should have seller_id" do
        assigns(:store).seller_id.should_not be_nil
      end
    end


    describe "seller has store" do
      before(:each) do
        seller = Factory(:seller, :user_id => Factory(:user).id)
        @store = seller.store
        test_sign_in seller.user
      end

      it "should redirect to 'edit' profile" do
        get :new
        response.should redirect_to(edit_store_path(@store))
      end
    end
  end

  describe "POST 'create'" do
    before(:each) do
      seller = Factory(:seller, :user_id => Factory(:user).id)
      test_sign_in(seller.user)
      seller.store.destroy
    end
    describe "with valid params" do
      it "creates a new Store" do
        expect {
          post :create, :store => valid_attributes
        }.to change(Store, :count).by(1)
      end

      it "should redirect to 'edit profile''" do
        post :create, :store => valid_attributes
        response.should redirect_to edit_store_path(Store.last)
      end

      it "should assign flash" do
        post :create, :store => valid_attributes
        cookies['flash'].should match(build_regexp "success-|-#{I18n.t(:store_profile)}-|-#{I18n.t(:store_created)}")
      end
      it "assigns a newly created store as @store" do
        post :create, :store => valid_attributes
        assigns(:store).should be_persisted
      end
    end

    describe "with invalid params" do
      before(:each) do
        @store = Store.any_instance.stub(:save).and_return(false)
      end

      it "assigns a newly created but unsaved store as @store" do
        post :create, :store => {}
        assigns(:store).should be_a_new(Store)
      end

      it "re-renders the 'new' template" do
        # Trigger the behavior that occurs when invalid params are submitted
        post :create, :store => {}
        response.should render_template("new")
      end

      it "assigns flash" do
        post :create, :store => {}
        request.flash.should_not be_nil
      end
    end
  end

  describe "GET edit" do
    before(:each) do
      @seller = Factory(:seller, :user_id => Factory(:user).id)
      test_sign_in(@seller.user)
    end
    it "should assign store" do
      get :edit, :id => @seller.store.id
      assigns(:store).should eq(@seller.store)
    end
    describe "can not find store" do
      it "should redirect to store" do
        get :edit, :id => "90000"
        response.should redirect_to new_store_path
      end
      it "should assign flash" do
        get :edit, :id => "90000"
        cookies['flash'].should match(build_regexp "alert-|-#{I18n.t(:store_profile)}-|-#{I18n.t(:havent_got_store_profile)}")
      end
    end
    describe "seller has no permission to access store" do
      before(:each) { @store = Factory(:seller).store }
      it "should redirect back" do
        get :edit, :id => @store.id
        response.should be_redirect
      end
      it "should assign flash" do
        get :edit, :id => @store.id
        cookies['flash'].should match(build_regexp "alert-|-#{I18n.t(:store_profile)}-|-#{I18n.t(:permission)}")
      end
    end
  end

  describe "PUT update" do
    before(:each) do
      @seller = Factory(:seller, :user_id => Factory(:user).id)
      test_sign_in(@seller.user)
    end
    describe "with valid params" do
      it "updates the requested store" do
        put :update, :id => @seller.store.id, :store => valid_attributes
        cookies['flash'].should match(build_regexp "success-|-#{I18n.t(:store_profile)}-|-#{I18n.t(:store_updated)}")
      end
      it "updates the requested store" do
        put :update, :id => @seller.store.id, :store => valid_attributes
        response.should redirect_to edit_store_path(@seller.store)
      end
    end

    describe "failure" do
      before(:each) { @store = Factory(:seller).store }
      describe "with invalid params" do
        it "updates the requested store" do
          put :update, :id => @seller.store.id, :store => invalid_attributes
          response.should render_template("edit")
        end
        it "should assign flash" do
          put :update, :id => @seller.store.id, :store => invalid_attributes
          request.flash.should_not be_nil
        end
      end

      describe "can not find store" do
        it "should redirect to store" do
          get :edit, :id => "90000"
          response.should redirect_to new_store_path
        end
        it "should assign flash" do
          get :edit, :id => "90000"
          cookies['flash'].should match(build_regexp "alert-|-#{I18n.t(:store_profile)}-|-#{I18n.t(:havent_got_store_profile)}")
        end
      end
      describe "seller has no permission to access store" do
        before(:each) { @store = Factory(:seller).store }
        it "should redirect back" do
          get :edit, :id => @store.id
          response.should be_redirect
        end
        it "should assign flash" do
          get :edit, :id => @store.id
          cookies['flash'].should match(build_regexp "alert-|-#{I18n.t(:store_profile)}-|-#{I18n.t(:permission)}")
        end
      end
    end

  end
end
