require 'spec_helper'

describe CartsController do
  render_views false

  after(:all) { clean_db }

  describe "POST 'add'" do

    before(:each) do
      @params = Factory.attributes_for(:line_item)
    end

    context "if data base cart" do

      before(:all) do
        @user = Factory(:user)
      end

      before(:each) do
        test_sign_in(@user)
      end

      it "should add to cart a valid product" do
        expect {
          post :add, {:size => @params[:item_type].size_category_id, :quantity => @params.count, :product_id => @params[:item_type].product_id, :destination => @params[:ship_to].id, :color => @params[:item_type].color_category_id}
        }.to change(LineItem, :count).by(1)
      end

      it "should not save the item if it is alredy in cart" do
        pending "this will fail through a bug in item_type model. should be activated after bugfixing. Laslo"
        line_item = Factory(:line_item, :user => @user)
        p @user.line_items
        expect {
          post :add, {:size => line_item.item_type.size_category_id, :quantity => line_item.count, :product_id => line_item.item_type.product_id, :destination => line_item.ship_to_id, :color => line_item.item_type.color_category_id}
        @user.reload
        p @user.line_items
        }.to change(LineItem, :count).by(0)
      end

    end

    context "if session cart" do
      it "should add to cart a valid item" do
        session[:cart_items] = []
        expect {
          post :add, {:size => @params[:item_type].size_category_id, :quantity => @params.count, :product_id => @params[:item_type].product_id, :destination => @params[:ship_to].id, :color => @params[:item_type].color_category_id}
        }.to change(session[:cart_items], :count).by(1)
      end
    end
  end

  describe "GET 'index'" do
    before(:all) do
      clean_db
    end

    context "if signed in" do
      before(:all) do
        @user = first_instance_of :user
      end

      before(:each) do
        test_sign_in @user
      end

      it "should be successful" do
        get :index
        response.should be_successful
      end

      it "should fetch the right items" do
        right_items = []
        4.times do
          right_items << Factory(:line_item, :user => @user)
        end
        2.times do
          Factory(:line_item, :user_id => (Factory(:user)).id)
        end
        @user.reload
        get :index
        assigns(:cart_items).should == right_items
      end

      it "should create a hash with items cost" do
        get :index
        assigns(:all_cost).should be_a(Hash)
      end

    end

    context "if not signed in" do
      it "should be successful" do
        get :index
        response.should be_successful
      end

      it "should fetch the right items" do
        session[:cart_items] = []
        4.times do
          session[:cart_items] << Factory(:line_item).to_cart_hash
        end
        get :index
        assigns(:cart_items).count.should == session[:cart_items].count
      end

      it "should create a hash with items cost" do
        get :index
        assigns(:all_cost).should be_a(Hash)
      end
    end

  end

  describe "POST 'remove'" do

    context "if data base cart" do

      before(:each) do
        @user = Factory(:user)
        test_sign_in(@user)
      end

      it "should remove an item from cart" do
        line_item = Factory(:line_item, :user => @user)
        expect {
          post :remove, {:item_type_id => line_item.item_type_id, :ship_to_id => line_item.ship_to_id}
        }.to change(LineItem, :count).by(-1)
      end

      it "should remove exacly the requested item" do
        line_item = Factory(:line_item, :user => @user)
        post :remove, {:item_type_id => line_item.item_type_id, :ship_to_id => line_item.ship_to_id}
        LineItem.find_by_id(line_item.id).should be_nil
      end

    end

    context "if session cart" do

      before(:each) do
        session[:cart_items] = []
        4.times do
          session[:cart_items] << Factory(:line_item).to_cart_hash
        end
      end

      it "should remove an item from cart" do
        line_item = session[:cart_items].second
        expect {
          post :remove, {:item_type_id => line_item.keys.first, :ship_to_id => line_item.values.first[:ship_to]}
        }.to change(session[:cart_items], :count).by(-1)
      end

      it "should remove exacly the requested item" do
        line_item = session[:cart_items].second
        post :remove, {:item_type_id => line_item.keys.first, :ship_to_id => line_item.values.first[:ship_to]}
        session[:cart_items].find_all { |e| e.keys.include?(line_item.keys.first) }.find { |e| e.values.first[:ship_to] == line_item.values.first[:ship_to] }.should be_nil
        session[:cart_items].count.should == 3
      end

    end
  end

  describe "POST 'update'" do

    context "if data base cart" do

      before(:each) do
        @user = Factory(:user)
        test_sign_in(@user)
      end

      after(:each) do
        clean_db
      end


      it "should update an item from cart" do
        line_item = Factory(:line_item, :user => @user)
        post :update, {:item_type_id => line_item.item_type_id, :ship_to_id => line_item.ship_to_id, :quantity => 8}
        LineItem.find_by_id_and_count(line_item.id, 8).should be_a(LineItem)
      end

      it "should update exacly the requested item" do
        other_items = []
        4.times do
          other_items << Factory(:line_item, :user => @user)
        end
        line_item = Factory(:line_item, :user => @user)
        
        post :update, {:item_type_id => line_item.item_type_id, :ship_to_id => line_item.ship_to_id, :quantity => 7}
        (@user.line_items - [line_item]).should == other_items
        line_item.reload
        line_item.count.should == 7
      end

    end

    context "if session cart" do

      before(:each) do
        session[:cart_items] = []
        4.times do
          session[:cart_items] << Factory(:line_item).to_cart_hash
        end
      end

      it "should update an item from cart" do
        line_item = session[:cart_items].second
        post :update, {:item_type_id => line_item.keys.first, :ship_to_id => line_item.values.first[:ship_to], :quantity => 4}
        session[:cart_items].second.values.first[:count].should == 4
      end

      it "should update exacly the requested item" do
        line_item = session[:cart_items].second
        post :update, {:item_type_id => line_item.keys.first, :ship_to_id => line_item.values.first[:ship_to], :quantity => 5}
        updated_item = session[:cart_items].find_all { |e| e.keys.include?(line_item.keys.first) }.find { |e| e.values.first[:ship_to] == line_item.values.first[:ship_to]}
        updated_item.values.first[:count].should == 5
      end

    end
  end













end
