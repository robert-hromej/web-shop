require "spec_helper"

describe "product_recommendations/show.html.haml" do

  it "should display item recommendations" do
    @recommendations = [stub_model(Product, :id => 1, :name => "title", :default_image => "some_src")] * 5
    @product = @recommendations.first
    @recent = @recommendations

    store = stub_model(Store, :id => 5, :name => "name")
    @product.stub(:store => store)
    controller.request.path_parameters[:id] = store.id

    render

    rendered.should have_selector("div", :id => 'recommendations', :class => "carousel") do |recommendations|

      recommendations.should have_selector("div", :class => "jcarousel-clip") do |div|

        div.should have_selector("ul", :class => "jcarousel-list") do |ul|

          ul.should have_selector("li") do |li|
            li.should have_selector("a", :href => '/products/1')
            li.should have_selector("img", :src => "/images/some_src")
          end

        end

      end

      recommendations.should have_selector("div", :class => "carousel-prev-image")
      recommendations.should have_selector("div", :class => "carousel-next-image")

    end

    rendered.should have_selector("div", :id => "recent", :class => "carousel") do |div|

      div.should have_selector("div", :class => "jcarousel-clip") do |div1|

        div1.should have_selector("ul", :class => "jcarousel-list") do |li|

          li.should have_selector("a", :href => "/products/1")
          li.should have_selector("img", :src => "/images/some_src")

        end

      end

    end

  end

end
