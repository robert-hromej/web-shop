require 'spec_helper'

describe "shared/_product_info.html.haml" do
  it "should check elements on partial" do
    product = stub_model(Product, :name => "product1", :new => false, :price => 40)
    render "shared/product_info", :product => product
    rendered.should have_selector("div", :class => "product_info") do |other_product|
      other_product.should have_selector("img")
      other_product.should have_selector("div", :class => "product_text_info") do |oii|
        oii.should have_selector("span", :content => "product1")
        oii.should have_selector("span", :content => "used")
        oii.should have_selector("span", :content => "40.0$")
      end
    end
  end

  it "should display 'new' if product is new" do
    product = stub_model(Product, :name => "product2", :new => true, :price => 20)
    render "shared/product_info", :product => product
    rendered.should have_selector("div", :class => "product_info") do |other_product|
      other_product.should have_selector("img")
      other_product.should have_selector("div", :class => "product_text_info") do |oii|
        oii.should have_selector("span", :content => "product2")
        oii.should have_selector("span", :content => "new")
        oii.should have_selector("span", :content => "20.0$")
      end
    end
  end
end
