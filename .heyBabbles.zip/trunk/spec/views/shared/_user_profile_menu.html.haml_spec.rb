require 'spec_helper'

describe "shared/_user_profile_menu.html.haml" do
  it "should display current user's profile navigation" do
    @user = stub_model(User)
    view.stub(:current_user).and_return(@user)
    render "shared/user_profile_menu"
    rendered.should have_selector("div.user_profile_menu_nav") do |content|
      content.should have_selector("a.button.grey#profile[href=\"#{user_path(@user)}\"]:contains('Profile')")
      content.should have_selector("a.button.grey#purchase_histories:contains('Purchase History')")
      content.should have_selector("a.button.grey#provide_feedback:contains('Provide Feedback')")
      content.should have_selector("a.button.grey#seller_account[href=\"#{new_store_path}\"]:contains('Seller Account')")
    end
  end
end
