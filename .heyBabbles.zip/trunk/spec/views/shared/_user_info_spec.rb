require 'spec_helper'

describe "shared/_user_info.html.haml" do
  it "should display user's info" do
    user = stub_model(User, :username => "ok", :fullname => "Fn Ln", :city => "ct", :state => (stub_model(State, :title => "state_title")))
    render "shared/user_info", :user => user
    rendered.should have_selector("div", :class => "user_info") do |ui|
      ui.should have_selector("a", :href => "#{user_path(user)}") do |a|
        a.should have_selector("img[src^=\"#{user.avatar.url(:thumb)}\"]", :alt => "avatar for user #{user.id}")
      end
      ui.should have_selector("div", :class => "user_text_info") do |ti|
        ti.should have_selector("a", :content => "#{user.username}")
        ti.should have_selector("span", :content => "#{user.fullname}")
        ti.should have_selector("span", :content => "#{user.city}")
        ti.should have_selector("span", :content => "State: #{user.state.title || 'no state'}")
      end
    end
  end
  it "should display some default text if user attributes are empty" do
    user = stub_model(User)
    render "shared/user_info", :user => user
    rendered.should have_selector("div.user_info") do |ui|
      ui.should have_selector("a", :href => "#{user_path(user)}") do |a|
        a.should have_selector("img[src^=\"#{user.avatar.url(:thumb)}\"]", :alt => "avatar for user #{user.id}")
      end
      ui.should have_selector("div", :class => "user_text_info") do |ti|
        ti.should have_selector("a", :content => "no nickname")
        ti.should have_selector("span", :content => "No Name")
        ti.should have_selector("span", :content => "no city")
        ti.should have_selector("span", :content => "State: no state")
      end
    end
  end
end
