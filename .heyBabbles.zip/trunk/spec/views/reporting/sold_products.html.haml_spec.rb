require 'spec_helper'

describe "reporting/sold_products.html.haml" do
  it "should display item data and items" do

    pending "Myroslav"
=begin
NoMethodError:
       undefined method `payed_images' for #<Product:0xb59b1710>
=end

    @user = stub_model(User, :id => 1, :name => "UserName")
    @store = stub_model(Store, :seller => stub_model(Seller, :user => @user))
    @current_user = stub(:has_store? => true, :store => {:id => 1}, :id => 1)

    data = Factory(:invoice_data)
    item_data = Factory(:invoiced_product, :invoice_data_id => data.id)
    data.products << item_data
    data.save

    @invoice_datum = [data]
    @invoice_datum.stub(:total_pages => 1)

    render

    rendered.should have_selector("table", :id =>"carts_table") do |table|
      table.should have_selector("table", :class =>"items_table") do |inner_table|
        %w(data_for_name data_for_count data_for_sh_cost data_for_add_sh_cost).each do |method|
          inner_table.should have_selector("td") do |td|
            td.should contain(item_data.send(method).to_s)
          end
        end
        %w(price item_price).each do |method|
          inner_table.should have_selector("td") do |td|
            price = number_to_currency item_data.send(method)
            td.should contain price
          end
        end
      end
    end
  end

end
