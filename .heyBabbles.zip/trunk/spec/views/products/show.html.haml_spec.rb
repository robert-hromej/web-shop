require 'spec_helper'

describe "products/show.html.haml" do
  it "should check all elements on page" do
    @product = stub_model(Product, :name => "product1", :price => "40.0", :description => "description", :id => "57")
    seller = stub_model(Seller, :user => stub_model(User, :username => "un"))
    @cnav = [["Home", root_path], ["Store name", "#"], ["Product name", "#"]]
    @seller = seller.user
    @seller.should_receive(:fullname).any_number_of_times.and_return("Fn Ln")
    country = stub_model(Country, :title => "Peru")
    @product.stub(:origin).and_return(country)
    shipping1 = stub_model(ShipTo, :country => stub_model(Country, :title => "Libya"), :cost => 10, :additional_cost => 50, :product_limit => 8)
    shipping2 = stub_model(ShipTo, :country => stub_model(Country, :title => "Tanzania"), :cost => 20, :additional_cost => 70, :product_limit => 4)
    @product.stub(:destinations).and_return([shipping1, shipping2])
    @other_products = [stub_model(Product, :name => "product1", :new => false, :price => 40.0), stub_model(Product, :name => "product2", :new => true, :price => 20.0)]
    render
    rendered.should render_template("shared/_user_info")
    rendered.should render_template("shared/_product_info")
    rendered.should have_selector("div", :id => "product_show") do |content|
      content.should have_selector("div", :class => "product_name", :content => "#{@product.name}")
      content.should have_selector("input", :type => "hidden", :name => "product_id", :value => "57")
      content.should have_selector("div[data-price='#{@product.price}']", :class => "item_price", :content => "$") do |price|
        price.should have_selector("div", :id => "price_number", :content => "#{@product.price}")
      end
      content.should have_selector("div", :class => "is_add_to_cart") do |add|
        add.should have_selector("input", :id => "add_to_cart", :type => "submit", :value => "Add to cart")
      end
      content.should have_selector("div", :id => "is_share")
      content.should have_selector("div", :class => "product_images")
      content.should have_selector("div", :class => "product_descriptions") do |d|
        d.should have_selector("textarea", :class => "is_description", :content => "#{@product.description}")
        d.should have_selector("div", :class => "is_specifications") do |s|
          s.should have_selector("select", :id => "scolor")
          s.should have_selector("select", :id => "ssize")
          s.should have_selector("b", :content => "Quantity")
          s.should have_selector("input", :type => "number", :id => "squantity", :min => "1", :name => "quantity")
        end
        d.should have_selector("div", :class => "is_specifications_next") do |sn|
          sn.should have_selector("b", :content => "Cost of one product")
          sn.should have_selector("div", :id => "price_for_one")
        end
        d.should have_selector("article", :content => "Ships from Peru")
        d.should have_selector("table", :class => "is_shipments") do |t|
          t.should have_selector("td", :content => "Libya")
          t.should have_selector("td", :content => "10.0")
          t.should have_selector("td", :content => "50.0")
          t.should have_selector("td", :content => "8")
          t.should have_selector("td", :content => "Tanzania")
          t.should have_selector("td", :content => "20.0")
          t.should have_selector("td", :content => "70.0")
          t.should have_selector("td", :content => "8")
          t.should have_selector("td") do |check_table|
            check_table.should have_selector("input", "data-cost" => '10.0', "data-add_cost" => '50.0', "data-limit" => '8', :name => "destination", :type => "radio", :class => "destination_check")
            check_table.should have_selector("input", "data-cost" => '20.0', "data-add_cost" => '70.0', "data-limit" => '4', :name => "destination", :type => "radio", :class => "destination_check")
          end
        end
        d.should have_selector("textarea", :class => "is_return_policy", :content => "#{@product.return_policy}")
      end
      content.should have_selector("div", :class => "is_other_products") do |oi|
        oi.should contain("product1")
        oi.should contain("product2")
        oi.should have_selector("article", :content => "Other products by #{@seller.fullname}")
      end
      content.should have_selector("div", :class => "is_seller") do |s|
        s.should have_selector("a", :content => "See un's store", :class => "is_view_store")
      end
    end
  end
  it "should display the default message if there are no other products" do
    @product = stub_model(Product, :name => "product1", :price => "40", :description => "description", :seller => (stub_model(Seller, :user => stub_model(User, :fullname => "Fn Ln", :username => "un"))))
    @cnav = [["Home", root_path], ["Store name", "#"], ["Product name", "#"]]
    seller = stub_model(Seller, :user => stub_model(User, :username => "un"))
    @seller = seller.user
    @seller.should_receive(:fullname).any_number_of_times.and_return("Fn Ln")
    render
    rendered.should have_selector("div", :class => "is_other_products") do |oi|
      oi.should have_selector("div", :class => "is_no_other_products", :content => "[ This seller has no other products ]")
    end
  end
end
