require 'spec_helper'

describe "sellers/show.html.haml" do
  it "should check all elements on page" do
    store = stub_model(Store, :name => "store name", :description => "test description", :bio => "test bio", :return_policy => "test return policy")
    @seller = stub_model(Seller, :fullname => "Fname Lname", :store => store, :user => stub_model(User))
    @cnav = [["Home", root_path], ["Fname Lname", "#"]]
    @products = [stub_model(Product, :name => "uniq_name2"), stub_model(Product, :name => "uniq_name1")]
    render
    rendered.should render_template("shared/_user_info")
    rendered.should render_template("shared/_product_info")
    rendered.should have_selector("div", :id => "seller_show") do |content|
      content.should have_selector("div", :id => "ss_welcome", :content => "Welcome to Store name")
      content.should have_selector("div", :id => "ss_user") do |u|
        u.should have_selector("a", :href => "#", :content => "Profile")
        u.should have_selector("a", :href => "#", :content => "Feedbacks")
      end
      content.should have_selector("div", :id => "ss_logo") do |l|
        l.should have_selector("img[src^='#{@seller.try(:store).logo.url(:thumb)}']")
      end
      content.should have_selector("div", :id => "ss_description") do |d|
        d.should have_selector("article", :content => "Description")
        d.should have_selector("textarea", :content => "test description")
      end
      content.should have_selector("div", :id => "ss_br") do |br|
        br.should have_selector("div", :id => "ss_bio") do |b|
          b.should have_selector("article", :content => "Bio")
          b.should have_selector("textarea", :content => "test bio")
        end
        br.should have_selector("div", :id => "ss_return") do |r|
          r.should have_selector("article", :content => "Return policy")
          r.should have_selector("textarea", :content => "test return policy")
        end
      end
      content.should have_selector("div", :id => "ss_shop") do |s|
        s.should have_selector("article") do |a|
          a.should contain("Shop")
          a.should have_selector("a", :content => "See more", :href => "#")
        end
        s.should have_selector("div", :id => "ss_products") do |i|
          i.should contain("uniq_name1")
          i.should contain("uniq_name2")
        end
      end
    end
  end

  it "should display some default value if there is no products" do
    store = stub_model(Store, :name => "store name", :description => "test description", :bio => "test bio", :return_policy => "test return policy")
    @seller = stub_model(Seller, :fullname => "Fname Lname", :store => store, :user => stub_model(User))
    @cnav = [["Home", root_path], ["Fname Lname", "#"]]
    @products = []
    render
    rendered.should_not render_template("shared/_product_info")
    rendered.should have_selector("div", :id => "ss_shop") do |no_products|
      no_products.should have_selector("article", :content => "Shop is empty for now")
    end
  end

end
