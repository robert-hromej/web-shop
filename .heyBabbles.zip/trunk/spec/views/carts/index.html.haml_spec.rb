require 'spec_helper'

describe "carts/index.html.haml" do
  fixtures
  it "should check all elements on page" do
    @all_cost = {:items => 10.5, :shipping => 7.8, :all => 18.3}
    @cart_items = []
    4.times do |index|
      @cart_items << stub_model(LineItem, :count => index+7, :ship_to => stub_model(ShipTo, :id => index+1), :item_type => stub_model(ItemType, :item_count => 14, :id => index, :price => index*(10.0), :product => stub_model(Product, :name => "tmp#{index}", :store => stub_model(Store, :seller => stub_model(Seller, :fullname => "seller name#{index}", :id => index)))))
    end
    render
#    view.should_receive(:calculate_shipping_cost).twice
    rendered.should have_selector("table", :id => "cart_table") do |cart_table|
      cart_table.should have_selector("th", :class => "cart_product", :content => "Product")
      cart_table.should have_selector("th", :content => "Seller")
      cart_table.should have_selector("th", :content => "Price")
      cart_table.should have_selector("th", :content => "Quantity")
      cart_table.should have_selector("th", :content => "Shipping")
      cart_table.should have_selector("th", :content => "Total")
      4.times do |index|
        cart_table.should have_selector("td", :class => "first") do |item_name_and_image|
          item_name_and_image.should have_selector("b", :content => "tmp#{index}")
          item_name_and_image.should have_selector("img")
        end
        cart_table.should have_selector("td") do |td|
          td.should have_selector("b", :content => "by") do |link_to_seller_name|
            link_to_seller_name.should have_selector("a", :href => seller_path(index), :content => "seller name#{index}")
          end
          td.should have_selector("span", :content => "$ #{index*10.0} USD x")
          td.should have_selector("form", :action => update_cart_items_path(), :method => "post") do |update_quantity_form|
            update_quantity_form.should have_selector("input", :type => "hidden", :value => "#{index}", :name => "item_type_id")
            update_quantity_form.should have_selector("input", :type => "hidden", :value => "#{index+1}", :name => "ship_to_id")
            update_quantity_form.should have_selector("input", :type => "number", :value => "#{index+7}", :name => "quantity", :min => "1", :class => "cart_item_quantity", :id => "quantity#{index}")
            update_quantity_form.should have_selector("input", :type => "submit", :class => "cart_item_quantity_submit", :value => "Update")
          end
          td.should have_selector("span", :class => "shipping_cost")
          td.should have_selector("span", :class => "total_cost")
        end
      end
    end
  end
end
