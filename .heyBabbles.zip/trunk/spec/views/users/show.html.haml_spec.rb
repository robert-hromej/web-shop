require 'spec_helper'

describe "users/show.html.haml" do
  it "should display current user's attributes" do
    @user = stub_model(User, :username => "ok", :first_name => "fn", :city => "ct", :state => (stub_model(State, :title => "state_title")), :remember_created_at => "2011-09-28 09:10:19")
    view.stub!(:current_user).and_return(@user)
    controller.request.path_parameters[:id] = @user.id
    render
    pending "add here code to test what you expect to see on users#show"
  end
end
