require 'rubygems'
require 'spork'
require "seed_db"
require "faker"

if RUBY_VERSION == "1.9.2"
  require 'simplecov'
  SimpleCov.start 'rails' do
    add_group "Models", "app/models"
    add_group "Controllers", "app/controllers"
    add_filter "/log/"
    add_filter "/vendor"
    add_filter "/lib/taskapp/controllerss"
    add_filter "/config"
  end
end

if Spork.using_spork?
  ActiveSupport::Dependencies.clear
  ActiveRecord::Base.instantiate_observers
end

Spork.prefork do

  ENV["RAILS_ENV"] ||= 'test'
  require File.expand_path("../../config/environment", __FILE__)
  require 'rspec/rails'
  require 'webmock/rspec'
  require 'webrat'

  Webrat.configure do |config|
    config.mode = :rails
  end
  Dir[Rails.root.join("spec/support/**/*.rb")].each { |f| require f }
  #Dir[Rails.root.join("spec/factories/*.rb")].each { |f| require f }

  RSpec.configure do |config|
    config.mock_with :rspec
    config.include Factory::Syntax::Methods
    config.include(Shoulda::ActiveRecord::CallbackMatcher)
    config.use_transactional_fixtures = true
    #config.filter_run_excluding :slow => true
    #config.filter_run :focus => true

    config.fixture_path = "#{::Rails.root}/spec/fixtures"

    config.before(:each) do
      WebMock.allow_net_connect!
    end
    Rails.root
    config.after(:all) do
      clean_db
    end

    def test_sign_in(user)
      controller.sign_in(user)
    end

    def test_sign_out
      controller.sign_out
    end

    def clean_db
      DatabaseCleaner.strategy = :truncation
      DatabaseCleaner.start #cleaning database
      DatabaseCleaner.clean
    end

    def populate(number = 1, options = {})
      options.reverse_merge!(:factory_label => :fast_item)
      @populate = SeedDB.new("test")
      @populate.seed_items(number, :factory_label => options[:factory_label])
    end

    def freeze_time(time = Time.new)
      Timecop.return
      @time = Timecop.freeze(time)
    end

    def quick_freeze
      freeze_time
      yield
      Timecop.return
    end

    def build_regexp(string)
      string = Regexp.escape(string)
      Regexp.new("#{string}")
    end

    def should_assign_message(message)
      cookies['flash'].should match(build_regexp message), cookies['flash']
    end

    # reload models
    ActiveSupport::Dependencies.clear
    ActiveRecord::Base.instantiate_observers
  end
end

Spork.each_run do
  HeyBabbles::Application.reload_routes!
  FactoryGirl.reload
end
#  Capybara.default_host="localhost"
#  Capybara.app_host="http://0.0.0.0:3005"
#  Capybara.server_port="3005"
