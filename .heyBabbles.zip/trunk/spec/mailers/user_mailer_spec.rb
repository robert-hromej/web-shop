require "spec_helper"

describe UserMailer do

  describe "welcome_mail" do
    before(:each) do
      @user = create(:user)
    end

    it "should render successfully" do
      lambda { UserMailer.create_welcome_mail(@user) }.should_not raise_error
    end

    describe "rendered without error" do
      before(:each) do

        @mail = UserMailer.create_welcome_mail(@user)
      end
      it "should have message" do
        @mail.body.should have_content("Thank you for being registered on our site!")
      end
      it "should have a link back" do
        expression = Regexp.new("#{root_path(:host => APP_CONFIG[:email_host])}")
        @mail.body.should match expression
      end
      it "should deliver successfully" do
        lambda { UserMailer.create_welcome_mail(@user).deliver }.should_not raise_error
      end

      describe "and delivered" do
        it "should be added to the delivery queue" do
          lambda { UserMailer.create_welcome_mail(@user).deliver }.should change(ActionMailer::Base.deliveries, :size).by(1)
        end
      end
    end
  end
  describe "reset password" do
    before(:each) do
      @user = create(:user)
    end

    it "should render successfully" do
      lambda { UserMailer.password_reset_mail(@user) }.should_not raise_error
    end

    describe "rendered without error" do
      before(:each) do
        @mail = UserMailer.password_reset_mail(@user)
      end
      it "should have a link back" do
        expression = Regexp.new("#{edit_password_reset_path(@user.reset_password_token, :host => APP_CONFIG[:email_host])}")
        @mail.body.should =~ expression
      end
      it "should deliver successfully" do
        lambda { UserMailer.create_welcome_mail(@user).deliver }.should_not raise_error
      end

      describe "and delivered" do
        it "should be added to the delivery queue" do
          lambda { UserMailer.create_welcome_mail(@user).deliver }.should change(ActionMailer::Base.deliveries, :size).by(1)
        end

      end
    end
  end
  describe "confirm_email" do
    before(:each) do
      @user = create(:user)
    end

    it "should render successfully" do
      lambda { UserMailer.confirm_email(@user) }.should_not raise_error
    end

    describe "rendered without error" do
      before(:each) do
        @mail = UserMailer.confirm_email(@user)
      end
      it "should have a link back with token" do
        expression = Regexp.new(Regexp.escape("#{finish_registration_url(@user, :token => @user.reset_password_token, :host => APP_CONFIG[:email_host])}"))
        @mail.body.should =~ expression
      end
      it "should deliver successfully" do
        lambda { UserMailer.confirm_email(@user).deliver }.should_not raise_error
      end

      describe "and delivered" do
        it "should be added to the delivery queue" do
          lambda { UserMailer.confirm_email(@user).deliver }.should change(ActionMailer::Base.deliveries, :size).by(1)
        end

      end
    end
  end
  describe "product_creation_email" do
    before(:all) do
      populate
    end

    it "should render successfully" do
      lambda { UserMailer.product_created(@populate.user, @populate.product) }.should_not raise_error
    end

    describe "rendered without error" do
      before(:each) do
        @mail = UserMailer.product_created(@populate.user, @populate.product)
      end

      it "should deliver successfully" do
        lambda { UserMailer.product_created(@populate.user, @populate.product) }.should_not raise_error
      end

      describe("and delivered") do
        it("should be added to the delivery queue") do
          lambda { UserMailer.product_created(@populate.user, @populate.product).deliver }.should change(ActionMailer::Base.deliveries, :size).by(1)
        end
      end
    end
  end
end
