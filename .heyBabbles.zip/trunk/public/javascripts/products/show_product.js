jQuery(function($) {
//    $('.product_image_main').colorbox({title:$(this).attr("title")});
    $('.product_image_main').lightBox();
    $('.product_image').click(function() {
        $('.product_image_main').attr("href", $(this).attr("src"));
        $('#main_image').attr("src", $(this).attr("src"));
        $('.product_image_main').attr("title", $(this).attr("title"));
//        $('#main_image').attr("src", $(this).attr("src"));
    });
});
