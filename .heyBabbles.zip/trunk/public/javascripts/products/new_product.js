/**
 * Created by HeyBabble.
 * User: EdgarK
 * Date: 8/18/11
 * Time: 3:55 PM
 */
$(function() {
    if ($('#new_product_page').length > 0) {


        $('#product-form input[type=file]').live('change', function() {
            $(this).appendTo('#ajax_form');
            $('#ajax_form').ajaxSubmit({
                beforeSubmit: function(a, f, o) {
                    o.dataType = 'json';
                },
                complete: function(XMLHttpRequest, textStatus) {
                    console.log(XMLHttpRequest);
                    console.log(textStatus);
                    return false;
                }
            });
            return false;
        });

        $('input[type=file]').each(function() {
            window['new_product'].validators[$(this).attr('name')] = {
                "presence" : {"message":"can't be blank"},
                "format":
                {
                    "message":"wrong format",
                    "with":/^.*\.(jpg|jpeg|png)$/i
                }
            };
        });
        valid_product_combinations();

        $(".add_photo").click(function() {
            add_photo();
        });
        $(".remove_photo").click(function() {
            clear_description(this);
            $(this).parent(".product_photo").find(".add_description").fadeIn("slow");
            $(this).parent(".product_photo").find(".remove_description").fadeOut("slow");
            $(this).parent(".product_photo").find(".show_description").fadeOut("slow");
            remove_photo(this);
            set_destroy(this, false);
        });
        $(".add_description").click(function() {
            show_description(this);
        });
        $(".hide_description").click(function() {
            hide_description(this);
            $(this).fadeOut('slow');
            $(this).parent(".product_photo").find(".show_description").fadeIn("slow");
            $(this).parent(".product_photo").find(".remove_description").fadeOut("slow");
        });
        $(".show_description").click(function() {
            show_description(this);
        });
        $(".remove_description").click(function() {
            $(this).fadeOut('slow');
            clear_description(this);
            $(this).parent(".product_photo").find(".add_description").fadeIn("slow");
        });
        $(".destroy_image").each(function() {
            if ($(this).val() == '0') {
                add_photo(this);
            }
            show_first_photo();
        });


        $(".destroy_shipment").click(function() {
            hide_show_shipment(this);
        });
        $(".destroy_shipment").each(function() {
            hide_show_shipment(this);
        });


        $(".add_combination").click(function() {
            add_combination(this);
        });
        $(".other_color").click(function() {
            custom_color(this);
        });
        $(".remove_combination").click(function() {
            remove_combination(this);
        });

        $(".image_main").click(function() {
            set_main(this);
        });

        $(".return_policy").click(function() {
            replace_return_policy(this);
        });

        replace_return_policy($(".return_policy"));

        set_first_as_main();
        subtotal_counter();

        $('.home_page_featured,.search_featured,.add_photo,.remove_photo').click(function() {
            subtotal_counter();
        });
        $('.product_photo_file,#season_feature').change(function() {
            subtotal_counter();
        });

        $('.product_shipment').each(function() {
            shipment_checked(this);
        });
    }
});

//adds new photo form
//obj is not necessary parameter and is needed to recreate all images after page refresh
//if obj is given then that form appears in which the obj contained
function add_photo(obj) {
    var photo = '';
    if (!obj) {
        photo = $('.hidden_photo').first();
    } else {
        photo = $(obj).parent(".product_photo");
    }
    photo.fadeIn('slow');
    photo.removeClass("hidden_photo");
    set_destroy(photo.find('.product_description'), true);
    if ($('.hidden_photo').length == 0) {
        $(".add_photo").fadeOut('slow');
    }
    if ($('.product_photo').not('.hidden_photo').length > 1) {
        $('.product_photo').not('.hidden_photo').find('.remove_photo').fadeIn("slow");
    }
    if (photo.find('.product_description').val() != '') {
        photo.find('.add_description').hide();
        photo.find('.show_description').show();
    }
    photo.find('input,select').data('changed', false);
//    .data('valid', true)
//    photo.find('input[type=file]').trigger('focusout');
}

//removes photo form
//obj is a necessary parameter, that image form would be removed in which obj contains
//usually obj is the "remove button" that triggers this event
function remove_photo(obj) {
    var photo = $(obj).parent(".product_photo");
    photo.fadeOut("slow");
    photo.addClass("hidden_photo");
    $(".add_photo").fadeIn('slow');
    clear_file(obj);
    if (photo.find('.image_main').attr('checked')) {
        set_first_as_main();
    }
    if ($('.product_photo').not('.hidden_photo').length == 1) {
        $('.product_photo').not('.hidden_photo').find('.remove_photo').fadeOut("slow");
    }
}

//shows the description field
function show_description(obj) {
    var photo = $(obj).parent(".product_photo");
    var description = photo.find('.product_description');
    description.fadeIn("slow");
    description.keyup(function() { //sets trigger on keyup for "remove description" button appear/disappear
        if (description.val() != '') {
            photo.find('.remove_description').fadeIn("slow");
        } else {
            photo.find('.remove_description').fadeOut("slow");
        }
    });
    $(obj).fadeOut('slow');//removes button that triggered this event
    if (description.val() != '') {//if photo recreated after refresh than this part shows "remove description"
        photo.find('.remove_description').fadeIn("slow");
    }
    photo.find('.hide_description').fadeIn("slow");
}
//hide description and "hide" button
function hide_description(obj) {
    var photo = $(obj).parent(".product_photo");
    photo.find('.product_description,.hide_description').fadeOut("slow");
}
//clears description field
function clear_description(obj) {
    $(obj).parent(".product_photo").find(".product_description").val('');
    hide_description(obj);
}
//clears file field
function clear_file(obj) {
    $(obj).parent(".product_photo").find(".product_photo_file").val('');
}
//sets hidden field value for model removement
function set_destroy(obj, val) {
    var photo = $(obj).parent(".product_photo");
    (val) ? photo.find('.product_photo_file').attr('data-validate', 'true') : photo.find('.product_photo_file').removeAttr('data-validate');
    val = (val) ? '0' : '1';
    photo.find('.destroy_image').val(val);
}

//shows first image form and hides "remove" button if form count equals to 1
function show_first_photo() {
    var photos = $('.product_photo').not('.hidden_photo');
    if (photos.length == 0) {
        add_photo();
    } else if (photos.length == 1) {
        photos.find('.remove_photo').hide();
    }
}
//hides and shows shipment fields in condition of checkbox status
function hide_show_shipment(obj) {
    var shipment = $(obj).parents('.product_shipment');
    if ($(obj).attr('checked')) {
        shipment.find('.hide').attr('data-validate', 'true').add(shipment.find('.field_with_errors')).fadeIn("slow");
    } else {
        shipment.find('.hide').removeAttr('data-validate').add(shipment.find('.field_with_errors')).fadeOut("slow");
    }
}
//clones product_combination last combination and triggers set_combination_names functions
function add_combination(obj) {
    var or_combination = $('.combination').last();
    var new_combination = or_combination.clone(true).hide();
    new_combination
        .find('.message,[id$=attributes_id]')
        .remove()
        .end()
        .find('input:not([type=button]),select')
        .val('')
        .end()
        .find('.field_with_errors select,input')
        .data('valid', true)
        .data('changed', true)
        .unwrap('.field_with_errors')
        .end()
        .appendTo($(or_combination).parents().find('map.combination').last())
        .fadeIn("slow")
        .find('.product_quantity')
        .val('');
    set_combination_names();
}
//sets the correct names and id's for all of combination fields
function set_combination_names() {
    var i = 0;
    $('li.combination').each(function() {
        $(this).children().each(function() {
            var name = $(this).attr('name');
            var id = $(this).attr('id');
            var patt = new RegExp('\[[0-9]+\]', 'g');
            if (name != null && name != 'undefined') {
                $(this).attr('name', name.replace(patt, '[' + i + ']'));
            }
            patt = new RegExp('_[0-9]+_', 'g');
            if (id != null && id != 'undefined') {
                $(this).attr('id', id.replace(patt, '_' + i + '_'));
            }
        });
        i++;
    });
    combination_initialise();
    valid_product_combinations();
}
function combination_initialise() {
    if ($('.combination').length == 1) {
        $('.combination').find('.remove_combination').hide();
    } else {
        $('.combination').find('.remove_combination').show();
    }
}

//changes combination color select to text field and revers it back
function custom_color(obj) {
    var combination = $(obj).parent('.combination');
    combination.find('.custom_color').add(combination.find('.system_color')).val('').fadeToggle();
}
//removes parent to given obj combination and triggers set_combination_names functions
function remove_combination(obj) {
    var combination = $(obj).parent('.combination');
    combination.remove();
    set_combination_names();
}

function set_main(obj) {
    if ($(obj).attr('checked')) {
        $('.image_main').not(obj).attr('checked', false);
    } else {
        set_first_as_main();
    }
}

function set_first_as_main() {
    $('.image_main').attr('checked', false);
    if ($('.product_photo').not('.hidden_photo').not($('.product_photo').has('.product_photo_file[value=]')).length > 0) {
        $('.product_photo').not('.hidden_photo').not($('.product_photo').has('.product_photo_file[value=]')).first().find('.image_main').attr('checked', true);
    } else {
        $('.product_photo').not('.hidden_photo').first().find('.image_main').attr('checked', true);
    }
}

function replace_return_policy(obj) {
    if ($(obj).attr('checked')) {
        $('.product_return_policy').val('').hide();
        $('.store_return_policy').show();
    } else {
        $('.product_return_policy').show();
        $('.store_return_policy').hide();
    }
}

window['new_product'] = {"validators":{
    "product[shippings_attributes][1][additional_shipping_cost]":{
        "presence":{"message":"can't be blank"}
    },
    "product[shippings_attributes][1][shipping_cost]":{
        "presence":{"message":"can't be blank"}
    },
    "product[price]":{
        "presence":{"message":"can't be blank"}
    },"product[shippings_attributes][0][additional_shipping_cost]":{
        "presence":{"message":"can't be blank"}
    },"product[shippings_attributes][2][additional_shipping_cost]":{
        "presence":{"message":"can't be blank"}
    },"product[category]":{
        "presence":{"message":"can't be blank"}
    },"product[name]":{
        "presence":{"message":"can't be blank"},
        "length":{"messages":{
            "maximum":"is too long (maximum is 20 characters)",
            "minimum":"is too short (minimum is 3 characters)"
        },"maximum":20,"minimum":3}
    },
    "product[shippings_attributes][0][shipping_cost]":{
        "presence":{"message":"can't be blank"}
    },"product[shippings_attributes][4][shipping_cost]":{
        "presence":{"message":"can't be blank"}
    },"product[ship_from]":{
        "presence":{"message":"can't be blank"}
    },"product[shippings_attributes][3][shipping_cost]":{
        "presence":{"message":"can't be blank"}
    },"product[shippings_attributes][2][shipping_cost]":{
        "presence":{"message":"can't be blank"}
    },"product[shippings_attributes][4][additional_shipping_cost]":{
        "presence":{"message":"can't be blank"}
    },"product[currency_id]":{
        "presence":{"message":"can't be blank"}
    },"product[shippings_attributes][3][additional_shipping_cost]":{
        "presence":{"message":"can't be blank"}
    },"product[gender]":{
        "presence":{"message":"can't be blank"}
    },"product[subcategory]":{
        "presence":{"message":"can't be blank"}
    },"product[description]":{
        "presence":{"message":"can't be blank"}
    }
},
    "label_tag":"<div class=\"field_with_errors\"><label id=\"label_tag\" /></div>",
    "type":"ActionView::Helpers::FormBuilder",
    "input_tag":"<div class=\"field_with_errors\"><span id=\"input_tag\" /><label for=\"_error\" class=\"message\"></label></div>"
};

function valid_product_combinations() {
    $('.system_color').each(function() {
        window['new_product'].validators[$(this).attr('name')] = {"presence" : {"message":"color can't be blank"}};
    });
    $('.product_combination_size').each(function() {
        window['new_product'].validators[$(this).attr('name')] = {"presence" : {"message":"size can't be blank"}};
    });
}

