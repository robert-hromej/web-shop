$.fn.add_filter = function(close, index) {
    index = (index == null) ? 0 : index;
    var left = $(this).position().left;
    var top = $(this).position().top;
    var width = $('body').find(this).width();
    var height = $('body').find(this).height();
    var element = (top == 0 && left == 0) ? "<div style='height:100%; width:100%;position: fixed !important;'></div>" : $(this).clone().html('').attr('id', '');
    if ($(this).css('position') + '' != 'undefined') {
        left = parseInt($(this).css('padding-left')) / 2 * -1;
        top = parseInt($(this).css('padding-top')) / 2 * -1;
    }
    element = $(element)
        .addClass('filter')
        .css({width: width + 'px', height: height + 'px', left: left, top: top, 'z-index': index})
        .data('filter', true);
    element.prependTo(this);
    if (close != null) {
        element.click(function() {
            $(close).trigger('click');
        })
    }
    return $(this);
};
$.fn.remove_filter = function() {
    $(this).find('.filter').first().remove();
};
$.fn.centered_popup = function(dir) {
    var xx = new RegExp('x', 'ig');
    var yy = new RegExp('y', 'ig');
    if (xx.test(dir)) {
        var browser_width = jQuery(window).width();
        var left = (browser_width * 1 - jQuery(this).width() * 1) / 2;
        (left < 0) ? left = 0 : '';
        jQuery(this).css('left', left);
    }
    if (yy.test(dir)) {
        var browser_height = jQuery(window).height();
        var top = (browser_height * 1 - jQuery(this).height() * 1) / 2;
        (top < 0) ? top = 0 : '';
        jQuery(this).css('top', top);
    }
    return $(this);
};

$.fn.set_id_name = function(i) {
    $(this).children().each(function() {
        var name = $(this).attr('name');
        var id = $(this).attr('id');
        var patt = new RegExp('\[[0-9]+\]', 'g');
        if (name != null && name != 'undefined') {
            $(this).attr('name', name.replace(patt, '[' + i + ']'));
        }
        patt = new RegExp('_[0-9]+_', 'g');
        if (id != null && id != 'undefined') {
            $(this).attr('id', id.replace(patt, '_' + i + '_'));
        }
    });
    return $(this)
};
$(function() {
    if ($('#update_product_page').length > 0) {
        var browser_height = jQuery(window).height();
        $('.popup_body').css('max-height', browser_height - 50 + 'px');
        $('.close').click(function() {
            $(this).parents('[id*=popup]').first().fadeOut('slow');
            $('body').remove_filter();
        });
        $('.change_pref').click(function() {
            $('#feature_popup').centered_popup('x').fadeIn('slow');
            $('body').add_filter('.close', 19);
        });
        $('.rem_photo').click(function() {
            $(this).parents('[class*=image_holder]').first().add_filter();
            remove_old_photo(this);
        });
        $('.product_shipment').each(function() {
            shipment_checked(this);
        });
        $('.add_photo').click(function() {
            add_new_photo();
        });
        $('.add_description').live('click', function() {
            description_popup(this);
        });
        $(".destroy_shipment").click(function() {
            hide_show_shipment(this);
        });
        $(".destroy_shipment").each(function() {
            hide_show_shipment(this);
        });
        $(".add_combination").click(function() {
            add_combination(this);
        });
        $(".other_color").click(function() {
            custom_color(this);
        });
        $(".return_policy").click(function() {
            replace_return_policy(this);
        });
        replace_return_policy(this);
        intitialise_return_policy();
        combination_initialise();
        subtotal_counter();
        $(".remove_combination").click(function() {
            remove_comb(this);
        });
        show_hide_photo_addition();
        $('.home_page_featured,.search_featured,.add_photo,.rem_photo').click(function() {
            subtotal_counter();
        });
        $('.product_photo_file,#season_feature').live('change', function() {
            subtotal_counter();
        });
    }
});
function shipment_checked(obj) {
    var cost = $(obj).find('[id*=shipping_cost]').not('[id*=additional_shipping_cost]').val();
    var add_cost = $(obj).find('[id*=additional_shipping_cost]').val();
    if (cost != '' || add_cost != '') {
        $(obj).find('.destroy_shipment').attr('checked', true);
    }
}
function remove_old_photo(obj) {
    obj = $(obj);
    var photo = obj.parents('.image_holder');
    photo.find('.destroy_image').val(1);
    show_hide_photo_addition();
    return photo;
}
function add_new_photo() {
    var new_photo = $('.photo_params').first().clone();
    new_photo
        .set_id_name(get_id('product_images'))
        .find('input, textarea')
        .not('[type=button]')
        .val('')
        .html('');
    new_photo.find('.destroy_image').val('0');
    new_photo.removeClass('photo_params').removeClass('old_params').addClass('new_photo_added').appendTo('.new_photos');
    show_hide_photo_addition();
}
function get_id(selector) {
    var patt = new RegExp('_([0-9]+)_', 'g');
    var max = 0;
    $('[id*=' + selector + ']').each(function() {
        var result = patt.exec($(this).attr('id'));
        var current = (result == null) ? 0 : result[1];
        current = parseInt(current);
        max = (current > max) ? current : max;
    });
    return (max + 1);
}
function description_popup(obj) {
    $('#feature_popup').add_filter(null, 28);
    var last_obj = $(obj).parent('.image_holder').children().find('.product_description');
    last_obj = (last_obj.length > 0) ? last_obj : $(obj).parent('.new_photo_added').find('.product_description');
    var val = (last_obj.val() == '') ? last_obj.html() : last_obj.val();
    console.log(val);
    $('<div class="description_popup"><div class="section_header" >Description</div><textarea class="temp_textarea" rows="4" cols="40">' + val + '</textarea><input type="button" value="OK"><input type="button" value="Cancel"></div>')
        .appendTo('#feature_popup')
        .fadeIn('slow')
        .centered_popup('xy');
    $('.description_popup input[value=OK]').click(function() {
        last_obj.val($('.temp_textarea').val());
        $('.description_popup').remove();
        $('#feature_popup').remove_filter();
    });
    $('.description_popup input[value=Cancel]').click(function() {
        $('.description_popup').remove();
        $('#feature_popup').remove_filter();
    });
    return true;
}
function intitialise_return_policy() {
    if ($('.product_return_policy').val() != '') {
        $('.return_policy').attr('checked', false);
    } else {
        $('.return_policy').trigger('click');
        $('.return_policy').attr('checked', true);
    }
}
function remove_comb(obj) {
    var combination = $(obj).parent('.combination');
    combination.hide().find('.destroy_combination').val(1);
}
function show_hide_photo_addition() {
    if ($('.destroy_image[value=0]').length >= 8) {
        $('.add_photo').hide();
    } else {
        $('.add_photo').show();
    }
}

function subtotal_counter() {
    var home = 0, season = 0, photo = 0, search = 0, features = $('#feature'), photo_count = 0;
    features = {'image_payed_count': parseInt(features.attr('data-image_payed_count')), 'image_free_count':parseInt(features.attr('data-image_feature_free_count')),
        'image_price':parseInt(features.attr('data-image_feature_price')), 'home_page_price':parseInt(features.attr('data-home_feature_price')),
        'search_price':parseInt(features.attr('data-search_feature_price')), 'seasonal_price':parseInt(features.attr('data-seasonal_feature_price'))
    };
    photo_count = (features['image_payed_count'] < features['image_free_count']) ? features['image_free_count'] : features['image_payed_count'];
    photo_count -= $('.photo_params .destroy_image[value=0]').length;

    home = ($('.home_page_featured').attr('checked')) ? features['home_page_price'] : 0;
    search = ($('.search_featured').attr('checked')) ? features['search_price'] : 0;
    season = ($('#season_feature option:selected').val() != '') ? features['seasonal_price'] : 0;
    photo = (features['image_price'] * ($('.product_photo_file').not('.product_photo_file[value=]').length - photo_count));
    photo = (photo < 0) ? 0 : photo;

    $('td.home_feature_price').html(home + ' $');
    $('td.search_feature_price').html(search + ' $');
    $('td.seasonal_feature_price').html(season + ' $');
    $('td.image_feature_price').html(photo + ' $');

    $('td.total_price').html(parseInt(home + season + photo + search) + ' $');
    return [home, search, season, photo]
}