window['new_user'] = {
    "validators":
    {
        "user[email]":
        {
            "format":
            {
                "message":"Email is invalid",
                "with":/^[\w+\-.]+@[a-z\d\-.]+\.[a-z]+$/i
            },
            "presence":
            {
                "message":"Email can't be blank"
            }
        },
        "user[password]":
        {
            "confirmation":
            {
                "message":"Password doesn't match confirmation"
            },
            "presence":
            {
                "message":"Password can't be blank"
            },
            "length":
            {
                "messages":
                {
                    "maximum":"Password is too long (maximum is 40 characters)",
                    "minimum":"Password is too short (minimum is 6 characters)"
                },
                "maximum":40,
                "minimum":6
            }
        }
    },
    "label_tag":"<div class=\"field_with_errors\"><label id=\"label_tag\" />",
    "type":"ActionView::Helpers::FormBuilder",
    "input_tag":"<span class=\"field_with_errors\"><span id=\"input_tag\" /><label for=\"\" class=\"message\"></label></span>"
};
