/**
 * Created by JetBrains RubyMine.
 * User: tom
 * Date: 9/30/11
 * Time: 6:23 PM
 * To change this template use File | Settings | File Templates.
 */
jQuery(function($) {
    $('#reset-password').click(function(event) {
        event.preventDefault();
        $('#reset_password_form').fadeToggle();
    });
});
