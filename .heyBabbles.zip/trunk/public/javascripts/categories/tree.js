function show_category(id, auto_hide) {
    if (!id)
        return;

    if (id.style.display == "none") {
        $(id).fadeIn("fast");
        show_category(id.parentElement.parentElement, false);
    }
    else if (auto_hide == null || auto_hide == true)
        $(id).fadeOut("fast");
}

