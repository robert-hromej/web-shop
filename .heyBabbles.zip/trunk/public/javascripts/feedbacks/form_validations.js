window['new_feedback'] = {
    "validators":
    {
        "feedback[feedback_text]":
        {
            "length":
            {
                "messages":
                {
                    "minimum":"is too short (minimum is 5 characters)"
                },
                "minimum":5
            }
        }
    },
    "label_tag":"<div class=\"field_with_errors\"><label id=\"label_tag\" />",
    "type":"ActionView::Helpers::FormBuilder",
    "input_tag":"<div class=\"field_with_errors\"><span id=\"input_tag\" /><label for=\"_error\" class=\"message\"></label></div>"
};
