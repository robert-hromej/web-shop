window['user_form'] = {
    "validators":
    {
        "user[address_attributes][city]":{
            "presence":
            {
                "message":"city can't be blank"
            },
            "length":
            {
                "messages":
                {
                    "maximum":"is too long (maximum is 30 characters)",
                    "minimum" : "is too short (minimum is 2 characters)"
                },
                "maximum":30,
                "minimum":2
            }
        },
        "user[address_attributes][street]":{
            "presence":
            {
                "message":"street can't be blank"
            }
        },
        "user[address_attributes][zip]":{
            "presence":
            {
                "message":"zip can't be blank"
            },
            "numericality":
            {
                "messages":
                {
                    "numericality":"is not a number"
                }
            },
            "length":
            {
                "messages":
                {
                    "minimum":"is too short (minimum is 3 characters)"
                },
                "minimum":3
            }
        },
        "user[seller_attributes][last_name]":{
            "presence":
            {
                "message":"last name can't be blank"
            },
            "length":
            {
                "messages":
                {
                    "maximum":"is too long (maximum is 30 characters)"
                },
                "maximum":30
            }
        },
        "user[seller_attributes][first_name]":
        {
            "presence":
            {
                "message":"first name can't be blank"
            },
            "length":
            {
                "messages":
                {
                    "maximum":"is too long (maximum is 30 characters)"
                },
                "maximum":30
            }
        },
        "user[address_attributes][state_id]":
        {
            "presence":
            {
                "message":"state can't be blank"
            }
        },
        "user[address_attributes][phone]":
        {
            "presence":
            {
                "message":"phone can't be blank"
            },
            "numericality":
            {
                "messages":
                {
                    "numericality":"is not a number (no special characters needed)"
                }
            }
        },
        "user[address_attributes][country_id]":
        {
            "presence":
            {
                "message":"country can't be blank"
            }
        }
    },
    "label_tag":"<div class=\"field_with_errors\"><label id=\"label_tag\" />",
    "type":"ActionView::Helpers::FormBuilder",
    "input_tag":"<div class=\"field_with_errors\"><span id=\"input_tag\" /><label for=\"_error\" class=\"message\"></label></div>"
};

window['edit_user'] = {
    "validators":
    {
        "user[address_attributes][city]":
        {
            "presence":
            {
                "message":"can't be blank"
            }
        },
        "user[address_attributes][state_id]":
        {
            "numericality":
            {
                "messages":
                {
                    "numericality":"is not a number"
                }
            }
        },
        "user[address_attributes][country_id]":
        {
            "numericality":
            {
                "messages":
                {
                    "numericality":"is not a number"
                }
            }
        }
    },
    "label_tag":"<div class=\"field_with_errors\"><label id=\"label_tag\" />",
    "type":"ActionView::Helpers::FormBuilder",
    "input_tag":"<span class=\"field_with_errors\"><span id=\"input_tag\" /><label for=\"\" class=\"message\"></label></span>"
};

function pofig() {
    var obj = jQuery('.actions input#user_submit');
    if (obj.attr('disabled')) {
        obj.removeAttr('disabled');
    } else {
        obj.attr('disabled', 'true');
    }
}
