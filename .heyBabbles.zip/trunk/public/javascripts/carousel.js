/**
 * Created by JetBrains RubyMine.
 * User: EdgarK
 * Date: 10/20/11
 * Time: 8:04 PM
 * To change this template use File | Settings | File Templates.
 */
$(function() {
    $('.carousel-next-image').click(function() {
        var carousel = $(this).parents('.carousel').find('ul');
        var scroll = carousel.scrollLeft();
        var x = 0;
        carousel.find('li').each(function() {
            if (x == 0 && $(this).position().left > 1) {
                x = $(this).position().left;
            }
        });
        carousel.animate({ scrollLeft: scroll + x }, 300);
    });
    $('.carousel-prev-image').click(function() {
        var carousel = $(this).parents('.carousel').find('ul');
        var scroll = carousel.scrollLeft();
        var x = 0;
        carousel.find('li').each(function() {
            if ($(this).position().left < 0) {
                x = $(this).position().left;
            }
        });
        carousel.animate({ scrollLeft: scroll + x }, 300);
    });
});