jQuery(function($) {

    $('.cart_item_quantity_submit').click(function(e) {
        e.preventDefault();
        $.post($(this).closest('form').attr("action"), $(this).closest('form').serialize(), null, "script")
    });

    $('.cart_item_remove_submit').click(function(e) {
        e.preventDefault();
        $.post($(this).closest('form').attr("action"), $(this).closest('form').serialize(), null, "script")
    });

    $('#refresh_cart').click(function(e) {
        e.preventDefault();
        $.post($('#cart_table').attr('data-check_path'), null, null, "script")
    });

    $('#cart_table').tablesorter();



});
