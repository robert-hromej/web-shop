window['store_form'] = {
    "validators":
    {
        "store[name]":
        {
            "presence":
            {
                "message":"Name can't be blank"
            },
            "length":
            {
                "messages":
                {
                    "maximum":"is too long (maximum is 100 characters)"
                },
                "maximum":100
            }
        },
        "store[return_policy]":
        {
            "presence":
            {
                "message":"Return policy can't be blank"
            },
            "length":
            {
                "messages":
                {
                    "maximum":"is too long (maximum is 400 characters)"
                },
                "maximum":400
            }
        },
        "store[description]":
        {
            "presence":
            {
                "message":"Description can't be blank"
            },
            "length":
            {
                "messages":
                {
                    "maximum":"is too long (maximum is 400 characters)"
                },
                "maximum":400
            }
        },
        "store[bio]":
        {
            "presence":
            {
                "message":"Bio can't be blank"
            },
            "length":
            {
                "messages":
                {
                    "maximum":"is too long (maximum is 400 characters)"
                },
                "maximum":400
            }
        }
    },
    "label_tag":"<div class=\"field_with_errors\"><label id=\"label_tag\" />",
    "type":"ActionView::Helpers::FormBuilder",
    "input_tag":"<div class=\"field_with_errors\"><span id=\"input_tag\" /><label for=\"_error\" class=\"message\"></label></div>"
};
