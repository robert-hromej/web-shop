window['sign_in_form'] = {
    "validators":
    {
        "session[email]":
        {
            "format":
            {
                "message":"Email is invalid",
                "with":/^[\w+\-.]+@[a-z\d\-.]+\.[a-z]+$/i
            },
            "presence":
            {
                "message":"Email can't be blank"
            }
        }
    },
    "label_tag":"<div class=\"field_with_errors\"><label id=\"label_tag\" />",
    "type":"ActionView::Helpers::FormBuilder",
    "input_tag":"<span class=\"field_with_errors\"><span id=\"input_tag\" /><label for=\"\" class=\"message\"></label></span>"
};
