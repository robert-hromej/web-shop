jQuery(function($) {
    set_flash();
    $("#control_7").dropdownchecklist({ icon: {}, width: 150 });
    jQuery("ul.top_nav li span").click(
        function() { //When trigger is clicked...
            var li = jQuery(this).parent()[0];
            var count = 0;
            jQuery(li).parent().children().each(function() {
                count += 1;
                if (this == li) {
                    return false;
                }
            });
            var sub = jQuery("#drop_menus").children(":nth-child(" + count + ")");
            //Following events are applied to the subnav itself (moving subnav up and down)
            jQuery(document).find(".drop_menu").not(sub).slideUp("slow");
            sub.delay(200).slideToggle("slow");

            //Following events are applied to the trigger (Hover events for the trigger)
        }).hover(function() {
            jQuery(this).addClass("subhover"); //On hover over, add class "subhover"
        }, function() {  //On Hover Out
            jQuery(this).removeClass("subhover"); //On hover out, remove class "subhover"
        });
});

function set_flash() {
    var flash = $.cookie('flash');
    if (flash != null && flash != '') {
        var mes = flash.split("&");
        for (var i = 0; i < mes.length; i++) draw_flash(mes[i]);
        $.cookie('flash', null, {path: '/'});
    }
}
function draw_flash(flash) {
    flash = flash.split("-|-");
    for (var i = 0; i < flash.length; i++) flash[i] = flash[i].replace(/\+/g, " ");
    jQuery.gritter.add({
        title: flash[1],
        text : flash[2],
        time : 5000,
        class_name: ("g" + flash[0])
    });
}

function setCookie(name, value, expires, path, domain, secure) {
    document.cookie = name + "=" + escape(value) +
        ((expires) ? "; expires=" + expires : "") +
        ((path) ? "; path=" + path : "") +
        ((domain) ? "; domain=" + domain : "") +
        ((secure) ? "; secure" : "");
}

function getCookie(name) {
    var cookie = " " + document.cookie;
    var search = " " + name + "=";
    var setStr = null;
    var offset = 0;
    var end = 0;
    if (cookie.length > 0) {
        offset = cookie.indexOf(search);
        if (offset != -1) {
            offset += search.length;
            end = cookie.indexOf(";", offset)
            if (end == -1) {
                end = cookie.length;
            }
            setStr = unescape(cookie.substring(offset, end));
        }
    }
    return(setStr);
}