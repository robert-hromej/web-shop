/**
 * Created by JetBrains RubyMine.
 * User: miroslav
 * Date: 12.10.11
 * Time: 19:46
 * To change this template use File | Settings | File Templates.
 */

jQuery(function($) {
//    var ind = window.location.hash;
    var ind = getCookie("anchor")
    if (ind != "") {
//        var index = parseInt(ind.slice(1, ind.length));
        var index = parseInt(ind);
        slide_products(index);
        $('#tab_' + index).focus();
    }
    setCookie("anchor",null)
});

function slide_products(index) {
    jQuery(".slaide_button div#minus").not("#but_" + index + ".slaide_button div#minus").hide("fast");
    jQuery(".slaide_button div#plus").not("#but_" + index + ".slaide_button div#plus").show("fast");
    jQuery(".items_table").not("table#tab_" + index + ".items_table").slideUp("slow");
    jQuery("#but_" + index + ".slaide_button div#minus").toggle("fast");
    jQuery("#but_" + index + ".slaide_button div#plus").toggle("fast");
    jQuery("table#tab_" + index + ".items_table").slideToggle("slow");
    setCookie("anchor",index)
//    window.location.hash = index;
}
