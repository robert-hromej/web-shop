module ApplicationHelper


#===================================
#temporary


#include AdaptivePayment


#===================================


#  <b>==DOCUMENTATION==</b>
#  <b>Gave ability simply create html tags inside helpers</b>
#
#  <b>Usage</b>
#    div.page! {
#      div.content {
#        h1 "A Short Short Saintly Dog"
#      }
#    }
#
#  <b>output</b> -->
#    <div id="page">
#      <div class="content">
#        <h1>A Short Short Saintly Dog</h1>
#      </div>
#    </div>
  def html_tags(&block)
    Markaby::Builder.new({}, self, &block)
  end

  #usage: just paste <%= title "My title "%> on your page
  #warning:IT WORKS WHEN YOU SET SCRIPLET <%= yield(:title) || "Static Title" %> IN LAYOUT
  def title(page_title)
    content_for(:title) { page_title }
  end

  #escape error if they happend
  def escape
    begin
      yield
    rescue => e
      Rails.logger.error "Error is ============> #{e}"
      Rails.logger.error e.backtrace.join("\n")
      ""
    end
    ""
  end

  #  <b>Draws the error message block</b>
  #  <em>income</em> <-- <b>object</b>
  #     - excepts object which refers to the random model one
  #  <em>outcome</em> --> <b>html</b>
  #       <div class="error">
  #          <div class="alertImg">
  #            <img src="/images/icons/error.png?1303331009" alt="Alert">
  #          </div>
  #          <div class="alertContent">
  #            <span class="header">3 errors occured!</span>
  #            <ul>
  #              <li>...some inf </li>
  #              <li>...some inf </li>
  #              <li>...some inf </li>
  #            </ul>
  #          </div>
  #     </div>
  #
  #  <b>Usage</b>
  #  <%= error_message_for @projects %>
  def error_message_for(object)
    return if object.errors.empty?
    raw(
        html_tags do
          div.error {
            div.alertImg { image_tag "icons/error.png" }
            div.alertContent! {
              span.header { "#{pluralize(object.errors.count, "error")} occured!" }
              ul {
                object.errors.full_messages.each do |msg|
                  li { msg }
                end
              }
            }
          }
        end
    )
  end

  def javascript(*files)
    content_for(:head) { javascript_include_tag(*files) }
  end

  def css(*files)
    content_for(:head) { stylesheet_link_tag(*files) }
  end

  # For facebook
  def fb_observer
    APP_CONFIG[:shared_route] + facebook_connect_sessions_path()
  end

  # Redirects to register as seller form otherwise show to seller store profile
  #
  def sell_link
    if signed_in?
      if current_user.seller?
        #todo weired bug
        if current_user.has_store? && !current_user.store.id.nil?
          link_to t(:sell), edit_store_path(current_user.store), :id => "Sell"
        else
          link_to t(:sell), new_store_path, :id => "Sell"
        end
      else
        link_to t(:sell), new_seller_path, :id => "Sell"
      end
    else
      link_to t(:sell), new_seller_path, :id => "Sell"
    end
  end

  # Redirects to new or edit if has_store?
  def seller_account_link(name)
    if current_user.has_store? && !current_user.store.id.nil?
      link = link_to(name, edit_store_path(current_user.store), {:class => "button grey", :id => html_id(name)})
    else
      link = link_to(name, new_store_path(), {:class => "button grey", :id => html_id(name)})
    end
    link.html_safe
  end

  #returns a string that can be used as a html tag id attribute. example: Seller Account => seller_account
  def html_id(str)
    str.split(" ").join("_").downcase!
  end

  #creates a link set like "Home > Store name > Product name". requires an array_data that must contain [["link title", path]]
  #def cnav_links(array_data)
  #  links = "".html_safe
  #  i = 0
  #  array_data.each do |e|
  #    i = i+1
  #    if i < array_data.length
  #      links << link_to(e.first, e.second) << "&nbsp;>&nbsp;".html_safe
  #    else
  #      links << "<span>".html_safe << e.first << "</span>".html_safe
  #    end
  #  end
  #  links
  #end


  #returns a quantity of items in cart
  def items_in_cart
    if signed_in?
      current_user.line_items.count
    else
      if session[:cart_items]
        session[:cart_items].count
      else
        0
      end
    end
  end


  #calculates the cost of all items in cart including shipping cost
  def cart_items_cost
    item_cost = 0
    shipping_cost = 0
    total_cost = 0
    if signed_in?
      current_user.line_items.each do |line_item|
        item_cost += line_item.item_type.price * line_item.count
        shipping_cost += calculate_shipping_cost(line_item.count, line_item.ship_to)
      end
    else
      if session[:cart_items]
        session[:cart_items].each do |line_item|
          item_cost += ItemType.find_by_id(line_item.keys.first).try(:price).to_i * line_item.values.first[:count]
          shipping_cost += calculate_shipping_cost(line_item.values.first[:count], ShipTo.find_by_id(line_item.values.first[:ship_to]))
        end
      end
    end
    {:items => item_cost, :shipping => shipping_cost, :total => (item_cost + shipping_cost)}
  end


  #calculates the shipping cost from items count and destination
  def calculate_shipping_cost(cont, ship_to)
    add_cost = ship_to.additional_cost
    cost = ship_to.cost
    limit = ship_to.product_limit
    if (cont > limit)
      add_price = cost*limit + add_cost*(cont-limit)
    else
      add_price = cost*cont
    end
    add_price
  end


  def load_js_for_development
    javascript_include_tag(JSD.transform["javascripts"]["workspace"].map { |element| element.gsub("public/javascripts/", "") })
  end

  def merge_current_params(new_params = {})
    params.dup.merge(new_params)
  end

  def show_ajax_notify
    escape_javascript("set_flash();")
  end

  # generate full path to category.
  def full_category_path(options = {})
    category = options[:category]
    if options[:season]
      season_category_path(category, options.merge({:category => nil}))
    else
      category_path(category, options.merge({:category => nil}))
    end
  end

  def category_child_container_id(options = {})
    unless options[:category].blank?
      container = "category_children_#{options[:category].id}"
      options.each { |key, value| container << value.try(:id).to_s }
    end
    container
  end

end

