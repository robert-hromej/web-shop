module HomeHelper
  def new?(product)
    product.new ? "New" : "Used"
  end

  def seller_fullname
    title = "Featured Vendor"
    @seller.nil? ? title : title + (" is " + @seller.fullname)
  end

end
