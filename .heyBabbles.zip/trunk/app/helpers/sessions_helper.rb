module SessionsHelper
  attr_writer :current_user

  def sign_in(user)
    session[:remember_token] = [user.id, user.salt]
    self.current_user = user
    session[:user_id] = user.id
    session[:seller_id] = user.seller.id unless user.seller.blank?
  end

  def sign_out
    session.delete(:remember_token)
    session.delete(:user_id)
    session.delete(:seller_id)
    self.current_user = nil
  end

  def signed_in?
    !current_user.blank?
  end

  def current_seller
    current_user.seller
  end

  def current_user
    @current_user ||= user_from_remember_token
  end

  def current_user?(user)
    user == @current_user
  end

  def deny_access
    store_location
    notify(:type => "alert", :title => t(:deny), :message => t(:notice_sign_in))
    redirect_to signin_path
  end

  # friendly forwarding so the users will get page they ask for
  def redirect_back_or(default)
    redirect_to(session[:return_to] || default)
    clear_return_to
  end

  #Filter not 'signed in' users
  def authenticate
    deny_access unless signed_in?
  end

  #Several pages will be denied for seller
  def authenticate_seller
    unless current_user.seller?
      notify(:type => "error", :title => t(:seller_profile), :message => t(:havent_got_seller_profile))
      redirect_to new_seller_path
    end
  end

  #Deny if user has no store
  def deny_without_store
    if current_user.store.nil?
      message = (t('need_store') + ("<a href='#{new_store_path}'>Create store</a>")).html_safe
      notify(:type => "error", :title => t(:product_management), :message => message)
      redirect_back_or_root
    end
  end

  #Filter
  # User can`t invoke sign in or reset password logic if he already in system
  # he would be redirected
  def deny_if_signed
    if signed_in?
      notify(:type => "alert", :title => t(:deny), :message => t(:cant_access))
      redirect_to user_path(current_user)
    end
  end

  #Redirects back or root_url
  # Income: options by default :notice => "", :error => ""
  # If malfunction params add than simple redirect to root
  #
  def redirect_back_or_root()
    request.env["HTTP_REFERER"] ? (redirect_to :back) : (redirect_to root_path)
  end

  #Tracks error and its backtrace
  #
  def error_log_for(exception)
    logger.debugger "Error is: ========> #{exception}"
    logger.debugger exception.backtrace.join("\n")
  end

  # Just parse ActiveRecord 'error' object.
  # Use this for messages within controllers.
  #
  def errors_messages_for(object)
    object.errors.full_messages.join("<br/>").html_safe if object.errors.any?
  end

  # We were forced to implement notifications within cookies.
  # This help us to cache pages and at the same time have dynamic messages
  #
  # @params options[hash]
  # Example:
  # <code>notify(:type => "success", :title => t(:authenticate), :message => t(:sign_in_success))</code>
  #
  def notify(options = {})
    options[:time] ||= 5000
    unless options.blank?
      value = ["#{options[:type]}-|-#{options[:title]}-|-#{options[:message]}-|-#{options[:time]}"]
      cookies[:flash].each { |flash| value << flash } unless cookies[:flash].blank?
      cookies[:flash] = {:value => value, :expires => Time.now + 1.minute}
    end
  end

  def ajax_notify(options={})
    notify(options)
    #  TODO "ajax_notify"
  end

  def user_id
    if !session[:user_id].blank?
      session[:user_id]
    else
      session[:user_id] = current_user.id if current_user
    end
  end

  def seller_id
    if !session[:seller_id].blank?
      session[:seller_id]
    else
      if signed_in?
        session[:seller_id] = current_user.seller.id if current_user.seller?
      end
    end
  end

  def recent_products(product_id)
    raise "Fixnum required" unless product_id.is_a?(Fixnum)
    session[:recent_products] ||= []
    session[:recent_products].shift() if session[:recent_products].length > 5
    session[:recent_products] << product_id unless session[:recent_products].include?(product_id)
    session[:recent_products]
  end

  def return_recent_products(product_id = nil)
    session[:recent_products] ||= []
    recent = (product_id.nil?) ? session[:recent_products] : session[:recent_products] - [product_id]
    recent = recent.reverse()[0..4]
    Product.where(:id => recent).order(:id => recent) unless recent.empty?
  end

  private

  def user_from_remember_token
    User.authenticate_with_salt(*remember_token) unless remember_token.compact.blank?
  end

  def remember_token
    session[:remember_token] || [nil, nil]
  end

  def store_location
    session[:return_to] = request.fullpath
  end

  def clear_return_to
    session[:return_to] = nil
  end
end
