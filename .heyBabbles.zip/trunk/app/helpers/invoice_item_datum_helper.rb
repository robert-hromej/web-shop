module InvoiceItemDatumHelper
  def payment_date(payment_info)
    payment_info.data_for_date_of_sent.blank? ? Date.today : payment_info.data_for_date_of_sent.to_date
  end
end
