module ProductRecommendationsHelper
  def url_before_item_show
    (session[:url_before_item_show]) ? session[:url_before_item_show] : root_path
  end
end
