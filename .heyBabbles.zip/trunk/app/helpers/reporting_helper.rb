module ReportingHelper
  def info_link(invoiced_item)
    @html = ""
    if invoiced_item.status != 3
      @html = edit_invoice_item_datum_path(invoiced_item)
    else
      @html = invoice_item_datum_path(invoiced_item)
    end
    raw(@html)
  end
end