module CategoriesHelper
  def list(categories, season = nil, parent_category_path = {})
    html = ""
    categories.each do |category|
      html << "<div id='category_#{category[:id]}'>"
      html << "*" * (category[:level]-1)

      category_path = parent_category_path.dup
      category_path[Category::LEVELS_SYMBOLS[category[:level]]] = category[:id]
      category_path[:season] = season.id if season


      html << link_to(category[:title], full_category_path(category_path))

      if category[:children]
        html << "<span onclick='show_category(#{category_child_container_id(category_path)})'>+</span>"
        html << "<div class='category_child' id='#{category_child_container_id(category_path)}' style='display:none;'>"
        html << list(category[:children], season, category_path)
        html << "</div>"
      end

      html << "</div>"
    end

    raw html
  end

end
