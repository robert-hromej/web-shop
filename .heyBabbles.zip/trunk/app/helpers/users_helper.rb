module UsersHelper
  def gender_select(f)
    @html = ''
    User::GENDERS.each_with_index do |gender, index|
      @html += f.radio_button :gender, index
      @html += label :gender, gender
    end
    raw(@html)
  end

  def if_has_password?
    !current_user.encrypted_password.blank?
  end

  def user_validate
    if current_user.seller
      return :'data-validate' => true
    else
      return {}
    end
  end
end
