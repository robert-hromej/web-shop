class UsersController < ApplicationController

  before_filter :authenticate, :only => [:show, :update]
  before_filter :correct_user, :only => [:show]
  expose(:countries) { Country.all }
  expose(:states) { State.all }

  caches_page :dynamic_states
  caches_action :new, :expires_in => APP_CONFIG[:expires_in].minutes

  def new
    add_breadcrumb I18n.t(:register), :new_user_path

    if current_user.blank?
      @user = User.new
      @user.build_address
    else
      redirect_to user_path(current_user)
    end
  end

  def create
    # Merge attribute skip for escaping validations within Address model
    params[:user][:address_attributes]

    @user = User.new(params[:user])
    if @user.save
      @user.send_confirmation_mail
      notify(:type => "notice", :title => t(:register_process), :message => t(:confirm_send))
      redirect_to root_path()
    else
      notify(:type => "alert", :title => t(:register_process), :message => errors_messages_for(@user))
      render 'new'
    end
  end

  def show
    add_breadcrumb I18n.t(:my_profile), :user_path

    @user = User.find(current_user.id, :include =>[:address, :seller])
    fresh_when(:etag => [@user, @user.seller]) if Rails.env == "production"
  rescue ActiveRecord::RecordNotFound
    notify(:type => "alert", :title => t(:user_profile), :message => t(:record_not_found))
    redirect_back_or_root
  end

  # This method allows to update both seller and user profile
  # We can provide this with a help of nested attributes
  #
  def update
    tab = (params[:user][:seller_attributes]) ? 'seller' : 'general'
    if params[:user]

      if Date.valid_date?(params[:user]['birthday(1i)'].to_i,
                          params[:user]['birthday(2i)'].to_i,
                          params[:user]['birthday(3i)'].to_i).nil?
        notify(:type => "alert", :title => t(:update_profile), :message => t(:incorrect_date))
        return redirect_back_or_root
      end

      user = User.find(current_user.id, :include => [:address, :seller])
      if user.update_attributes(params[:user].merge(:reset => 0))
        notify(:type => "success", :title => t(:update_profile), :message => t(:successfully_changed))
        redirect_to user_path + "?tab=#{tab}"
      else
        notify(:type => "alert", :title => t(:update_profile), :message => errors_messages_for(user))
        redirect_back_or_root
      end
    else
      notify(:type => "alert", :title => t(:update_profile), :message => t(:record_not_found))
      redirect_back_or_root
    end
  end

  #This method creates instance variable @country_states and renders rjs for dynamic states select
  #
  def dynamic_states
    @country_states = {}
    Country.all(:include => :states).each { |c| @country_states.merge!(c.id => c.states.collect(&:id)) }
    respond_to { |format| format.js { render 'dynamic_states.js.erb', :layout => false } }
  end

  def resend_mail
    user = User.find_by_id(params[:id])
    if user.nil?
      notify(:type => "notice", :title => t(:register_process), :message => t(:record_not_found))
    else
      check_if_registered?(user)
    end
    redirect_to root_path()
  end

  private

  def correct_user
    user = User.find_by_id(params[:id])
    unless current_user?(user)
      notify(:type => "alert", :title => t(:user_profile), :message => t(:permission))
      redirect_to user_path(current_user)
    end
  end

  # Looks whether user is already registered or not
  # otherwise sends an email confirmation
  #
  def check_if_registered?(user)
    if user.registered?
      notify(:type => "alert", :title => t(:register_process), :message => t(:already_registered))
    else
      notify(:type => "notice", :title => t(:register_process), :message => t(:confirm_send))
      user.send_confirmation_mail
    end
  end
end
