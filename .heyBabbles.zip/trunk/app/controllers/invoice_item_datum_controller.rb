class InvoiceItemDatumController < ApplicationController
  before_filter :deny_if_strange_product

  def show;
  end

  def edit;
  end

  def update
    if_has_intracking_number? do
      set_additional_params
      redirect_to sold_products_path
    end
  end

  private

  def if_has_intracking_number?
    if params[:inv_it_data][:intracking_number][:params_value].blank?
      notify(:type => "error", :title => t(:cart_updating), :message => t("shipping_info.no_number"))
      redirect_back_or_root
    else
      yield
    end
  end

  #Deny, when user will show the strange product
  def deny_if_strange_product
    if @payment_info = InvoiceItemData.find_by_id(params[:id])
      unless current_seller.has_product?(@payment_info.identifier_id)
        notify(:type => "error", :title => t(:reporting), :message => t(:permission))
        redirect_back_or_root
      end
    else
      notify(:type => "alert", :title => t(:reporting), :message => t(:record_not_found))
      redirect_back_or_root
    end
  end

  # 'Deprecated'
  def transform_date(date)
    date[:params_value].values.join("-")
  end

  def arguments
    info = params[:inv_it_data]
    status = params[:invoice_item_data][:status]
    closed = params[:invoice_item_data][:closed]
    array = info.values
    array[1][:params_value] = transform_date(array[1])

    [@payment_info, array, status, closed]
  end

  def set_additional_params
    InvoiceItemData.set_additional_params(*arguments)
  rescue => error
    notify(:type => "error", :title => t(:cart_updating),
           :message => t("shipping_info.no_update").concat(' ' + error))
  else
    notify(:type => "success", :title => t(:cart_updating), :message => t("shipping_info.updated"))
  end
end
