class FeedbacksController < ApplicationController

  def index
    add_breadcrumb I18n.t(:feedbacks), :feedbacks_path
    if params[:controllers] == "sellers"
      @seller = Seller.find_by_id(seller_id)
      @cnav = [["Home", root_path], ["#{@seller.fullname}", seller_path(seller_id)], ["Feedbacks", feedbacks_path("sellers", seller_id)]]
      @feedbacks = @seller.feedbacks.select("feedback_text, created_at").paginate(:page => params[:page])
    else
      @feedbacks = User.by_payed(user_id).paginate(:page => params[:page])
    end
    notify(:type => "notice", :title => t("feedback.title"), :message => t("feedback.havent")) if @feedbacks.blank?
  end

  def create
    @feedback = Feedback.new(:writer_id => user_id, :writeable_id => params[:writeable_id],
                             :writeable_type => "Seller", :feedback_text => params[:feedback][:feedback_text],
                             :write_through_id => params[:write_through_id], :write_through_type => "ReceiverOption")
    if @feedback.save
      render :update do |page|
        page.replace_html "#feedback_#{params[:write_through_id]}", @feedback.feedback_text
      end
    end
  end

end