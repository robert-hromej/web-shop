class ProductRecommendationsController < ApplicationController
  skip_before_filter :authenticate

  def show
<<<<<<< .working
session[:url_before_item_show] = request.env["HTTP_REFERER"]
=======
    add_breadcrumb I18n.t(:recommendation_page), :recommendation_path
>>>>>>> .merge-right.r606
    if params[:id]
      @product = Product.find_by_id(params[:id])
      @recommendations = @product.recommendations if @product
      @recent = return_recent_products(params[:id].to_i)
      redirect_back_or_root unless @product
    end
  end

end
