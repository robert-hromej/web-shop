class ApplicationController < ActionController::Base

  before_filter :authenticate
   before_filter :set_home_breadcrumb
  protect_from_forgery

  include Facebooker2::Rails::Controller
  include SessionsHelper
  include ApplicationHelper
  helper_method :fb_user_valid?

  def set_home_breadcrumb
    add_breadcrumb I18n.t(:home), :root_path
  end

  def fb_user_valid?
    valid = current_facebook_user
    begin
      current_facebook_user.try(:fetch)
    rescue Mogli::Client::HTTPException => e
      cookies.delete(fb_cookie_name) if !fb_cookie_name.nil?
      valid = false
    end
    valid
  end


  # this method needs optimization for payment.
  def validate_cart
    initialize_cart
    @cart_data = check_cart(@cart.get_items)
    if @cart_data[:valid]
      notify(:type => "success", :title => "Valid", :message => "All products in cart has a valid condition")
      render "carts/validate"
    else
      notify(:type => "alert", :title => "Not valid", :message => "Condition of the cart is not valid")
    end
  end

  private

    def initialize_cart
      if signed_in?
        @cart = DbCart::Cart.new(current_user)
      else
        @cart = SessionCart::Cart.new(session)
      end
    end


    def check_cart(cart_items)
      invalid_items = []
      sellers = []
      valid = true
      cart_items.each do |line_item|
        unless line_item.has_valid_condition?
          invalid_items << line_item
        end
        sellers << line_item.item_type.product.store.seller.id
      end
      sellers.uniq!
      valid = false if !invalid_items.blank? || sellers.count > SELLER_LIMIT
      return {:invalid_items => invalid_items, :sellers => sellers, :valid => valid}
    end



  #todo Refactor
  #To raise error is a bad idea.We need to create new mechanism.
  #
  def access_control(record, options = {})
    case
      when (record.is_a?(Product) or options[:as] == :product)
        raise "access denied to this product" unless current_user.my_product?(record)
      when (record.is_a?(ShipTo) or options[:as] == :ship_to)
        raise "access denied to this product" unless current_user.my_product?(record.product_id)
      when (record.is_a?(ProductCounter) or options[:as] == :product_counter)
        raise "access denied to this product" unless current_user.my_product?(record.product_id)
      when record.is_a?(NilClass)
        raise "it object is nil"
      else
        raise "dont implement access_control for #{record.class} model"
    end
  end

  # example notify_object(@product, :method => :save, :success_msg => "success saved",  :alert_msg => "fail saved")
  #
  def notify_do(object, options = {})

    object_return = object.send(options[:method])

    if object_return
      options[:type] = "success"
      options[:message] = options[:success_msg]
    else
      options[:type] = "alert"
      options[:message] = options[:alert_msg] || errors_messages_for(object)
    end

    if options[:ajax]
      ajax_notify(options)
    else
      notify(options)
    end

    #if object_return
    #  true
    #else
    #  false
    #end
    !!object_return
  end

end
