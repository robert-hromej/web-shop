class ProductCountersController < ApplicationController

  before_filter :authenticate

  def create
    @product = Product.find_by_id(params[:product_counter][:product_id])
    access_control(@product)

    @service = Service.find_by_id(params[:product_counter][:service_type])
    @product_service = ProductCounter.new params[:product_counter].merge(:payed => false, :points => @service.points)

    notify_do(@product_service, :method => :save, :title => t(:product_management), :success_msg => "Successfully created")
  end

  def update
    @product = Product.find_by_id(params[:product_counter][:product_id])
    access_control(@product)

    @product_service = ProductCounter.find_by_id(params[:id])

    unless @product_service.payed?
      @product_service.check(params[:product_counter].delete(:status))
      notify_do(@product_service, :method => :save, :title => t(:product_management), :success_msg => "Successfully #{@product_service.status? ? "on" : "off"} service")
    end

    render :create
  end

end
