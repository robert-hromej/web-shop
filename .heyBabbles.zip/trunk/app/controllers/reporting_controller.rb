class ReportingController < ApplicationController
  require 'will_paginate/array'

  before_filter :authenticate_seller
  before_filter :deny_without_store
  before_filter :common_breadcrumbs

  def common_breadcrumbs
    add_breadcrumb I18n.t(:my_profile), {:controller => :users, :action => :show, :id => current_user.id}
    add_breadcrumb I18n.t(:my_store), {:controller => :stores, :action => :edit, :id => current_seller.store.id}
  end

  def sold_products
    add_breadcrumb I18n.t(:sold_products), :sold_products_path

    @invoice_datum = ReceiverOption.datum_for_seller(seller_id, params[:filter]).paginate(:page => params[:page])
    if @invoice_datum.blank?
      notify(:type => "notice", :title => t(:reporting), :message => t(:any_sold_products))
    end
  end

  def for_sale_products
    add_breadcrumb I18n.t(:for_sale), :for_sale_products_path

    @products = Product.for_sale_products(seller_id).paginate(:page => params[:page])
    notify(:type => "notice", :title => t("report.title"), :message => t("report.for_sale_products.havent")) if @products.blank?
  end

  def renew_products
    unless params[:renew].nil?
      if Product.update_all(["expiration_date = ?", (Time.now + Product::EXPIRATION_TIME)], ["id IN (?) AND seller_id = ?", params[:renew].map { |id| id.to_i }, seller_id])
        params[:renew] = nil
      end
    end
    redirect_back_or_root
  end

  def product_history
    add_breadcrumb I18n.t(:product_history), :product_history_path
    @products = Product.history_for_seller(seller_id).paginate(:page => params[:page])
  end

  def used_products
    add_breadcrumb I18n.t(:used_products), :used_products_path

    status = params[:filter]
    condition = show_all_used_products?(status) ? "" : (status.blank? ? "accepted is null" : "accepted = #{status}")
    @products = Product.used_products(seller_id, condition).paginate(:page => params[:page])
    notify(:type => "notice", :title => t("report.title"), :message => t("report.used_products.havent")) if @products.blank?
  end

  private

  def show_all_used_products?(status)
    status.nil? || status.to_s == "2"
  end

end
