class ProductsController < ApplicationController

  protect_from_forgery :except => [:ipn_for_approval, :ipn_for_key]
  before_filter :authenticate, :except => [:ipn_for_approval, :ipn_for_key, :index, :show, :dynamic_product_combinations]
  before_filter :deny_without_store, :except => [:ipn_for_approval, :ipn_for_key, :index, :show, :dynamic_product_combinations]
  before_filter :common_breadcrumbs, :except => [:show, :dynamic_product_combinations]
  before_filter :edit_product_breadcrumbs, :only => [:edit, :advanced, :paid]

  caches_page :dynamic_categories
  caches_action :new, :expires_in => APP_CONFIG[:expires_in].minutes

  expose(:currencies) { Currency.all }
  expose(:from_shippings) { Country.from_shippings }
  expose(:categories) { Category.all }
  expose(:combinations) { Combination.all }

  def common_breadcrumbs
    add_breadcrumb I18n.t(:my_profile), {:controller => :users, :action => :show, :id => current_user.id}
    add_breadcrumb I18n.t(:my_store), {:controller => :stores, :action => :edit, :id => current_seller.store.id}
  end

  def edit_product_breadcrumbs
    @product = Product.find_by_id(params[:id])
    add_breadcrumb "#{@product.try(:name)}", :"#{action_name}_product_path"
    access_control(@product)
  end

  def new
    add_breadcrumb I18n.t(:new_product), :new_product_path
    @product = Product.new
  end

  def create
    #May be I am wrong, but we need to check whether
    #combination exists or not!
    combination_id = Combination.where(:category_id => params[:product].delete(:category_id),
                                       :subcategory_id => params[:product].delete(:subcategory_id),
                                       :gender_category_id => params[:product].delete(:gender_category_id)).first.try(:id)
    @product = Product.new(params[:product].merge(:store_id => current_user.store.id, :combination_id => combination_id))

    if @product.save
      UserMailer.product_created(current_user, @product).deliver
      notify(:type => "success", :title => t(:product_management), :message => t(:successfully_saved))
      redirect_to advanced_product_path(@product)
    else
      notify(:type => "alert", :title => t(:product_management), :message => errors_messages_for(@product))
      render new_product_path
    end

  end

  def management
    add_breadcrumb I18n.t(:product_management), :management_products_path

    @products = current_user.my_products.includes(:images, :item_types).paginate(:page => params[:page])
  end

  # searches products by string and category
  def index
    params[:query] ||= ""

    @search_query = params[:query]
    category = Category.find(params[:category_id]) unless params[:category_id].blank?

    @products = Product.search(@search_query, :category => category, :page => params[:page])

    @products = @products.all_new if params[:filter] == "new"
    @products = @products.all_used if params[:filter] == "used"

    ProductCounter.decrement_points(@products.collect(&:id))

  rescue ActiveRecord::RecordNotFound => e
    notify(:type => "alert", :title => t(:searching), :message => e)
  end

  def edit
  end

  #todo Refactor
  #It would be better to assign params[:combination] just in UI
  def update
    @product = Product.find_by_id(params[:id])
    access_control(@product)
    combination_id = Combination.where(:category_id => params[:product].delete(:category_id),
                                       :subcategory_id => params[:product].delete(:subcategory_id),
                                       :gender_category_id => params[:product].delete(:gender_category_id)).first.try(:id)

    if @product.update_attributes(params[:product].merge(:combination_id => combination_id))
      notify(:type => "success", :title => t(:product_management), :message => t(:successfully_saved))
    else
      notify(:type => "alert", :title => t(:product_management), :message => errors_messages_for(@product))
    end
    redirect_to edit_product_path(@product)
  end

  def advanced
  end

  def paid
    @services = Service.all
  end

  def checkout
    # TODO this is payment method
  end

  def show
    @product = Product.find_by_id(params[:id])
#    add_breadcrumb "#{@product.try(:store).try(:name)}", {:controller => :stores, :action => :edit, :id => current_seller.store.id}
    add_breadcrumb "#{@product.try(:name)}", :product_path

    @seller = @product.try(:seller).try(:user)
    @other_products = Product.where("seller_id = #{@product.try(:seller).try(:id)} and id != #{@product.try(:id)}").limit(3)
    recent_products(@product.id)
  end


  def dynamic_product_combinations
    @combinations = ItemType.for_product(params[:id]).all
    @product_combinations = []
    @combinations.each do |combination|
      @product_combinations << {:color => {:title => combination.color_title, :id => combination.color_category_id},
                                :size => {:title => combination.size_title, :id => combination.size_category_id},
                                :count => combination.item_count, :price => combination.price}
    end
    render :layout => false
  end

  def dynamic_categories
    @categories = {}
    #    creates hash for dynamic_categories like {"1"=>{"2"=>[3, 4],"6"=>[3,8]},"5"=>{"6"=>[3,8]}}
    #    where keys in the parent hash are a category_id's keys in the second hash are a subcategory_id's
    #    and arrays contain all relative gender id's
    #
    combinations.each do |combination|
      category_id = combination.category_id.to_s
      subcategory_id = combination.subcategory_id.to_s
      gender_id = combination.gender_category_id

      @categories.merge!(category_id => {}) if @categories[category_id].nil?
      unless @categories[category_id][subcategory_id].nil?
        @categories[category_id][subcategory_id] << gender_id
      else
        @categories[category_id].merge!(subcategory_id => [gender_id])
      end
    end
    render :layout => false
  end

  #todo Tom! Remove this
  def test
    #request.format = :js if params['accept_js'] == '1'

    respond_to do |format|
      format.html do
        @product_id = rand(10000) + 1
        html = '<textarea data-type="application/json">{"ok": true, "message": "Thanks so much"}</textarea>'.html_safe
        render :text => html if params[:image]
      end
      format.js do
        #image = ApplicationImage.new(params[:image])
        message = "Ha"
        #message = image.save ? "Success" : "Fail"
        #render :update do |page|
        #  page["target1"].replace_html :partial => "shared/remotipart_response"
        #end
        render :partial => "shared/remotipart_response"
      end
    end
  end

  #todo Tom! Remove this
  def cancel_test
    render :layout => false
  end

  #todo Tom! Remove this
  def return_test
    render :layout => false
  end

  def ipn_for_approval
    if params.keys.include?("preapproval_key")
      settings = ApprovalOptions.new(:user_id => user_id, :params => params, :ap_key => params[:preapproval_key])
      if settings.save
        logger.info "Approval settings saved!"
      else
        logger.info settings.errors.to_s
      end
    end
    render :text => true
  end

  def ipn_for_key
    logger.info "elseelseelseelseelseelse"
    render :text => true
  end

  private

  def deny_without_store
    if current_user.store.nil?
      message = (t('need_store') + ("<a href='#{new_store_path}'>Create store</a>")).html_safe
      notify(:type => "error", :title => t(:product_management), :message => message)
      redirect_back_or_root
    end
  end

  #todo need to be removed
  def prepare_form
    urls = {"returnUrl" => "return_test", "cancelUrl" => "cancel_test", "ipnNotificationUrl" => "ipn_for_key", "action_type" => "PAY"}
    request_for_pk = PayKey.new(urls)

    @pay_key = request_for_pk.receiver_list([{"email"=>"buyer_1320835920_per@gmail.com", "amount" => 2.00}]).fetch_pay_key

    #request_for_ak = ApprovalKey.new(urls.merge("ipnNotificationUrl" => "ipn_for_approval"))
    #@approval_key = request_for_ak.approval_settings.fetch_approval_key
    #ApprovalOptions.create!(:preapproval_key => @approval_key,
    #                        :starting_date => request_for_ak.data[:startingDate],
    #                        :ending_date => request_for_ak.data[:endingDate],
    #                        :sender_email => current_user.email,
    #                        :params => request_for_ak.data
    #)

    options = {
        "senderOptions" => {"requireShippingAddressSelection" => true},
        "receiverOptions" => [
            {
                "invoiceData" =>
                    {"totalShipping" => 1.00,
                     "item"=> [
                         {"name" => "test item name", "itemCount" => 1, "itemPrice" => 1.00, "price" => 1.00}
                     ]
                    },
                "receiver" => {"email" => "buyer_1320835920_per@gmail.com"}
            }
        ],
        "payKey" => @pay_key
    }
    options = SetPayment.new(options)
    options.fetch
  end

end
