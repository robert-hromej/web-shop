class ItemTypesController < ApplicationController

  before_filter :authenticate

  def create
    @product = Product.find_by_id(params[:item_type][:product_id])
    access_control(@product)

    @item_type = ItemType.find_or_create(params[:item_type][:product_id], params[:item_type][:size_category_id], params[:item_type][:color_category_id])

    @item_type.price = params[:item_type][:price]
    @item_type.item_count = params[:item_type][:item_count]

    notify_do(@item_type, :method => :save, :title => t(:product_management), :success_msg => "Successfully created")
  end

  def destroy
    @item_type = ItemType.find_by_id(params[:id])
    @product = Product.find_by_id(@item_type.product_id)
    access_control(@product)
    notify_do(@item_type, :method => :destroy, :title => t(:product_management), :success_msg => t(:successfully_deleted), :alert_msg => "you dont delete this data")
  end

end
