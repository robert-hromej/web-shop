class ShipTosController < ApplicationController

  before_filter :authenticate

  def create
    @product = Product.find_by_id(params[:ship_to][:product_id])
    access_control(@product)
    @ship_to = ShipTo.with_deleted.find_by_country_id_and_product_id(params[:ship_to][:country_id], params[:ship_to][:product_id]) || ShipTo.new

    # We need to move this logic inside model
    if @ship_to.new_record?
      @ship_to.country_id = params[:ship_to][:country_id]
      @ship_to.product_id = params[:ship_to][:product_id]
    else
      @ship_to.deleted_at = nil
    end
    @ship_to.cost = params[:ship_to][:cost]
    @ship_to.additional_cost = params[:ship_to][:additional_cost]

    notify_do(@ship_to, {:method => :save, :title => t(:product_management),
                         :success_msg => t(:successfully_saved), :ajax => true})
  end

  #Who functional will react if ship_to == nil
  def update
    @ship_to = ShipTo.with_deleted.find_by_id(params[:ship_to][:id])
    access_control(@ship_to)

    # We need to move this logic inside model
    @ship_to.deleted_at = nil
    @ship_to.cost = params[:ship_to][:cost]
    @ship_to.additional_cost = params[:ship_to][:additional_cost]

    notify_do(@ship_to, {:method => :save, :title => t(:product_management),
                         :success_msg => t(:successfully_saved), :ajax => true})
  end

  def destroy
    @ship_to = ShipTo.find_by_id(params[:id])
    access_control(@ship_to)
    @product = @ship_to.try(:product)

    notify_do(@ship_to, {:method => :destroy, :title => t(:product_management), :success_msg => t(:successfully_deleted),
                         :alert_msg => "you dont delete this data", :ajax => true})
  end

end
