class PurchaseHistoriesController < ApplicationController

  def index
    add_breadcrumb I18n.t(:purchase_history), :purchase_histories_path
    @items = InvoiceItemData.only_products.by_user(current_user.id).
        includes(:identifier => :sold_one).paginate(:page => params[:page])
  end

end
