class HomeController < ApplicationController
protect_from_forgery :only => [:increment]
  skip_before_filter :authenticate
  protect_from_forgery :only => [:increment]

  def index
    @last_products ||= []
    @products ||= Product.fetch_features

#    create_hash_in_cache if cache_expired?

    @seller = Seller.featured
    @seller.last_product(4).each_slice(2) { |element| @last_products << element } unless @seller.nil?
  end

  # This method increments counters and invalidates cache of page.
  def increment
    respond_to do |format|
      format.js do
 #       # Increment view counter
 #       counter = CACHE.get('counter')
 #       # This happens when cache launched on
 #       unless counter.blank?
 #         counter.merge!(:count => counter[:count] + 1)
 #         CACHE.set("counter", counter)
 #       end

#        if cache_expired?
#          Product.decrement_counters(CACHE.get('product_ids'), counter[:limit])
#          expire_page :action => :index
#          # Run screen for background request so user will see cached page permanently.
#          system("screen -dmS set_cache wget http://#{request.host_with_port}/ &")
#        end
#        render :update do |page|
#          page.replace_html "#update", :partial => "layouts/links"
#          page.replace_html "#facebook_connect", :partial => "layouts/facebook_connect"
#        end

      end
    end
  end


  private
  # Here we are creating 2 cache instances
  # 'first' will store the counter with minimal value
  # 'second' will store ids of all featured products
  #
  def create_hash_in_cache
    impressions = []; products = @products.flatten
    products.each { |product| impressions << product.attributes_before_type_cast["points"].to_i }
    CACHE.set("counter", {:count => 0, :limit => impressions.min})
    CACHE.set("expiration", Time.now + 20.minutes) #sets cache expiration time
    CACHE.set("product_ids", products.collect(&:id))
  end

  def cache_expired?
    counter = CACHE.get('counter')
    unless counter.blank?
      return (counter[:limit].to_i < counter[:count]) || Time.now > CACHE.get('expiration')
    end
    true
  end
end
