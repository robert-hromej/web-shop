class ProductSeasonsController < ApplicationController

  before_filter :authenticate

  def create
    @product = Product.find_by_id(params[:product_season][:product_id])
    access_control(@product)
    @product_season = ProductSeason.new(params[:product_season].merge(:paid => false))

    notify_do(@product_season, :method => :save, :title => t(:product_management), :success_msg => "Successfully created")
  end

  def destroy
    @product_season = ProductSeason.where(:id => params[:id], :paid => false).first
    @product = @product_season.try(:product)
    access_control(@product)
    notify_do(@product_season, :method => :destroy, :title => t(:product_management), :success_msg => "Successfully created")
  end

end
