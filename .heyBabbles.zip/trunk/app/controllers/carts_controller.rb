class CartsController < ApplicationController

  skip_before_filter :authenticate
  before_filter :initialize_cart
  before_filter :validate_cart, :only => :validate

  def add
    line_item = LineItem.build_from_params(params)
    error = false

    if line_item.valid?
      if @cart.add_item(line_item)
        notify(:type => "success", :title => "Ok", :message => t("product_added"))
      else
        notify(:type => "alert", :title => "Already in cart", :message => t("already_in_cart"))
        error = true
      end
    else
      notify(:type => "alert", :title => "Wrong data", :message => "#{line_item.errors.full_messages.join('<br/>')}")
      error = true
    end
    error ? (redirect_to :back) : (redirect_to recommendation_path(params[:product_id]))
  end


  def index
    add_breadcrumb I18n.t(:cart), :cart_items_path

    @cart_items = @cart.get_items
    @all_cost = cart_items_cost
  end


  def validate
  end


  def remove
    @line_item = @cart.fetch_line_item(params)
    unless @line_item.blank?
      @cart.destroy_line_item(@line_item)
      notify(:type => "success", :title => "Product removed", :message => "Product was successfully removed from you cart")
    else
      notify(:type => "alert", :title => "Wrong product", :message => "This product already isn't in cart")
    end
    respond_to do |format|
      format.html { redirect_to cart_items_path }
      format.js { [@item_type_id = params[:item_type_id], @ship_to_id = params[:ship_to_id], @all_cost = cart_items_cost] }
    end
  end


  def update
    @line_item = @cart.fetch_line_item(params)
    unless @line_item.blank?
      item_type = @cart.get_item_type(@line_item)
      @count = (@line_item.is_a?(Hash) ? @line_item.values.first[:count] : @line_item.count)
      if 0 < params[:quantity].to_i && params[:quantity].to_i <= item_type.item_count
        @count = params[:quantity].to_i
        @cost = calculate_cost(params, item_type)
        @cart.update_line_item(@line_item, @count)
        notify(:type => "success", :title => "Quantity updated", :message => "Product quantity was successfully updated")
      else
        notify(:type => "alert", :title => "Wrong quantity", :message => "Can't add to cart the selected quantity of products")
      end
    end
    respond_to do |format|
      format.html { redirect_to cart_items_path }
      format.js { [@item_type_id = params[:item_type_id], @ship_to_id = params[:ship_to_id], @all_cost = cart_items_cost] }
    end
  end


  private

    def calculate_cost(params, item_type)
      ship_to = ShipTo.find_by_id(params[:ship_to_id])
      shipping_cost = calculate_shipping_cost(params[:quantity].to_i, ship_to)
      total_cost = item_type.price * params[:quantity].to_i + shipping_cost
      {:shipping => shipping_cost, :total => total_cost}
    end

end
