class SellersController < ApplicationController
  before_filter :authenticate, :except => :show
  before_filter :check_if_seller?, :except => [:show, :rate]

  expose(:countries) { Country.all }
  expose(:states) { State.all }

  caches_action :new, :expires_in => 10.seconds

  def new
    @user = current_user
    @seller = @user.build_seller({})
  end

  def create
    if current_user.update_attributes(params[:user].merge(:reset => 0))
      notify(:type => "success", :title => t(:register_process), :message => t(:seller_registered))
      redirect_to user_path(current_user, :tab=>'seller')
    else
      notify(:type => "error", :title => t(:register_process), :message => errors_messages_for(current_user))
      redirect_to new_seller_path
    end
  end

  def show
    @seller = Seller.find_by_id(params[:id])
    @cnav = [["Home", root_path], ["#{@seller.fullname}", "#"]]
    @products = @seller.store.products.limit(10)
  end

  def rate
    @seller = Seller.find(params[:id])
    @seller.rate(params[:stars], current_user, params[:dimension])
    render :update do |page|
      page.replace_html @seller.wrapper_dom_id(params), ratings_for(@seller, params.merge(:wrap => false))
      page.visual_effect :highlight, @seller.wrapper_dom_id(params)
    end
  end

  private

  def check_if_seller?
    if current_user.seller?
      store = current_user.try(:seller).try(:store)
      if store
        redirect_to edit_store_path(current_user.try(:seller).try(:store))
      else
        redirect_back_or_root
      end
    end
  end
end
