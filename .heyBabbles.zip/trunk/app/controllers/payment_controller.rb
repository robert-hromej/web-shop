class PaymentController < ApplicationController

  before_filter :validate_cart, :only => :show

  def show

=begin
    @cart_data = check_condition(@@cart.get_items)
    if @cart_data[:valid]
      render :text => "ok"
    else
      notify(:type => "alert", :title => "Not valid", :message => "Condition of the cart is not valid")
      # should render carts/check_condition as js
      redirect_to cart_path()
    end
=end


  end

end
