class LineItem < ActiveRecord::Base
  belongs_to :item_type
  belongs_to :ship_to
  belongs_to :user

  validates_uniqueness_of :item_type_id, :scope => [:ship_to_id, :user_id]
  validates_presence_of :item_type_id, :ship_to_id, :count
  validates :count, :numericality => {:only_integer => true, :greater_than => 0, :less_than_or_equal_to => :max_count}


  def already_in_cart?(cart)
    !cart.find_all { |e| e.keys.include?(try(:item_type).try(:id)) }.find { |e| e.values.first[:ship_to] == try(:ship_to).try(:id) }.blank?
  end

  def to_cart_hash
    {try(:item_type).try(:id) => {:ship_to => try(:ship_to).try(:id), :count => try(:count)}}
  end

  def has_valid_condition?
    try(:item_type).try(:item_count) >= try(:count) ? true : false
  end

  class << self
    def build_from_params(params)
      ship_to = ShipTo.where(:id => params[:destination], :product_id => params[:product_id]).first
      item_type = ItemType.where(:product_id => params[:product_id],
                                 :color_category_id => params[:color],
                                 :size_category_id => params[:size]).first
      quantity = params[:quantity].to_i
      LineItem.new(:item_type => item_type, :ship_to => ship_to, :count => quantity)
    end
  end


  private

  def max_count
    self.try(:item_type).try(:item_count) || 0
  end

end
