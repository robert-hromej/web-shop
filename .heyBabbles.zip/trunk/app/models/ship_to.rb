class ShipTo < ActiveRecord::Base

  acts_as_paranoid

  belongs_to :country
  belongs_to :product

  has_many :line_items, :dependent => :destroy

  validates_presence_of :product_id, :country_id, :cost, :additional_cost, :product_limit
  validates_numericality_of :product_id, :country_id, :cost, :additional_cost, :product_limit
  validates_uniqueness_of :product_id, :scope => [:country_id]

  accepts_nested_attributes_for :country
  accepts_nested_attributes_for :product

end

# == Schema Information
#
# Table name: ship_tos
#
#  id              :integer(4)      not null, primary key
#  product_id      :integer(4)
#  country_id      :integer(4)
#  cost            :integer(4)      default(0), not null
#  additional_cost :integer(4)      default(0), not null
#  product_limit   :integer(4)      default(0), not null
#  created_at      :datetime
#  updated_at      :datetime
#  deleted_at      :datetime
#

