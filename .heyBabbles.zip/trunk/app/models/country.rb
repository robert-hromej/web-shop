class Country < ActiveRecord::Base

  COUNTRY_TYPE = {:base => 1, :from => 2, :to => 4}

  BASE_RANGE = [1, 3, 5, 7]
  FROM_RANGE = [2, 3, 6, 7]
  TO_RANGE = [4, 5, 6, 7]

  TITLE = 30
  TYPE = 2

  attr_accessible :title, :country_type

  has_many :addresses, :dependent => :nullify
  has_many :states, :dependent => :nullify
  has_many :shippings, :class_name => "ShipTo", :dependent => :nullify
  has_many :products, :foreign_key => "ship_from_id", :dependent => :nullify

  scope :base_shippings, :conditions => {:country_type => BASE_RANGE}
  scope :from_shippings, :conditions => {:country_type => FROM_RANGE}
  scope :to_shippings, :conditions => {:country_type => TO_RANGE}

  validates :title, :presence => true, :length => {:within => 2..TITLE}, :uniqueness => {:case_sensitive => false}
  validates :country_type, :length => {:maximum => TYPE},
            :inclusion => {:in => COUNTRY_TYPE[:base]..COUNTRY_TYPE.values.sum}

end

# == Schema Information
#
# Table name: countries
#
#  id           :integer(4)      not null, primary key
#  title        :string(30)      not null
#  country_type :integer(2)      default(1), not null
#

