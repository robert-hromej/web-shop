class PaymentOption < ActiveRecord::Base

  serialize :params

  attr_accessible :params, :pay_key, :user_id

  has_many :receiver_options, :class_name => "ReceiverOption", :foreign_key => "payment_opt_id"
  belongs_to :sender, :class_name => "User", :primary_key => "id", :foreign_key => "user_id"

  validates_presence_of :params, :user_id
  validates :pay_key, :presence => true, :uniqueness => true

end

# == Schema Information
#
# Table name: payment_options
#
#  id           :integer(4)      not null, primary key
#  sender_email :string(255)     not null
#  pay_key      :string(255)     not null
#  params       :text            default(""), not null
#  created_at   :datetime
#  updated_at   :datetime
#

