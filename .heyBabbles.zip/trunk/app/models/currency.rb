class Currency < ActiveRecord::Base

  has_many :products, :dependent => :destroy

  validates :title, :presence => true

  attr_accessible :title

end

# == Schema Information
#
# Table name: currencies
#
#  id    :integer(4)      not null, primary key
#  title :string(255)
#

