class Category < ActiveRecord::Base

  MAIN_CATEGORIES_LEVEL = 1
  SUB_CATEGORIES_LEVEL = 2
  GENDER_CATEGORIES_LEVEL = 3
  SIZE_CATEGORIES_LEVEL = 4
  COLOR_CATEGORIES_LEVEL = 5

  MAIN_ONE = {
      "Babies" => 1,
      "Maternity" => 2,
      "Daddies" => 3,
      "Kids" => 4
  }

  LEVELS_SYMBOLS = {
      1 => :category,
      2 => :subcategory,
      3 => :gender,
      4 => :size,
      5 => :color
  }

  has_many :combinations, :dependent => :destroy
  has_many :sub_combinations, :class_name => 'Combination', :foreign_key => :subcategory_id
  has_many :gender_combinations, :class_name => 'Combination', :foreign_key => :gender_category_id
  has_many :color_item_types, :class_name => 'ItemType', :foreign_key => :color_category_id
  has_many :size_item_types, :class_name => 'ItemType', :foreign_key => :size_category_id

  has_many :main_products, :class_name => 'Product', :through => :combinations
  has_many :sub_products, :class_name => 'Product', :through => :sub_combinations
  has_many :gender_products, :class_name => 'Product', :through => :gender_combinations
  has_many :size_products, :class_name => 'Product', :through => :size_item_types
  has_many :color_products, :class_name => 'Product', :through => :color_item_types

  attr_accessible :title, :level
  validates_presence_of :title

  scope :main_categories, where(:level => MAIN_CATEGORIES_LEVEL)
  scope :sub_categories, where(:level => SUB_CATEGORIES_LEVEL)
  scope :gender_categories, where(:level => GENDER_CATEGORIES_LEVEL)
  scope :color_categories, where(:level => COLOR_CATEGORIES_LEVEL)
  scope :size_categories, where(:level => SIZE_CATEGORIES_LEVEL)
  class << self
    attr_accessor :main_one, :sub_one, :color_one, :gender_one, :size_one

    def group_by_levels(condition = nil)
      group_categories = []
      #Came from search
      #
      if condition
        all_categories = where("`categories`.`title` regexp ?", condition).all
      else
        all_categories = all
      end


      {:main_one => 1, :sub_one => 2,
       :gender_one => 3, :color_one => 4,
       :size_one => 5
      }.each do |singleton, level|
        group = all_categories.select { |category| category.level == level }
        send("#{singleton}=", group) unless group.blank?
      end
    end

    def categories_tree
      category_to_hash = lambda { |c| {:id => c.id, :title => c.title} }

      self.group_by_levels

      categories_array = main_one.collect &category_to_hash
      subcategories_array = sub_one.collect &category_to_hash
      gender_array = gender_one.collect &category_to_hash
      colors_array = color_one.collect &category_to_hash
      sizes_array = size_one.collect &category_to_hash

      categories_array.each { |category| category[:children] = subcategories_array; category[:level] = 1; }
      subcategories_array.each { |category| category[:children] = gender_array; category[:level] = 2; }
      gender_array.each { |category| category[:children] = colors_array; category[:level] = 3; }
      colors_array.each { |category| category[:children] = sizes_array; category[:level] = 4; }
      sizes_array.each { |category| category[:level] = 5; }

      categories_array
    end
  end

end

# == Schema Information
#
# Table name: categories
#
#  id    :integer(4)      not null, primary key
#  title :string(255)
#  level :integer(4)
#

