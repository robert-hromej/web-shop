class State < ActiveRecord::Base

  TITLE = 30

  belongs_to :country

  has_many :addresses, :dependent => :nullify

  validates :title, :presence => true, :length => {:within => 2..TITLE},
            :uniqueness => {:case_sensitive => false, :scope => :country_id}
  validates_each :country_id do |record, attr, value|
    unless Country.base_shippings.collect(&:id).include?(value)
      record.errors.add(attr, "is out of scope for state")
    end
  end

end

# == Schema Information
#
# Table name: states
#
#  id         :integer(4)      not null, primary key
#  title      :string(30)      not null
#  country_id :integer(4)      not null
#

