class Season < ActiveRecord::Base

  has_many :product_seasons, :dependent => :destroy

  scope :active_seasons, where("seasons.end_date > ?", Time.now)

  def self.free_for_product(product)
    ids = product.product_seasons.collect(&:season_id)
    where(ids.blank? ? "" : "seasons.id NOT IN (#{ids.join(",")})")
  end

  validates_with PriceValidation, :fields => [:cost]

  with_options :presence => true do |season|
    season.validates :start_date
    season.validates :end_date
    season.validates :title, :length => {:within => 3..50}
    season.validates :cost, :numericality => true
  end

end

# == Schema Information
#
# Table name: seasons
#
#  id          :integer(4)      not null, primary key
#  title       :string(255)
#  description :text
#  start_date  :date
#  end_date    :date
#  cost        :float
#  created_at  :datetime
#  updated_at  :datetime
#

