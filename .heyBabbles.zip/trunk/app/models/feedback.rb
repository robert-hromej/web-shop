class Feedback < ActiveRecord::Base

  MAX_FEEDBACK_SIZE = 400
  MIN_FEEDBACK_SIZE = 5

  attr_accessible :feedback_text, :writeable_id, :writeable_type, :write_through_type, :write_through_id,
                  :writer_id

  belongs_to :writer, :class_name => "User"
  belongs_to :writeable, :polymorphic => true
  belongs_to :write_through, :polymorphic => true

  ajaxful_rater

  validates :feedback_text, :length => { :within => MIN_FEEDBACK_SIZE..MAX_FEEDBACK_SIZE,
                                         :to_short => "is too short (minimum is #{MIN_FEEDBACK_SIZE} characters)",
                                         :to_long => "is too long (maximum is #{MAX_FEEDBACK_SIZE} characters)"},
                            :presence => true
  validates_presence_of :writer_id, :writeable_id, :writeable_type, :write_through_id, :write_through_type

end