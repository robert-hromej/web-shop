class Combination < ActiveRecord::Base
  attr_accessible :category_id, :gender_category_id, :subcategory_id

  belongs_to :category
  belongs_to :subcategory, :class_name => "Category", :foreign_key => :subcategory_id
  belongs_to :gender, :class_name => "Category", :foreign_key => :gender_category_id

  has_many :products

  validates_uniqueness_of :category_id, :scope => [:subcategory_id, :gender_category_id]
  validates_existence_of :category, :gender, :subcategory

end

# == Schema Information
#
# Table name: combinations
#
#  id                 :integer(4)      not null, primary key
#  category_id        :integer(4)
#  subcategory_id     :integer(4)
#  gender_category_id :integer(4)
#

