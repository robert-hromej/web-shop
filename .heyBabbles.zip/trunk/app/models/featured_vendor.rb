class FeaturedVendor < ActiveRecord::Base

  belongs_to :seller
  scope :ascendants, select("featured_vendors.seller_id,featured_vendors.id,featured_vendors.end_date").order("end_date ASC")

  validates_presence_of :end_date, :start_date, :seller_id
  validates_existence_of :seller

  validates_each :start_date, :end_date do |record, attr, value|
    vendors = FeaturedVendor.all

    unless vendors.empty?

      vendors.each do |vendor|
        range = (vendor.start_date..vendor.end_date).to_a
        record.errors.add attr, 'has already been taken by other FeaturedVendor' if range.include?(value)
      end

    end
  end

end

# == Schema Information
#
# Table name: featured_vendors
#
#  id         :integer(4)      not null, primary key
#  seller_id  :integer(4)
#  start_date :date
#  end_date   :date
#

