class Product < ActiveRecord::Base
  include ProductDeprecations
  include ProductInstanceMethods

  STATUSES = ['used', 'new']
  EXPIRATION_TIME = 1.month
  USED_STATUSES = {"In progress" => "", "Rejected" => "0", "Approved" => "1", "All" => "2"}
  self.per_page = 10

  belongs_to :combination
  belongs_to :currency
  belongs_to :store
  belongs_to :origin, :class_name => "Country", :foreign_key => "ship_from_id"
  belongs_to :main_image, :class_name => "ApplicationImage", :foreign_key => "main_image_id"

  has_one :seller, :through => :store
  has_many :sold_one, :class_name => "InvoiceItemData", :foreign_key => "identifier_id", :as => :identifier
  has_many :images, :class_name => "ApplicationImage", :order => "application_images.position ASC"
  has_many :item_types
  has_many :product_counters
  has_many :counter_services, :through => :product_counters
  has_many :product_seasons
  has_many :destinations, :class_name => "ShipTo"

  accepts_nested_attributes_for :product_counters

  delegate :category_id, :subcategory_id, :gender_category_id, :to => :combination, :allow_nil => true
  delegate :name, :to => :store, :prefix => true
  delegate :user, :to => :seller

  before_create :set_default_values

  validates_presence_of :name, :description, :combination_id, :currency_id, :price, :ship_from_id
  validates :name, :length => {:within => 3..20}
  validates_with BooleanValidator, :fields => [:new]

  validate :associated_images_count

  scope :featured_products, select("products.*, categories.title, stores.name as label, product_counters.points").
      joins(:store, :product_counters, {:combination => :category}).
      where("product_counters.service_type = #{Service::TYPE[:home]} and product_counters.points > 0 and products.id in (SELECT products.id as product_id FROM `products` INNER JOIN `product_counters` ON `product_counters`.`product_id` = `products`.`id` INNER JOIN `combinations` ON `combinations`.`id` = `products`.`combination_id` INNER JOIN `categories` ON `categories`.`id` = `combinations`.`category_id` WHERE (product_counters.service_type = #{Service::TYPE[:home]} and product_counters.points > 0) ORDER BY product_counters.points ASC,categories.title = '#{Category::MAIN_ONE[0]}',categories.title = '#{Category::MAIN_ONE[1]}',categories.title = '#{Category::MAIN_ONE[2]}', categories.title = '#{Category::MAIN_ONE[3]}')").
      order("RAND()").limit(50)

  scope :last_added, lambda { |limit, store_id| select("products.*").where("products.store_id = #{store_id}").#joins(:main_image).#includes(:main_image).
      order("products.created_at ASC").limit(limit) }

  scope :for_current_seller, lambda { |seller_id| where(:seller_id => seller_id) }
  # Deprecated
  scope :history_for_seller, lambda { |seller_id| where(:seller_id => seller_id).joins(:product_counters) }

  scope :for_sale_products, lambda { |seller_id| select("products.id, products.expiration_date, products.name, sum(item_types.item_count) as amount").
      where("products.seller_id = #{seller_id} and products.accepted = 1").joins(:item_types).
      group("products.id").order("products.expiration_date, products.id DESC") }

  scope :used_products, lambda { |seller_id, condition| select("products.id, products.name, products.accepted, products.expiration_date").
      where("products.seller_id = #{seller_id} and products.new = 0").where(condition).order("products.expiration_date") }

  scope :all_new, where(:products => {:new => true})

  scope :all_used, where(:products => {:new => false})


  def order_images
    self.images.count - self.payed_images
  end

  def subtotal
    result = {}
    result[:total] = 0.0

    if order_images > 0
      result[:images] = {
          :count => order_images,
          :cost => order_images * ApplicationImage::PRICE_ONE_IMAGE
      }
      result[:total] += result[:images][:cost]
    end

    result[:services] = []

    product_counters.not_payed.includes(:service).each do |service|
      result[:services] << {
          :title => service.service.title,
          :cost => service.service.price
      }
      result[:total] += service.service.price
    end

    result[:seasons] = []

    Season.joins(:product_seasons).where(:product_seasons => {:product_id => self.id, :paid => false}).each do |season|
      result[:seasons] << {
          :title => season.title,
          :cost => season.cost
      }
      result[:total] += season.cost
    end

    result
  end

  #todo Ask Robert
  # TODO REFACTORING
  # SQL:
  # SELECT countries.*, ship_tos.id FROM countries left JOIN ship_tos ON ship_tos.country_id = countries.id  and ship_tos.product_id = 55 where countries.country_type & 4 and ship_tos.id IS NULL;
  def to_shippings
    Country.joins("LEFT JOIN ship_tos ON ship_tos.country_id = countries.id AND ship_tos.product_id = #{self.id}").
        to_shippings.where(:ship_tos => {:id => nil})
    # old script:
    #ar = destinations.all.collect(&:country_id)
    #conditions = ar.blank? ? "" : "countries.id NOT IN (#{ar.join(",")})"
    #Country.to_shippings.where(conditions)
  end

  #todo Ask Robert
  def product_services
    counters = product_counters.all
    ids = counters.collect(&:service_type)
    Service.all.each do |service|
      unless ids.include?(service.id)
        counters << ProductCounter.new(:service_type => service.id, :product_id => self.id)
      end
    end
    counters.sort_by { |counter| counter.service_type }
  end

  def impressions_for_service(serv_type)
    try(:product_counters).select(:points).where(:service_type => serv_type).first.try(:points)
  end

  def seasons_for_product(id)
    prod_count = Product.where(:product_seasons => {:product_id => id}).select('seasons.title as season_title').joins(:product_seasons => :season).all
    result = prod_count.map { |product| product.attributes_before_type_cast["season_title"] }.join(",")
    result
  end


  class << self
    include ProductSearch
    include ProductFetchFeatured
    #todo Speak with Fedia.About position.
    def category_products(category)
      joins(:combination).where(:combinations => {:category_id => category.id})
    end

    def subcategory_products(category)
      joins(:combination).where(:combinations => {:subcategory_id => category.id})
    end

    def gender_products(category)
      joins(:combination).where(:combinations => {:gender_category_id => category.id})
    end

    def color_products(category)
      joins(:item_types).where(:item_types => {:color_category_id => category.id})
    end

    def size_products(category)
      joins(:item_types).where(:item_types => {:size_category_id => category.id})
    end

    def season_products(season)
      joins(:product_seasons).where(:product_seasons => {:season_id => season.id})
    end

  end


  private

  def set_default_values
    self.expiration_date = (Time.zone.now + Product::EXPIRATION_TIME)
    self.accepted = self.new? ? 1 : nil
  end

  def associated_images_count
    if order_images + payed_images > ApplicationImage::MAX_IMAGES_PER_PRODUCT
      errors.add(:base, "you can not upload more then #{MAX_IMAGES_PER_PRODUCT} images per 1 product ")
    end
  end

end

# == Schema Information
#
# Table name: products
#
#  id              :integer(4)      not null, primary key
#  currency_id     :integer(4)
#  seller_id       :integer(4)
#  store_id        :integer(4)
#  combination_id  :integer(4)
#  price           :float
#  accepted        :integer(4)
#  description     :text
#  return_policy   :text
#  name            :string(255)
#  product_sid     :string(255)
#  shipping_policy :text
#  expiration_date :datetime
#  new             :boolean(1)
#  ship_from_id    :integer(4)
#  created_at      :datetime
#  updated_at      :datetime
#  payd_images     :integer(4)      default(2), not null
#  main_image_id   :integer(4)      default(0), not null
#

