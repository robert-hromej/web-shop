class AdditionalParams < ActiveRecord::Base

  belongs_to :identifier, :primary_key => "id", :foreign_key => "identifier_id", :polymorphic => true
end

# == Schema Information
#
# Table name: additional_params
#
#  id              :integer(4)      not null, primary key
#  params_name     :string(255)
#  params_value    :string(255)
#  identifier_id   :integer(4)
#  identifier_type :string(255)
#  created_at      :datetime
#  updated_at      :datetime
#

