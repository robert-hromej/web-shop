class ProductSeason < ActiveRecord::Base

  belongs_to :season
  belongs_to :product

  validates_existence_of :season, :product
  validates_uniqueness_of :season_id, :scope => [:product_id]
  validates_with BooleanValidator, :fields => [:paid]

  scope :not_payed, where(:paid => false)

end

# == Schema Information
#
# Table name: product_seasons
#
#  id         :integer(4)      not null, primary key
#  season_id  :integer(4)
#  product_id :integer(4)
#  paid       :boolean(1)      default(FALSE), not null
#  created_at :datetime
#  updated_at :datetime
#

