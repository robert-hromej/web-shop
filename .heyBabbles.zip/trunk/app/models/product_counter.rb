class ProductCounter < ActiveRecord::Base

  MAX_POINTS = 100000

  has_many :sold_one, :class_name => "InvoiceItemData", :foreign_key => "identifier_id", :as => :identifier

  belongs_to :service, :foreign_key => "service_type", :primary_key => "service_type"
  belongs_to :product

  scope :home_counter, where(:service_type => Service::TYPE[:home])
  scope :search_counter, where(:service_type => Service::TYPE[:search])

  scope :not_payed, where(:payed => false, :status => true)

  validates_existence_of :product, :service
  validates_with BooleanValidator, :fields => [:payed, :status]
  validates_uniqueness_of :service_type, :scope => [:product_id]
  validates :points, :presence => true, :numericality => true, :inclusion => {:in => 0..MAX_POINTS}

  validates_each :service_type do |record, attr, value|
    service = Service.where(attr => value).first
    record.errors.add attr, "there is no Service with #{attr} #{value}" if service.blank?
  end

  def check(status)
    case status
      when "0"
        self.points = 0
        self.status = false
      when "1"
        self.points = self.service.points
        self.status = true
    end
  end

  def self.decrement_points(product_ids)
    unless product_ids.blank?
      update_all("points = points - 1", "product_id in (#{product_ids.join(",")}) and service_type = #{Service::TYPE[:search]} and points > 0 and payed = 1")
    end
  end

end

# == Schema Information
#
# Table name: product_counters
#
#  id           :integer(4)      not null, primary key
#  product_id   :integer(4)
#  service_type :integer(4)
#  points       :integer(4)      default(0), not null
#  payed        :boolean(1)      default(FALSE), not null
#  status       :boolean(1)      default(FALSE), not null
#

