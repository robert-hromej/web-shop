class Seller < ActiveRecord::Base

  ajaxful_rateable :stars => 5, :dimensions => [:behavior], :cache_column => :rating_average

  FIRST_NAME = 30
  LAST_NAME = 30

  self.per_page = 10

  belongs_to :user

  has_one :address, :through => :user
  has_many :stores, :dependent => :destroy
  has_many :featured_vendors, :dependent => :destroy
  has_many :products, :through => :stores, :source => :products, :dependent => :destroy
  has_many :sales, :class_name => "ReceiverOption", :foreign_key => "custom_id"
  has_many :feedbacks, :as => :writeable, :class_name => "Feedback"

  validates :first_name, :presence => true, :length => {:maximum => FIRST_NAME}
  validates :last_name, :presence => true, :length => {:maximum => LAST_NAME}

  def products_id
    products.collect(&:id)
  end

  def last_product(number = 1)
    store = self.try(:store)
    return nil if store.nil?
    Product.last_added(number, store.id).all
  end

  # Just select one product
  #
  def store
    self.try(:stores).first
  end

  def fullname
    self.try(:first_name).try(:capitalize).to_s + " " + self.try(:last_name).try(:capitalize).to_s
  end

  def address
    self.try(:user).try(:address_full)
  end

  def has_product?(id)
    products_id.include?(id)
  end

  class << self
    #Return only one featured seller
    #
    def featured
      actual_vendor = nil
      vendors = FeaturedVendor.ascendants.all
      vendors.each do |vendor|
        if vendor.end_date > Date.today
          actual_vendor = vendor
          # Delete one vendors history.There must be only one expired user
        elsif vendor.end_date < Date.today
          FeaturedVendor.destroy(vendor)
        end
      end if !vendors.blank?
      return nil if actual_vendor.nil?
      self.first(:conditions => {:id => actual_vendor.seller_id}, :include => [:user, :stores])
    end

  end
end

# == Schema Information
#
# Table name: sellers
#
#  id         :integer(4)      not null, primary key
#  user_id    :integer(4)
#  first_name :string(30)
#  last_name  :string(30)
#  rating     :integer(4)
#  created_at :datetime
#  updated_at :datetime
#

