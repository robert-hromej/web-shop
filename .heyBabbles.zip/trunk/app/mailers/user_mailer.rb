class UserMailer < ActionMailer::Base
  default :from => 'irromance.com'

  def create_welcome_mail(user)
    mail(:to => user.email, :subject => "Registered")
  end

  def password_reset_mail(user)
    @user = user
    mail(:to => user.email, :subject => "Reset Password")
  end

  def confirm_email(user)
    @user = user
    mail(:to => user.email, :subject => "Confirm Email")
  end

  def rescue_mail(error)
    mail(:to => ["tom.koptel@gmail.com", "kedgark@gmail.com"], :subject => "Error Happened")
  end

  def product_created(user, product)
    @user = user
    @product = product
    mail(:to => user.email, :subject => "Product was created #{product.name}")
  end
end
