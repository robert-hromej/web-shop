HeyBabbles::Application.routes.draw do

  match "product_recommendations/show/:id" => "product_recommendations#show", :as => "recommendation"

  root :to => "home#index"

  resources :users do
    collection do
      get :dynamic_states
    end
  end

  get ":controllers/:id/feedbacks" => "feedbacks#index", :as => "feedbacks"
  post "/feedbacks/:writeable_id/:write_through_id" => "feedbacks#create", :as => "create_feedbacks"

  resources :sessions, :only => [:new, :create, :destroy] do
    collection do
      post :update_password
      get :facebook_connect
      get :integration_sign_in
    end
  end

  resources :password_reset, :except => [:show, :destroy, :index]

  resources :products do
    collection do
      get :dynamic_categories
      get :management
    end
    member do
      get :dynamic_product_combinations
      get :advanced
      get :paid
      post :checkout
    end
  end

  resources :application_images, :only => [:create, :update, :destroy] do
    member do
      post :set_main
    end
  end

  resources :categories do
    member do
      get :season, :to => "categories#show", :show_season => true
    end
  end

  resources :sellers, :only => [:new, :create, :edit, :show] do
    member do
      post :rate
    end
  end

  resources :stores, :except => [:destroy]
  resources :item_types, :only => [:create, :destroy]
  resources :ship_tos, :only => [:create, :update, :destroy]
  resources :product_seasons, :only => [:create, :destroy]
  resources :product_counters, :only => [:create, :update]
  resources :invoice_item_datum, :only => [:show, :update, :edit]

  resources :purchase_histories, :only => [:index]

  resources :carts, :only => :index, :path => "cart", :as => "cart_items" do
    collection do
      post :add
      post :update, :as => "update"
      post :remove
      post :validate
    end
  end

  get "/checkout" => "payment#show", :as => "checkout"

  match "/signin" => "sessions#new", :as => "signin"
  match "/signout" => "sessions#destroy", :as => "signout"

  match "/finish_registration/:id" => "password_reset#finish_registration", :as => "finish_registration"
  match "/resend_mail/:id" => "users#resend_mail", :as => "resend_mail"

  match "/reporting/sold_products" => "reporting#sold_products", :as => "sold_products"

  get "/reporting/for_sale_products" => "reporting#for_sale_products", :as => "for_sale_products"
  post "/reporting/renew_products" => "reporting#renew_products", :as => "renew_products"

  match "/reporting/used_products" => "reporting#used_products", :as => "used_products"
  match "/reporting/product_history" => "reporting#product_history", :as => "product_history"

  get "/password_reset/begin_process" => "password_reset#begin_process", :as => "begin_reset"
  post "/increment" => "home#increment"

  match "/test" => "products#test", :as => "test"
  match "/ipn_for_approval" => "products#ipn_for_approval"
  match "/ipn_for_key" => "products#ipn_for_key"
  match "/return_test" => "products#return_test"

  get "/cancel_test" => "products#cancel_test"
end
