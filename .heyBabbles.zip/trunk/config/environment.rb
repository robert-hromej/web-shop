# Load the rails application
require File.expand_path('../application', __FILE__)

# Initialize the rails application
HeyBabbles::Application.initialize!
require 'memcache'
memcache_options = {
    :compression => true,
    :debug => false,
    :namespace => "pr",
    :readonly => false,
    :urlencode => false
}

memcache_servers = ['127.0.0.1:11211']
CACHE = MemCache.new(memcache_options)
CACHE.servers = memcache_servers
