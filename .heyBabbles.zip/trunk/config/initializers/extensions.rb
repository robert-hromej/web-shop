raw_config = File.read("#{Rails.root}/config/app_config.yml")
APP_CONFIG = YAML.load(raw_config)[Rails.env].symbolize_keys
raw_config = File.read("#{Rails.root}/config/services.yml")
SERVICES = YAML.load(raw_config)[Rails.env].symbolize_keys
JSD = YAML::parse(File.open("#{Rails.root}/config/assets.yml")) unless Rails.env == "production"
SELLER_LIMIT = 5

Facebooker2.load_facebooker_yaml
HeyBabbles::Application.middleware.use(Oink::Middleware, :logger => Rails.logger)
