class DevelopmentMailInceptor
  def self.delivering_email(message)
    message.subject = "#{message.to} #{message.subject}"
    message.to = "rmd.metr.team@gmail.com"
  end
end

ActionMailer::Base.smtp_settings = {
    :address => "smtp.gmail.com",
    :port => 587,
    :domain => "www.example.com",
    :user_name => "rmd.metr.team@gmail.com",
    :password => "RmdMetrTeam",
    :authentication => "plain",
    :enable_starttls_auto => true
}
ActionMailer::Base.default_url_options[:host] = APP_CONFIG[:email_host]
#todo need to be removed during real production
#if ["development", "test", "staging"].include?(Rails.env)
Mail.register_interceptor(DevelopmentMailInceptor)
